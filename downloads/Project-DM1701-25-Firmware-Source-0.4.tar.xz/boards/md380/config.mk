# SPDX-License-Identifier: MIT
# Copyright (c) 2026 The RadioFoundry Authors
# MD-380 feature defaults (config/features.mk lists them all). 464 KB for code and read-only data: flash sectors 3-7;
# the codec sectors 8-11 are never linked into (boards/md380/memory.ld, docs/spec/codec-placement.md).
# 160x128 display. The case edge crowds the top row and the two left columns (seen on the radio, 2026-10-16);
# right and bottom are close but usable (hardware-md380.md 7). The fault trace, the large font and LTO follow the
# platform (platform/stm32f4/config.mk)
CONFIG_DISPLAY_INSET ?= 0
CONFIG_DISPLAY_INSET_TOP ?= 1
CONFIG_DISPLAY_INSET_LEFT ?= 2
# The FM TX tones (roger beep, 1750 Hz burst), DTMF and APRS AFSK need a TX tone path through the HR_C5000 or the PC7 PWM:
# not written
CONFIG_FM_TX_TONES ?= n
CONFIG_DTMF ?= n
CONFIG_APRS_RX ?= n
# SFR needs CRC_MCU_Control, which the HR_C5000 lacks (docs/spec/sfr.md); the split duplex glue is written for the
# HR_C6000 and HR_C7000 only
CONFIG_SFR ?= n
CONFIG_HOTSPOT_SPLIT ?= n
# Link time optimization takes the third-party code along (FreeRTOS marks what its port's assembly reaches
# portDONT_DISCARD; the vectors are referenced from the assembly start-up). The image needed it while the application
# had 275 KB, before the codec moved; it stays on for the smaller image
LTO_3P ?= 1
# Stored uncompressed, web control's page and drawing take about 18.5 KB more flash, more than this image has free:
# it would run into the codec sectors. So web control goes with the compression: CONFIG_NET_HTTP_GZIP=n builds the
# plain status page instead (hardware-md380.md 19). Asking for CONFIG_NET_WEBCTL=y as well still fails in the linker
CONFIG_NET_WEBCTL ?= $(CONFIG_NET_HTTP_GZIP)
# What the radio's hardware can't do, one switch per line with the reason (tools/boards.py checks there is one;
# docs/build-config.md, "Unsupported, not written, unconfirmed"): ci's maximal configuration leaves these off
BOARD_UNSUPPORTED += SFR	# the HR_C5000 lacks CRC_MCU_Control for the idle bursts (docs/spec/sfr.md)
BOARD_UNSUPPORTED += SFR_DUALPATH_RX	# needs SFR
BOARD_UNSUPPORTED += SFR_CWID	# needs SFR
BOARD_UNSUPPORTED += FONT_XL	# the 160x128 panel is too small for the large font (it is for 240 px and wider)
CONFIG_AM_RX ?= n
BOARD_UNSUPPORTED += AM_RX	# no air band receiver (docs/spec/airband-and-broadcast.md)
CONFIG_BCAST_FM ?= n
BOARD_UNSUPPORTED += BCAST_FM	# no broadcast receiver (docs/spec/airband-and-broadcast.md)
BOARD_UNSUPPORTED += NAND_STORAGE	# the data flash is a SPI NOR (docs/spec/hardware-md380.md 12)
BOARD_UNSUPPORTED += VIBRATE	# no vibration motor (docs/user/23-radios.md, What the MD-380 lacks)
BOARD_UNSUPPORTED += FAULT_TRACE	# needs a host UART: the host port is USB, the one UART the G models' GPS line
# What the hardware can do but this radio's driver or glue doesn't yet, the same way: off by default, and off in ci's
# maximal configuration too
BOARD_NOT_WRITTEN += FM_TX_TONES	# the TX tone path (through the HR_C5000 or the PC7 PWM) isn't written (above)
BOARD_NOT_WRITTEN += DTMF	# the DTMF tones need the same TX tone path (above)
BOARD_NOT_WRITTEN += APRS_RX	# no APRS receive audio path yet (the HR_C5000's I2S receive audio isn't fed to it)
BOARD_NOT_WRITTEN += APRS_IGATE	# needs APRS receive (above)
BOARD_NOT_WRITTEN += HOTSPOT_SPLIT	# the split duplex glue is HR_C6000 and HR_C7000 only (docs/spec/split-duplex.md)
BOARD_NOT_WRITTEN += AUDIO_PROBE	# no board.audio_tap yet
# Supported, but the maximal configuration leaves these off too: PPP stands in for the USB network adapter on UART-only
# radios (docs/spec/ppp.md), and this one has the adapter. Every switch on doesn't fit the 464 KB of flash with two
# translations: maximal keeps Spanish, as the default build does (Italian builds on the other boards)
# APRS-IS (about 2.7 KB) is left out of maximal too, which had 156 bytes left: with no APRS receive here it only gates
# RF positions out, so it is the first IP service to go. The default build keeps it. It defaults on, so it is set off,
# not only skipped
MAXIMAL_SKIP := NET_PPP LANG_IT LANG_DEFAULT_IT NET_APRSIS
MAXIMAL_VARS := CONFIG_NET_APRSIS=n
# When the default build runs out of room, the IP services go first, the weakest here first: APRS-IS (NET_APRSIS, about
# 2.7 KB: with no APRS receive it only gates RF positions out), then KISS over TCP (NET_KISS, about 0.75 KB, transmit
# only for the same reason), then USRP or SNMP. Each serves its own kind of user over the same USB network link, so
# dropping one costs the others nothing. USB_SERIAL_REQUEST stays while USB_NETWORK does: without it a radio in network
# mode can't be reached by the web pages
CONFIG_RX_EXT ?= n
BOARD_NOT_WRITTEN += RX_EXT	# no receive range in its chip documents (a PLL and an IF chain, no single receiver chip)

# A Chinese character is 16 px tall (core/ui/cjk_font.h) and these layouts draw their words in the 6x12 font:
# there is no room for a 16 px line, and the CJK face must not be built in (docs/build-config.md)
BOARD_UNSUPPORTED += LANG_ZH	# a Chinese line needs 16 px; this layout draws its words in a smaller font
BOARD_UNSUPPORTED += LANG_DEFAULT_ZH	# needs LANG_ZH
