// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The RadioFoundry Authors
// MD-9600 RF sequencing (boards/md9600/rfseq_md9600.c) and calibration rows (cal_md9600.c) against a fake board: every
// line change, bus word, DAC write and delay is logged, and the tests check the order of the receive, transmit and
// return sequences per board revision, the transmit gates, the error paths and the receiver probe. Nothing here
// drives hardware: the "transmitter" is a log. Built with transmit in the build (md9600RfSeqTest) and without it
// (md9600RfSeqTestNoTx); in both, a line watcher fails the test if the PA loop or a transmitter supply comes on
// where it must not.
#include <stdio.h>
#include <string.h>
#include "rfseq_md9600.h"
#include "md9600.h"
#include "config.h"

#ifndef CONFIG_MD9600_TX
#define CONFIG_MD9600_TX	0
#endif

static int failures;

#define CHECK(cond) do { if (!(cond)) { printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); failures++; } } while (0)

// --- The fake board ---

enum { EV_LINE, EV_PLL, EV_IF, EV_DAC, EV_DELAY };

typedef struct {
	uint8_t kind, a;	// line / band / DAC channel
	uint32_t v;		// level / word / value / microseconds
} ev_t;

#define EV_MAX	600
static ev_t ev[EV_MAX];
static int nev;
static bool level[MD9600_LN_COUNT];
static bool pll_fail, if_fail;
static int pll_fail_after = -1;		// fail the bus at this pll word (counted from the log start)
static int npll;
static int lock_after = -1;		// with the lock op: true after this many polls, -1 never
static int lock_polls;
static bool use_lock;
static uint32_t delay_total;
static bool pa_allowed;			// the watcher: the PA loop or a T5 line may be on
static uint16_t dac_now[2];
static uint32_t last_uhf_word;		// the probe's noise model
static uint32_t probe_match_word;
static uint16_t apc_value = 2400;
static bool apc_ok = true;

static void log_ev(uint8_t kind, uint8_t a, uint32_t v)
{
	if (nev < EV_MAX) {
		ev[nev] = (ev_t){ kind, a, v };
	}
	nev++;
}

static void reset_log(void)
{
	nev = 0;
	npll = 0;
	delay_total = 0;
	lock_polls = 0;
}

static void f_line(void *ctx, uint8_t line, bool lv)
{
	(void)ctx;
	level[line] = lv;
	log_ev(EV_LINE, line, lv);
	if (lv && (line == MD9600_LN_APC || line == MD9600_LN_T5_U || line == MD9600_LN_T5_V)) {
		if (!pa_allowed) {
			printf("PA line %u on at event %d\n", line, nev);
		}
		CHECK(pa_allowed);
		CHECK(CONFIG_MD9600_TX);
	}
}

static bool f_pll(void *ctx, uint8_t band, uint32_t word, uint8_t bits)
{
	(void)ctx;
	(void)bits;
	log_ev(EV_PLL, band, word);
	if (band == MD9600_UHF) {
		last_uhf_word = word;
	}
	return !pll_fail && npll++ != pll_fail_after;
}

// The AK2365A read test's fake chips: PRESENT answers when both receiver supplies are on and its reset was released
// by the pull, ABSENT leaves the data line to the pull (V5), STUCK holds it low
enum { AK_PRESENT, AK_ABSENT, AK_STUCK };
static int ak_mode = AK_ABSENT;
static uint8_t ak_reg[2];
static bool ak_rst_up, ak_rst_pulsed, ak_read_fail;
static int ak_reads;

static bool f_if(void *ctx, uint8_t band, uint16_t word)
{
	(void)ctx;
	log_ev(EV_IF, band, word);
	if ((word >> 9) == MD9600_IF_TEST_REG) {
		ak_reg[band] = (uint8_t)word;
	} else if (word == 0x08AAu) {
		ak_reg[band] = 0;	// the soft reset
	}
	return !if_fail;
}

static void f_if_rst_pull(void *ctx, bool up)
{
	(void)ctx;
	if (!up) {
		ak_rst_pulsed = true;
	}
	ak_rst_up = up;
}

static bool f_if_read(void *ctx, uint8_t band, uint8_t addr, bool pull_up, uint16_t *bits)
{
	(void)ctx;
	ak_reads++;
	const uint16_t ones = (1u << MD9600_IF_READ_BITS) - 1u;
	bool alive = level[MD9600_LN_R5_U] && level[MD9600_LN_R5_V] && ak_rst_up && ak_rst_pulsed;
	if (ak_mode == AK_PRESENT && alive && addr == MD9600_IF_TEST_REG) {
		// One unstable bit (here the pull's level), D7-D0, then D0 held
		uint8_t d = ak_reg[band];
		*bits = (uint16_t)((pull_up ? 1u << 9 : 0u) | (uint16_t)d << 1 | (d & 1u));
	} else if (ak_mode == AK_STUCK) {
		*bits = 0;
	} else {
		*bits = pull_up ? ones : 0u;
	}
	return !ak_read_fail;
}

static void f_dac(void *ctx, uint8_t ch, uint16_t v)
{
	(void)ctx;
	dac_now[ch] = v;
	log_ev(EV_DAC, ch, v);
}

static void f_delay(void *ctx, uint32_t us)
{
	(void)ctx;
	delay_total += us;
	log_ev(EV_DELAY, 0, us);
}

static bool f_locked(void *ctx, uint8_t band)
{
	(void)ctx;
	(void)band;
	return lock_after >= 0 && lock_polls++ >= lock_after;
}

static uint16_t f_rx_tune(void *ctx, uint32_t hz)
{
	(void)ctx;
	return (uint16_t)(1000u + hz / 1000000u);
}

static bool f_apc(void *ctx, uint32_t hz, uint8_t power, uint16_t *dac)
{
	(void)ctx;
	(void)hz;
	*dac = (uint16_t)(apc_value + power);
	return apc_ok;
}

#if CONFIG_MD9600_TX
static uint16_t apc_floor_value;

static uint16_t f_apc_floor(void *ctx, uint8_t band)
{
	(void)ctx;
	(void)band;
	return apc_floor_value;
}
#endif

static uint16_t f_noise(void *ctx, uint8_t band)
{
	(void)ctx;
	(void)band;
	return probe_match_word != 0 && last_uhf_word == probe_match_word ? 1200 : 2000;
}

static md9600_rf_ops_t ops = {
	.line = f_line, .pll = f_pll, .ifw = f_if, .dac = f_dac, .delay_us = f_delay, .locked = NULL,
	.rx_tune = f_rx_tune, .apc = f_apc, .noise = f_noise, .if_rst_pull = f_if_rst_pull, .if_read = f_if_read,
};

// --- Log queries ---

// First event index at or after from matching kind / a / v (v_any: any value), -1 when none
static int find(int from, uint8_t kind, int a, long v)
{
	for (int i = from < 0 ? 0 : from; i < nev && i < EV_MAX; i++) {
		if (ev[i].kind == kind && (a < 0 || ev[i].a == a) && (v < 0 || ev[i].v == (uint32_t)v)) {
			return i;
		}
	}
	return -1;
}

static int last(uint8_t kind, int a, long v)
{
	int r = -1;
	for (int i = 0; i < nev && i < EV_MAX; i++) {
		if (ev[i].kind == kind && (a < 0 || ev[i].a == a) && (v < 0 || ev[i].v == (uint32_t)v)) {
			r = i;
		}
	}
	return r;
}

static int count(uint8_t kind, int a)
{
	int n = 0;
	for (int i = 0; i < nev && i < EV_MAX; i++) {
		n += ev[i].kind == kind && (a < 0 || ev[i].a == a);
	}
	return n;
}

static bool pa_off_now(void)
{
	return !level[MD9600_LN_APC] && !level[MD9600_LN_T5_U] && !level[MD9600_LN_T5_V];
}

// The plan's words appear in order on the band's chip select from index from
static bool words_follow(int from, const md9600_pll_plan_t *p)
{
	int at = from;
	for (uint8_t i = 0; i < p->count; i++) {
		at = find(at, EV_PLL, p->band, p->words[i]);
		if (at < 0) {
			return false;
		}
		at++;
	}
	return true;
}

static md9600_rf_t rf;

static void fresh(md9600_rev_t rev, bool confirmed)
{
	memset(level, 0, sizeof(level));
	pll_fail = if_fail = false;
	pll_fail_after = -1;
	use_lock = false;
	ops.locked = NULL;
	apc_ok = true;
	pa_allowed = false;
	md9600_rf_init(&rf, &ops, rev, confirmed);
	reset_log();
}

// --- Tests ---

static void test_init(void)
{
	reset_log();
	md9600_rf_init(&rf, &ops, MD9600_REV_V5, false);
	// The PA loop and the transmitter supplies go off before anything else
	CHECK(ev[0].kind == EV_LINE && ev[0].a == MD9600_LN_APC && ev[0].v == 0);
	CHECK(find(0, EV_LINE, MD9600_LN_T5_U, 0) < find(0, EV_LINE, MD9600_LN_POWER, 0));
	CHECK(count(EV_PLL, -1) == 0 && count(EV_IF, -1) == 0);
	CHECK(rf.state == MD9600_RF_OFF);

	// An unknown or unbuilt revision: everything off and every request refused
	fresh(MD9600_REV_UNKNOWN, true);
	CHECK(rf.desc == NULL && !rf.confirmed);
	CHECK(md9600_rf_power_up(&rf) == MD9600_RF_E_REV);
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_E_REV);
	CHECK(count(EV_PLL, -1) == 0 && !level[MD9600_LN_POWER]);
	CHECK(md9600_rf_tx(&rf, 446000000u, true, 0) != MD9600_RF_OK && pa_off_now());
	CHECK(rf.refused == 3 && rf.last_err != MD9600_RF_OK);
	md9600_rf_init(&rf, &ops, MD9600_REV_COUNT, true);
	CHECK(rf.desc == NULL);
}

static void test_power_up(void)
{
	md9600_pll_plan_t p;
#if CONFIG_MD9600_V1V3
	fresh(MD9600_REV_V1V3, false);
	CHECK(md9600_rf_power_up(&rf) == MD9600_RF_OK);
	// Receivers on, then the AK2365A reset pulse; no synthesizer words
	int on = find(0, EV_LINE, MD9600_LN_R5_U, 1), rst = find(0, EV_LINE, MD9600_LN_IF_RST, 0);
	CHECK(on >= 0 && rst > on && find(rst, EV_DELAY, -1, MD9600_IF_RESET_US) == rst + 1);
	CHECK(find(rst, EV_LINE, MD9600_LN_IF_RST, 1) == rst + 2);
	CHECK(count(EV_PLL, -1) == 0);
#endif
#if CONFIG_MD9600_V4
	fresh(MD9600_REV_V4, false);
	CHECK(md9600_rf_power_up(&rf) == MD9600_RF_OK);
	// The VHF synthesizer set right after power-on (145 MHz receive)
	CHECK(md9600_pll_plan(MD9600_REV_V4, MD9600_V4_KICK_HZ, false, &p));
	CHECK(p.band == MD9600_VHF && words_follow(0, &p) && count(EV_PLL, -1) == p.count);
	CHECK(find(0, EV_LINE, MD9600_LN_IF_RST, 0) < find(0, EV_PLL, -1, -1));
	CHECK(rf.lo_hz == p.lo_hz);
	// A bus failure there is reported
	fresh(MD9600_REV_V4, false);
	pll_fail = true;
	CHECK(md9600_rf_power_up(&rf) == MD9600_RF_E_BUS && rf.errors == 1);
#endif
#if CONFIG_MD9600_V5
	fresh(MD9600_REV_V5, false);
	CHECK(md9600_rf_power_up(&rf) == MD9600_RF_OK);
	// V5: PE15 is never driven. The reset on the VHF then the UHF chip, after the supplies, then the wait; no other
	// words
	int on5 = find(0, EV_LINE, MD9600_LN_R5_U, 1);
	int rv = find(0, EV_PLL, MD9600_VHF, 0x002000), ru = find(0, EV_PLL, MD9600_UHF, 0x002000);
	CHECK(count(EV_LINE, MD9600_LN_IF_RST) == 0 && count(EV_PLL, -1) == 2);
	CHECK(on5 >= 0 && rv > on5 && ru == rv + 1 && find(ru, EV_DELAY, -1, MD9600_LMX2571_RESET_US) == ru + 1);
	CHECK(level[MD9600_LN_R5_V] && level[MD9600_LN_C5_U] && level[MD9600_LN_POWER] && pa_off_now());
	// No retune repeats it
	reset_log();
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK && find(0, EV_PLL, -1, 0x002000) < 0);
	// A bus failure there is reported
	fresh(MD9600_REV_V5, false);
	pll_fail = true;
	CHECK(md9600_rf_power_up(&rf) == MD9600_RF_E_BUS && rf.errors == 1);
#endif
	(void)p;
}

static void check_rx_order(md9600_rev_t r, uint32_t hz, bool wide)
{
	fresh(r, false);
	md9600_pll_plan_t p;
	CHECK(md9600_pll_plan(r, hz, false, &p));
	CHECK(md9600_rf_rx(&rf, hz, wide) == MD9600_RF_OK);
	const md9600_rev_desc_t *d = md9600_rev_desc(r);
	int apc = find(0, EV_LINE, MD9600_LN_APC, 0);
	int pwr = find(0, EV_LINE, MD9600_LN_POWER, 1);
	int vco = find(0, EV_LINE, p.band == MD9600_VHF ? MD9600_LN_VCO_V : MD9600_LN_VCO_U, 1);
	int w0 = find(0, EV_PLL, p.band, -1);
	int wl = last(EV_PLL, p.band, -1);
	uint8_t tune_ch = p.band == MD9600_VHF ? MD9600_DAC_APC_TUNE_V : MD9600_DAC_TUNE_U;
	int tune = find(0, EV_DAC, tune_ch, f_rx_tune(NULL, hz));
	int af = find(0, EV_LINE, MD9600_LN_AF_VHF, p.band == MD9600_VHF);
	int fm = find(0, EV_LINE, MD9600_LN_FM_SW, 1);
	// PA off, supplies and RX VCO, the words, the settle, front-end tuning, IF, audio band, FM stages
	CHECK(apc == 0 && apc < pwr && pwr < vco && vco < w0);
	CHECK(words_follow(w0, &p) && count(EV_PLL, -1) == p.count);
	CHECK(find(wl, EV_DELAY, -1, -1) == wl + 1);
	CHECK(tune > wl && af > tune && fm > af);
	if (d->if_chip) {
		uint16_t w[MD9600_IF_WORDS];
		uint8_t n = md9600_if_words(wide, w);
		int i0 = find(0, EV_IF, p.band, w[0]);
		CHECK(i0 > tune && i0 < af && count(EV_IF, p.band) == n && count(EV_IF, 1 - p.band) == 0);
		CHECK(find(i0, EV_IF, p.band, w[1]) == i0 + 1);
		CHECK(count(EV_LINE, MD9600_LN_V5_BW_V) == 0);
	} else {
		uint8_t lines = md9600_if_lines_v5(p.band, wide);
		CHECK(count(EV_IF, -1) == 0);
		CHECK(level[MD9600_LN_V5_BW_V] == ((lines & 1u) != 0) && level[MD9600_LN_V5_BW_U] == ((lines & 2u) != 0));
		CHECK(level[MD9600_LN_V5_ROUTE_V] == (p.band == MD9600_VHF) && level[MD9600_LN_V5_ROUTE_U] == (p.band == MD9600_UHF));
	}
	CHECK(pa_off_now() && rf.state == MD9600_RF_RX && rf.lo_hz == p.lo_hz && rf.retunes == 1);
	CHECK(!level[MD9600_LN_T5_U] && level[MD9600_LN_R5_U] && level[MD9600_LN_R5_V]);
	// Every wait bounded and short: a retune is a few milliseconds
	CHECK(delay_total <= 20000u);
}

static void test_rx(void)
{
	for (int r = MD9600_REV_V1V3; r < MD9600_REV_COUNT; r++) {
		if (!md9600_rev_built((md9600_rev_t)r)) {
			continue;
		}
		check_rx_order((md9600_rev_t)r, 145500000u, true);
		check_rx_order((md9600_rev_t)r, 446006250u, false);
	}
	md9600_rev_t r = MD9600_REV_V5;
	// DMR: narrow IF and the FM audio stages off
	fresh(r, false);
	md9600_rf_set_dmr(&rf, true);
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);
	CHECK(!level[MD9600_LN_FM_SW] && !level[MD9600_LN_V5_BW_U]);
	md9600_rf_set_dmr(&rf, false);
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK && level[MD9600_LN_FM_SW] && level[MD9600_LN_V5_BW_U]);

	// Out of band: refused before any word
	fresh(r, false);
	CHECK(md9600_rf_rx(&rf, 300000000u, true) == MD9600_RF_E_BAND);
	CHECK(count(EV_PLL, -1) == 0 && rf.refused == 1 && rf.last_err == MD9600_RF_E_BAND);
	// A bus failure: an error, the PA lines stay off
	fresh(r, false);
	pll_fail = true;
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_E_BUS && rf.errors == 1 && pa_off_now());
#if CONFIG_MD9600_V1V3 || CONFIG_MD9600_V4
	fresh(md9600_rev_built(MD9600_REV_V4) ? MD9600_REV_V4 : MD9600_REV_V1V3, false);
	if_fail = true;
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_E_BUS);
#endif
	// Sleep powers the receivers down
	fresh(r, false);
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);
	md9600_rf_sleep(&rf);
	CHECK(!level[MD9600_LN_POWER] && !level[MD9600_LN_R5_U] && rf.state == MD9600_RF_OFF && pa_off_now());
}

// A lock indication: polled up to the timeout, an error past it
static void test_lock(void)
{
	fresh(MD9600_REV_V5, false);
	ops.locked = f_locked;
	lock_after = 3;
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);
	CHECK(lock_polls == 4);
	fresh(MD9600_REV_V5, false);
	ops.locked = f_locked;
	lock_after = -1;
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_E_LOCK);
	CHECK(rf.errors == 1 && pa_off_now());
	CHECK(delay_total >= MD9600_LOCK_TIMEOUT_US && delay_total <= MD9600_LOCK_TIMEOUT_US + 10000u);
	ops.locked = NULL;
}

static void test_tx_gates(void)
{
	fresh(MD9600_REV_V5, false);
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);
	reset_log();
#if !CONFIG_MD9600_TX
	// Not in this build: every request is refused, no line moves toward transmit
	md9600_rf_t c = rf;
	c.confirmed = true;
	CHECK(md9600_rf_tx_check(&c, 446000000u, 0) == MD9600_RF_E_TX_BUILD);
	CHECK(md9600_rf_tx(&c, 446000000u, true, 0) == MD9600_RF_E_TX_BUILD);
	CHECK(md9600_rf_pa(&c, true) != MD9600_RF_OK);
	CHECK(count(EV_PLL, -1) == 0 && pa_off_now());
#else
	// Unconfirmed revision: refused, nothing keyed
	CHECK(md9600_rf_tx(&rf, 446000000u, true, 0) == MD9600_RF_E_TX_REV);
	CHECK(md9600_rf_tx_check(&rf, 446000000u, 0) == MD9600_RF_E_TX_REV);
	CHECK(count(EV_PLL, -1) == 0 && pa_off_now());
	// Confirmed later (a person stored the revision running): allowed at once
	md9600_rf_confirm(&rf, true);
	CHECK(rf.confirmed && md9600_rf_tx_check(&rf, 446000000u, 0) == MD9600_RF_OK);
	// Another revision stored: refused again until the restart
	md9600_rf_confirm(&rf, false);
	CHECK(!rf.confirmed && md9600_rf_tx_check(&rf, 446000000u, 0) == MD9600_RF_E_TX_REV && pa_off_now());
	md9600_rf_confirm(&rf, true);
	// No revision: nothing to confirm
	fresh(MD9600_REV_UNKNOWN, false);
	md9600_rf_confirm(&rf, true);
	CHECK(!rf.confirmed && md9600_rf_tx_check(&rf, 446000000u, 0) == MD9600_RF_E_REV);
	// Confirmed: out of band and missing calibration refuse
	fresh(MD9600_REV_V5, true);
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);
	reset_log();
	CHECK(md9600_rf_tx(&rf, 300000000u, true, 0) == MD9600_RF_E_BAND);
	apc_ok = false;
	CHECK(md9600_rf_tx(&rf, 446000000u, true, 0) == MD9600_RF_E_TX_CAL);
	apc_ok = true;
	CHECK(md9600_rf_tx_check(&rf, 446000000u, 0) == MD9600_RF_OK);
	CHECK(count(EV_PLL, -1) == 0 && pa_off_now());
	// The PA alone outside transmit
	CHECK(md9600_rf_pa(&rf, true) == MD9600_RF_E_STATE && pa_off_now());
	// A confirmation dropped while tuned for transmit (a running DMR transmission's next burst): no key-up
	CHECK(md9600_rf_tx_tune(&rf, 446000000u, 0, true) == MD9600_RF_OK && rf.state == MD9600_RF_TX);
	md9600_rf_confirm(&rf, false);
	uint32_t next_us;
	CHECK(md9600_rf_pa_step(&rf, 0, &next_us) == MD9600_RF_E_TX_REV && pa_off_now());
	CHECK(md9600_rf_pa(&rf, true) == MD9600_RF_E_TX_REV && pa_off_now());
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);
#endif
	CHECK(rf.state != MD9600_RF_TX);
}

#if CONFIG_MD9600_TX
static void check_tx(md9600_rev_t r, uint32_t rx_hz, uint32_t tx_hz, uint8_t power)
{
	fresh(r, true);
	CHECK(md9600_rf_rx(&rf, rx_hz, true) == MD9600_RF_OK);
	reset_log();
	pa_allowed = true;
	md9600_pll_plan_t p;
	CHECK(md9600_pll_plan(r, tx_hz, true, &p));
	uint8_t b = p.band, o = (uint8_t)(1u - b);
	const md9600_rev_desc_t *d = md9600_rev_desc(r);
	CHECK(md9600_rf_tx(&rf, tx_hz, true, power) == MD9600_RF_OK);
	int r5 = find(0, EV_LINE, MD9600_LN_R5_U, 0);
	int c5 = find(0, EV_LINE, b == MD9600_VHF ? MD9600_LN_C5_V : MD9600_LN_C5_U, 1);
	int c5o = find(0, EV_LINE, o == MD9600_VHF ? MD9600_LN_C5_V : MD9600_LN_C5_U, -1);
	int mod = find(0, EV_LINE, MD9600_LN_MOD_VHF, b == MD9600_VHF);
	int vco = find(0, EV_LINE, b == MD9600_VHF ? MD9600_LN_VCO_V : MD9600_LN_VCO_U, 0);
	int w0 = find(0, EV_PLL, b, -1), wl = last(EV_PLL, b, -1);
	int t5 = find(0, EV_LINE, b == MD9600_VHF ? MD9600_LN_T5_V : MD9600_LN_T5_U, 1);
	int apc = find(0, EV_LINE, MD9600_LN_APC, 1);
	// PA safe, receivers off, C5 per revision, MOD2 and the TX VCO, the words, then T5, the loop, the ramp
	CHECK(find(0, EV_LINE, MD9600_LN_APC, 0) == 0);
	CHECK(r5 > 0 && c5 > r5 && c5o > r5 && mod > c5 && vco > mod && w0 > vco && words_follow(w0, &p));
	CHECK(ev[c5o].v == (d->tx_other_c5_off ? 0u : 1u));
	CHECK(t5 > wl && apc > t5 && find(t5, EV_DELAY, -1, MD9600_TX_SUPPLY_US) > t5);
	if (d->pll == MD9600_PLL_LMX2571) {
		// LMX2571: the transmit settle after the words, before the transmitter supply
		int s = find(wl, EV_DELAY, -1, MD9600_SETTLE_LMX2571_TX_US);
		CHECK(s == wl + 1 && s < t5 && find(0, EV_PLL, -1, 0x002000) < 0);
	}
	if (!d->if_chip) {
		// V5: both IF routes off before the words, and off through the transmission
		int rv = find(0, EV_LINE, MD9600_LN_V5_ROUTE_V, 0), ru = find(0, EV_LINE, MD9600_LN_V5_ROUTE_U, 0);
		CHECK(rv > 0 && rv < w0 && ru > 0 && ru < w0);
		CHECK(!level[MD9600_LN_V5_ROUTE_V] && !level[MD9600_LN_V5_ROUTE_U]);
	}
	// The reference: zero before T5, then rising in steps to the calibrated value
	int z = last(EV_DAC, MD9600_DAC_APC_TUNE_V, 0);
	CHECK(z >= 0 && z < t5);
	int steps = 0;
	uint32_t prev = 0;
	for (int i = apc; i < nev; i++) {
		if (ev[i].kind == EV_DAC && ev[i].a == MD9600_DAC_APC_TUNE_V) {
			CHECK(ev[i].v >= prev);
			prev = ev[i].v;
			steps++;
		}
	}
	CHECK(steps == (int)MD9600_APC_RAMP_STEPS && prev == (uint32_t)(apc_value + power));
	CHECK(level[b == MD9600_VHF ? MD9600_LN_T5_V : MD9600_LN_T5_U] && !level[o == MD9600_VHF ? MD9600_LN_T5_V : MD9600_LN_T5_U]);
	CHECK(level[MD9600_LN_APC] && rf.state == MD9600_RF_TX && rf.lo_hz == tx_hz);
	// No receiver word in transmit; the other band's synthesizer untouched
	CHECK(count(EV_PLL, o) == 0 && count(EV_IF, -1) == 0);

	// DMR bursts: the PA alone, no retune
	reset_log();
	CHECK(md9600_rf_pa(&rf, false) == MD9600_RF_OK && pa_off_now());
	CHECK(md9600_rf_pa(&rf, true) == MD9600_RF_OK && level[MD9600_LN_APC]);
	CHECK(count(EV_PLL, -1) == 0);

	// Back: ramp down, loop and supplies off, then the receive words for the stored frequency
	reset_log();
	md9600_rf_tx_off(&rf);
	md9600_pll_plan_t q;
	CHECK(md9600_pll_plan(r, rx_hz, false, &q));
	int off = find(0, EV_LINE, MD9600_LN_APC, 0);
	int t5off = find(0, EV_LINE, b == MD9600_VHF ? MD9600_LN_T5_V : MD9600_LN_T5_U, 0);
	int down = -1;	// the last reference write before the loop opens: the end of the ramp, at zero
	for (int i = 0; i < off; i++) {
		down = ev[i].kind == EV_DAC && ev[i].a == MD9600_DAC_APC_TUNE_V ? i : down;
	}
	CHECK(find(0, EV_DAC, MD9600_DAC_APC_TUNE_V, -1) == 0 && down > 0 && ev[down].v == 0 && off < t5off);
	CHECK(words_follow(t5off, &q) && find(t5off, EV_PLL, -1, -1) > t5off);
	CHECK(pa_off_now() && rf.state == MD9600_RF_RX && level[MD9600_LN_VCO_U] && level[MD9600_LN_VCO_V]);
	CHECK(level[MD9600_LN_C5_U] && level[MD9600_LN_C5_V] && level[MD9600_LN_R5_U]);
	pa_allowed = false;
}

// DMR: tuned without the settle wait (from an interrupt), the supply up with the loop open, then per burst the loop
// and a short ramp, the supply kept between bursts
static void check_dmr_tx(md9600_rev_t r, uint32_t hz, uint8_t power)
{
	fresh(r, true);
	CHECK(md9600_rf_rx(&rf, hz, false) == MD9600_RF_OK);
	reset_log();
	pa_allowed = true;
	md9600_pll_plan_t p;
	CHECK(md9600_pll_plan(r, hz, true, &p));
	uint8_t t5 = p.band == MD9600_VHF ? MD9600_LN_T5_V : MD9600_LN_T5_U;
	CHECK(md9600_rf_tx_tune(&rf, hz, power, false) == MD9600_RF_OK);
	CHECK(delay_total == 0 && count(EV_PLL, p.band) == p.count && rf.state == MD9600_RF_TX);
	CHECK(pa_off_now());
	CHECK(md9600_rf_tx_settle_us(&rf) >= MD9600_TX_SUPPLY_US);
	if (md9600_rev_desc(r)->pll == MD9600_PLL_LMX2571) {
		CHECK(md9600_rf_tx_settle_us(&rf) == MD9600_SETTLE_LMX2571_TX_US + MD9600_TX_SUPPLY_US);
	}
	for (int burst = 0; burst < 2; burst++) {
		reset_log();
		CHECK(md9600_rf_pa_burst(&rf, true) == MD9600_RF_OK);
		CHECK(level[MD9600_LN_APC] && level[t5] && dac_now[MD9600_DAC_APC_TUNE_V] == apc_value + power);
		CHECK(count(EV_DAC, MD9600_DAC_APC_TUNE_V) == (int)MD9600_BURST_RAMP_STEPS + 1);
		CHECK(delay_total == MD9600_BURST_T5_US + (MD9600_BURST_RAMP_STEPS - 1u) * MD9600_BURST_RAMP_STEP_US);
		CHECK(find(0, EV_LINE, t5, 1) < find(0, EV_LINE, MD9600_LN_APC, 1));	// the supply before the loop
		CHECK(count(EV_PLL, -1) == 0);
		CHECK(md9600_rf_pa_burst(&rf, false) == MD9600_RF_OK);
		CHECK(pa_off_now() && rf.state == MD9600_RF_TX);	// between bursts nothing of the transmitter is on
	}
	// The same key-up in timer steps (radio_md9600.c's TIM5): no waits of its own, the same lines and ramp, and the
	// waits it asks for add up to the busy version's
	reset_log();
	uint32_t step = 0, us = 0, asked = 0;
	CHECK(md9600_rf_pa_step(&rf, step++, &us) == MD9600_RF_OK && us == MD9600_BURST_T5_US);
	CHECK(level[t5] && !level[MD9600_LN_APC] && dac_now[MD9600_DAC_APC_TUNE_V] == 0);	// the supply, loop open
	do {
		asked += us;
		CHECK(md9600_rf_pa_step(&rf, step++, &us) == MD9600_RF_OK);
	} while (us != 0 && step < 20);
	CHECK(step == MD9600_BURST_RAMP_STEPS + 1u && delay_total == 0);
	CHECK(asked == MD9600_BURST_T5_US + (MD9600_BURST_RAMP_STEPS - 1u) * MD9600_BURST_RAMP_STEP_US);
	CHECK(level[MD9600_LN_APC] && level[t5] && dac_now[MD9600_DAC_APC_TUNE_V] == apc_value + power);
	CHECK(md9600_rf_pa_step(&rf, 0, &us) == MD9600_RF_OK && us == 0);	// already on: nothing
	CHECK(md9600_rf_pa_burst(&rf, false) == MD9600_RF_OK && pa_off_now());
	// Ended after the supply step (the burst's end came first): all off
	CHECK(md9600_rf_pa_step(&rf, 0, &us) == MD9600_RF_OK && level[t5]);
	CHECK(md9600_rf_pa_burst(&rf, false) == MD9600_RF_OK && pa_off_now());
	// Back in receive: no burst keys, the PA stays safe
	md9600_rf_tx_off(&rf);
	CHECK(pa_off_now() && rf.state == MD9600_RF_RX);
	CHECK(md9600_rf_pa_burst(&rf, true) != MD9600_RF_OK && pa_off_now());
	CHECK(md9600_rf_pa_step(&rf, 1, &us) != MD9600_RF_OK && us == 0 && pa_off_now());
	pa_allowed = false;
}

// A DMR transmission ends (TX done): the receiver comes back on the RX frequency at once, without waits, so the radio
// hears a repeater answer its wake-up, or on simplex the reply to a confirmed packet 30 ms later (radio_md9600.c
// md9600_rf_dmr_done); the next transmission tunes the carrier again, and rx() afterwards only resumes
static void check_dmr_rx_back(md9600_rev_t r, uint32_t rx_hz, uint32_t tx_hz)
{
	fresh(r, true);
	CHECK(md9600_rf_rx(&rf, rx_hz, false) == MD9600_RF_OK);
	pa_allowed = true;
	md9600_pll_plan_t rxp, txp;
	CHECK(md9600_pll_plan(r, rx_hz, false, &rxp) && md9600_pll_plan(r, tx_hz, true, &txp));
	for (int k = 0; k < 2; k++) {
		CHECK(md9600_rf_tx_tune(&rf, tx_hz, 0, false) == MD9600_RF_OK && rf.state == MD9600_RF_TX);
		CHECK(rf.lo_hz == txp.lo_hz);
		CHECK(md9600_rf_pa_burst(&rf, true) == MD9600_RF_OK && md9600_rf_pa_burst(&rf, false) == MD9600_RF_OK);
		reset_log();
		CHECK(md9600_rf_burst_rx(&rf) == MD9600_RF_OK);
		CHECK(delay_total == 0 && pa_off_now() && rf.state == MD9600_RF_RX && rf.lo_hz == rxp.lo_hz);
		CHECK(count(EV_PLL, rxp.band) == rxp.count && level[rxp.band == MD9600_VHF ? MD9600_LN_R5_V : MD9600_LN_R5_U]);
		if (!md9600_rev_desc(r)->if_chip) {
			// V5: the band's IF route back, which the transmit side dropped
			CHECK(level[rxp.band == MD9600_VHF ? MD9600_LN_V5_ROUTE_V : MD9600_LN_V5_ROUTE_U]);
		}
		CHECK(md9600_rf_burst_rx(&rf) == MD9600_RF_E_STATE);	// once: already receiving
	}
	reset_log();
	md9600_rf_tx_off(&rf);		// the radio leaves transmit: the receiver is already back
	CHECK(pa_off_now() && rf.state == MD9600_RF_RX && count(EV_PLL, -1) == 0);
	pa_allowed = false;
	// The glue's tx_end on the same channel: the front-end tune back (on VHF the PA drive's DAC, zeroed above), no words, no waits
	reset_log();
	CHECK(md9600_rf_rx_resume(&rf) == MD9600_RF_OK);
	CHECK(count(EV_PLL, -1) == 0 && delay_total == 0 && pa_off_now() && rf.state == MD9600_RF_RX);
	if (rxp.band == MD9600_VHF) {
		CHECK(dac_now[MD9600_DAC_APC_TUNE_V] == f_rx_tune(NULL, rx_hz));
	}
	md9600_rf_sleep(&rf);
	CHECK(md9600_rf_rx_resume(&rf) == MD9600_RF_E_STATE);	// not receiving: tx_off() sets receive up in full
}

// The reference's writes to the PA drive in [from, to) of the log
static int apc_writes(int from, int to, uint16_t *lo, uint16_t *first, uint16_t *final)
{
	int n = 0;
	for (int i = from; i < to && i < nev; i++) {
		if (ev[i].kind == EV_DAC && ev[i].a == MD9600_DAC_APC_TUNE_V) {
			*first = n == 0 ? (uint16_t)ev[i].v : *first;
			*lo = n == 0 || ev[i].v < *lo ? (uint16_t)ev[i].v : *lo;
			*final = (uint16_t)ev[i].v;
			n++;
		}
	}
	return n;
}

// With the loop closed the drive never goes under the band's zero-output drive (the floor): under it the loop loses
// control and the PA puts out about 10 W. Every ramp starts and ends there; the drive goes to 0 only with the loop open
static void test_tx_floor(void)
{
	const uint16_t fl = 800;
	uint16_t lo, first, final;
	ops.apc_floor = f_apc_floor;
	apc_floor_value = fl;
	fresh(MD9600_REV_V5, true);
	pa_allowed = true;
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);
	reset_log();
	CHECK(md9600_rf_tx(&rf, 446000000u, true, 1) == MD9600_RF_OK);
	int t5 = find(0, EV_LINE, MD9600_LN_T5_U, 1), lp = find(0, EV_LINE, MD9600_LN_APC, 1);
	int zf = last(EV_DAC, MD9600_DAC_APC_TUNE_V, fl);
	CHECK(t5 > 0 && lp > t5 && zf >= 0 && zf < t5);
	CHECK(apc_writes(lp, nev, &lo, &first, &final) == (int)MD9600_APC_RAMP_STEPS && lo > fl && final == apc_value + 1);
	reset_log();
	md9600_rf_tx_off(&rf);
	int op = find(0, EV_LINE, MD9600_LN_APC, 0);
	CHECK(op > 0 && apc_writes(0, op, &lo, &first, &final) == (int)MD9600_APC_RAMP_STEPS && lo == fl && final == fl);
	CHECK(dac_now[MD9600_DAC_APC_TUNE_V] == 0 && pa_off_now());

	// DMR bursts: the same, in the short ramps
	CHECK(md9600_rf_tx_tune(&rf, 446000000u, 1, false) == MD9600_RF_OK);
	reset_log();
	CHECK(md9600_rf_pa_burst(&rf, true) == MD9600_RF_OK);
	CHECK(apc_writes(0, nev, &lo, &first, &final) == (int)MD9600_BURST_RAMP_STEPS + 1);
	zf = find(0, EV_DAC, MD9600_DAC_APC_TUNE_V, fl);
	CHECK(first == fl && lo == fl && final == apc_value + 1 && zf >= 0 && zf < find(0, EV_LINE, MD9600_LN_T5_U, 1));
	reset_log();
	CHECK(md9600_rf_pa_burst(&rf, false) == MD9600_RF_OK);
	op = find(0, EV_LINE, MD9600_LN_APC, 0);
	CHECK(apc_writes(0, op, &lo, &first, &final) == (int)MD9600_BURST_RAMP_STEPS && lo == fl && final == fl);
	CHECK(dac_now[MD9600_DAC_APC_TUNE_V] == 0 && pa_off_now());
	md9600_rf_tx_off(&rf);

	// A level under the floor (none in the table): the ramp from 0 as without one
	apc_floor_value = (uint16_t)(apc_value + 10);
	reset_log();
	CHECK(md9600_rf_tx(&rf, 446000000u, true, 1) == MD9600_RF_OK);
	lp = find(0, EV_LINE, MD9600_LN_APC, 1);
	zf = last(EV_DAC, MD9600_DAC_APC_TUNE_V, 0);
	CHECK(zf >= 0 && zf < find(0, EV_LINE, MD9600_LN_T5_U, 1));
	CHECK(apc_writes(lp, nev, &lo, &first, &final) == (int)MD9600_APC_RAMP_STEPS && lo < apc_value / 2);
	md9600_rf_tx_off(&rf);
	ops.apc_floor = NULL;
	pa_allowed = false;
}

static void test_tx(void)
{
	for (int r = MD9600_REV_V1V3; r < MD9600_REV_COUNT; r++) {
		if (!md9600_rev_built((md9600_rev_t)r)) {
			continue;
		}
		check_tx((md9600_rev_t)r, 446000000u, 446000000u, 0);
		check_tx((md9600_rev_t)r, 145500000u, 146520000u, 3);
	}

	// A bus failure in transmit: the PA never comes on and the receiver returns
	fresh(MD9600_REV_V5, true);
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);
	reset_log();
	pll_fail_after = 2;
	CHECK(md9600_rf_tx(&rf, 446000000u, true, 1) == MD9600_RF_E_BUS);
	CHECK(find(0, EV_LINE, MD9600_LN_APC, 1) < 0 && find(0, EV_LINE, MD9600_LN_T5_U, 1) < 0 && pa_off_now() && rf.state == MD9600_RF_RX && rf.errors == 1);
	CHECK(rf.last_err == MD9600_RF_E_BUS && level[MD9600_LN_VCO_U]);

	fresh(MD9600_REV_V5, true);
	pa_allowed = true;
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);

	// A retune in transmit (a new frequency, or a power step) and sleep with the PA on: each ramps the PA down first,
	// the loop opening only at the end of the ramp
	for (int k = 0; k < 2; k++) {
		CHECK(md9600_rf_tx(&rf, 446000000u, true, 2) == MD9600_RF_OK && level[MD9600_LN_APC]);
		reset_log();
		if (k == 0) {
			CHECK(md9600_rf_tx(&rf, 446100000u, true, 1) == MD9600_RF_OK);
		} else {
			md9600_rf_sleep(&rf);
		}
		int open = find(0, EV_LINE, MD9600_LN_APC, 0);
		CHECK(count(EV_DAC, MD9600_DAC_APC_TUNE_V) >= (int)MD9600_APC_RAMP_STEPS);
		CHECK(open > 0 && find(0, EV_DAC, MD9600_DAC_APC_TUNE_V, -1) < open);
		CHECK(find(0, EV_DELAY, -1, MD9600_APC_RAMP_STEP_US) >= 0);
		CHECK(k == 1 || find(0, EV_PLL, -1, -1) > open);	// the new words after the PA is off
	}
	CHECK(pa_off_now() && rf.state == MD9600_RF_OFF);
	CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);

	// A receive request in transmit ends the transmission first
	CHECK(md9600_rf_tx(&rf, 446000000u, true, 2) == MD9600_RF_OK);
	reset_log();
	CHECK(md9600_rf_rx(&rf, 440000000u, true) == MD9600_RF_OK);
	CHECK(find(0, EV_LINE, MD9600_LN_APC, 0) < find(0, EV_PLL, -1, -1) && pa_off_now() && rf.rx_hz == 440000000u);
	// tx_off without a stored receive frequency still powers the receivers
	fresh(MD9600_REV_V5, true);
	pa_allowed = true;
	CHECK(md9600_rf_tx(&rf, 446000000u, true, 0) == MD9600_RF_OK);
	md9600_rf_tx_off(&rf);
	CHECK(rf.state == MD9600_RF_RX && level[MD9600_LN_R5_U] && pa_off_now());
	pa_allowed = false;
}
#endif

static void test_probe(void)
{
	md9600_pll_plan_t p;
	md9600_rev_t want = MD9600_REV_V5;
#if CONFIG_MD9600_V4
	want = MD9600_REV_V4;
#endif
	CHECK(md9600_pll_plan(want, MD9600_PROBE_HZ, false, &p));
	probe_match_word = p.words[p.count - 1];	// the last word of the matching revision moves the noise reading
	memset(level, 0, sizeof(level));
	last_uhf_word = 0;
	reset_log();
	CHECK(md9600_rf_probe(&ops, MD9600_PROBE_HZ, MD9600_PROBE_THRESHOLD) == want);
	// Receive side only: no transmitter line on, never PE15, the radio left off
	CHECK(find(0, EV_LINE, MD9600_LN_APC, 1) < 0 && find(0, EV_LINE, MD9600_LN_T5_U, 1) < 0);
	CHECK(count(EV_LINE, MD9600_LN_IF_RST) == 0 && !level[MD9600_LN_POWER]);
	CHECK(count(EV_PLL, MD9600_VHF) == 0);
	// No candidate moves it: no verdict
	probe_match_word = 0;
	CHECK(md9600_rf_probe(&ops, MD9600_PROBE_HZ, MD9600_PROBE_THRESHOLD) == MD9600_REV_UNKNOWN);
	CHECK(md9600_rf_probe(&ops, 300000000u, MD9600_PROBE_THRESHOLD) == MD9600_REV_UNKNOWN);
}

// The AK2365A read test: present on V1-V4, absent on V5, no verdict for anything else; never drives PE15 or a
// transmitter line, and leaves the radio off
static md9600_if_t if_detect(int mode)
{
	ak_mode = mode;
	ak_rst_up = ak_rst_pulsed = false;
	ak_reads = 0;
	memset(level, 0, sizeof(level));
	reset_log();
	return md9600_rf_if_detect(&ops);
}

static void test_if_detect(void)
{
	CHECK(if_detect(AK_PRESENT) == MD9600_IF_PRESENT);
	CHECK(ak_reads == 2 * 2 * MD9600_IF_PATTERNS);
	CHECK(find(0, EV_LINE, MD9600_LN_APC, 1) < 0 && find(0, EV_LINE, MD9600_LN_T5_U, 1) < 0 &&
	      find(0, EV_LINE, MD9600_LN_T5_V, 1) < 0);
	CHECK(count(EV_LINE, MD9600_LN_IF_RST) == 0 && !level[MD9600_LN_POWER] && !level[MD9600_LN_R5_U]);
	CHECK(count(EV_PLL, -1) == 0);
	// Each chip back to its defaults at the end
	CHECK(find(0, EV_IF, MD9600_VHF, 0x08AAu) >= 0 && find(0, EV_IF, MD9600_UHF, 0x08AAu) >= 0);
	CHECK(ak_reg[0] == 0 && ak_reg[1] == 0);
	CHECK(if_detect(AK_ABSENT) == MD9600_IF_ABSENT);
	CHECK(if_detect(AK_STUCK) == MD9600_IF_UNKNOWN);
	// A failed frame or bus write: no verdict, never "absent"
	ak_read_fail = true;
	CHECK(if_detect(AK_ABSENT) == MD9600_IF_UNKNOWN);
	ak_read_fail = false;
	if_fail = true;
	CHECK(if_detect(AK_ABSENT) == MD9600_IF_UNKNOWN);
	if_fail = false;
	// A board without the read ops
	ops.if_read = NULL;
	CHECK(if_detect(AK_PRESENT) == MD9600_IF_UNKNOWN && ak_reads == 0);
	ops.if_read = f_if_read;
}

// The verdict over hand-made frames: each alignment the data sheet allows, one band alone, mixed or wrong answers
static void test_if_verdict(void)
{
	const uint16_t ones = (1u << MD9600_IF_READ_BITS) - 1u;
	uint16_t r[2][2][MD9600_IF_PATTERNS];
	for (uint8_t a = 0; a <= MD9600_IF_READ_BITS - 8u; a++) {
		for (uint8_t b = 0; b < 2u; b++) {
			for (uint8_t pull = 0; pull < 2u; pull++) {
				for (uint8_t k = 0; k < MD9600_IF_PATTERNS; k++) {
					// UHF answers; VHF floats
					r[b][pull][k] = b == MD9600_UHF ?
						(uint16_t)(md9600_if_patterns[k] << (MD9600_IF_READ_BITS - 8u - a)) :
						(pull ? ones : 0u);
				}
			}
		}
		CHECK(md9600_if_verdict(r) == MD9600_IF_PRESENT);
	}
	// Both float: V5
	for (uint8_t b = 0; b < 2u; b++) {
		for (uint8_t k = 0; k < MD9600_IF_PATTERNS; k++) {
			r[b][0][k] = 0;
			r[b][1][k] = ones;
		}
	}
	CHECK(md9600_if_verdict(r) == MD9600_IF_ABSENT);
	// One sample against the pull on one band: something drives the line, so not V5
	r[MD9600_VHF][1][1] = (uint16_t)(ones & ~1u);
	CHECK(md9600_if_verdict(r) == MD9600_IF_UNKNOWN);
	// The patterns swapped (a chip echoing something else): no verdict
	for (uint8_t pull = 0; pull < 2u; pull++) {
		r[MD9600_UHF][pull][0] = (uint16_t)(md9600_if_patterns[1] << 1);
		r[MD9600_UHF][pull][1] = (uint16_t)(md9600_if_patterns[0] << 1);
	}
	CHECK(md9600_if_verdict(r) == MD9600_IF_UNKNOWN);
	// Only one pull answered: no verdict
	r[MD9600_UHF][0][0] = (uint16_t)(md9600_if_patterns[0] << 1);
	r[MD9600_UHF][0][1] = (uint16_t)(md9600_if_patterns[1] << 1);
	CHECK(md9600_if_verdict(r) == MD9600_IF_UNKNOWN);
}

// The reference trim: every synthesizer frequency is f x (1 + trim), the IF unchanged; the band check and the
// calibration lookups stay on f
static void test_ref_trim(void)
{
	for (int r = MD9600_REV_V1V3; r < MD9600_REV_COUNT; r++) {
		if (!md9600_rev_built((md9600_rev_t)r)) {
			continue;
		}
		md9600_pll_plan_t p;
		fresh((md9600_rev_t)r, true);
		rf.trim_ppb = 5000;	// +5.0 ppm
		CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK);
		CHECK(md9600_pll_plan((md9600_rev_t)r, 446002230u, false, &p) && rf.lo_hz == p.lo_hz);
		CHECK(rf.lo_hz == 446002230u - MD9600_IF_HZ && rf.rx_hz == 446000000u);
		rf.trim_ppb = -5000;
		CHECK(md9600_rf_rx(&rf, 145500000u, true) == MD9600_RF_OK && rf.lo_hz == 145499272u + MD9600_IF_HZ);
#if CONFIG_MD9600_TX
		pa_allowed = true;
		CHECK(md9600_rf_tx(&rf, 146520000u, true, 0) == MD9600_RF_OK && rf.lo_hz == 146519267u);
		CHECK(rf.tx_hz == 146520000u);
		// A burst back to receive keeps the trim
		CHECK(md9600_rf_burst_rx(&rf) == MD9600_RF_OK && rf.lo_hz == 145499272u + MD9600_IF_HZ);
		md9600_rf_tx_off(&rf);
#endif
		rf.trim_ppb = 0;
		CHECK(md9600_rf_rx(&rf, 446000000u, true) == MD9600_RF_OK && rf.lo_hz == 446000000u - MD9600_IF_HZ);
	}
}

// The squelch's noise window: speech peaks don't close it, a dropped carrier does at once
static void test_noise_window(void)
{
	md9600_noise_win_t w;
	md9600_noise_clear(&w);
	uint32_t t = 1000;
	// A carrier with speech: pauses near 100, peaks over 1000; RSSI steady at -110 dBm
	static const uint16_t speech[] = { 100, 120, 1200, 1500, 900, 1400, 1300, 110, 1500, 1450 };
	for (unsigned i = 0; i < sizeof speech / sizeof speech[0]; i++, t += 25) {
		CHECK(md9600_noise_floor(&w, speech[i], -110, t) <= 120);
	}
	// Peaks for longer than the window: the floor follows them
	for (int i = 0; i < 8; i++, t += 25) {
		(void)md9600_noise_floor(&w, 1400, -110, t);
	}
	CHECK(md9600_noise_floor(&w, 1400, -110, t) == 1400);
	t += 25;
	CHECK(md9600_noise_floor(&w, 100, -110, t) == 100);
	t += 25;
	// The carrier ends: noise 1800 and RSSI 11 dB down within one poll. The floor follows the next reading
	CHECK(md9600_noise_floor(&w, 1800, -121, t) == 1800);
	t += 25;
	CHECK(md9600_noise_floor(&w, 1750, -121, t) == 1750);
	// A smaller RSSI step keeps the window: a speech peak during a 5 dB fade doesn't close it
	md9600_noise_clear(&w);
	(void)md9600_noise_floor(&w, 100, -100, t);
	t += 25;
	CHECK(md9600_noise_floor(&w, 1500, -105, t) == 100);
	// A retune forgets the last channel
	md9600_noise_clear(&w);
	CHECK(md9600_noise_floor(&w, 1700, -105, t) == 1700);

	// A transmission: the noise line reads 700-800 with the receiver off. The squelch stays closed through it, and the
	// first reading after it (an empty channel, 1800) closes it, not the window's 700 from before
	md9600_noise_clear(&w);
	CHECK(md9600_rf_squelch_noise(&w, true, 1750, -138, t, 0, 0) == 1750 / 16);
	for (int i = 0; i < 20; i++, t += 15) {
		CHECK(md9600_rf_squelch_noise(&w, false, 700 + 5 * i, -145, t, 0, 0) == 255);
	}
	CHECK(md9600_rf_squelch_noise(&w, true, 1800, -138, t, 0, 0) == 1800 / 16);
	t += 15;
	CHECK(md9600_rf_squelch_noise(&w, true, 1600, -138, t, 2400, 1600) == 40);	// calibrated the same way

	// 25 kHz: thresholds from a real channel (level 1 open 900, level 9 open 570). A weak signal the 12.5 kHz filter
	// passes reads about 1300 through the wide one and has to open level 1; an empty channel (1500 up) must not
	CHECK(md9600_rf_sql_wide(900) == 1350 && md9600_rf_sql_wide(570) == 855);
	CHECK(md9600_rf_sql_wide(4095) == 6142);					// no overflow
	CHECK(md9600_rf_noise(1300, md9600_rf_sql_wide(900), md9600_rf_sql_wide(570)) < 64);
	CHECK(md9600_rf_noise(1500, md9600_rf_sql_wide(900), md9600_rf_sql_wide(570)) >= 64 + 3);
}

static void test_readings(void)
{
	CHECK(md9600_rf_rssi_dbm(MD9600_REV_V4, MD9600_VHF, 0) == -135);
	CHECK(md9600_rf_rssi_dbm(MD9600_REV_V1V3, MD9600_UHF, 0x400) == -145 + 32);
	CHECK(md9600_rf_rssi_dbm(MD9600_REV_V5, MD9600_UHF, 0x400) == -155 + 64 * 100 / 195);
	// Uncalibrated: raw / 16
	CHECK(md9600_rf_noise(0x800, 0, 0) == 0x80);
	// Calibrated, either direction: level 1's line maps to 64, level 9's to 40
	CHECK(md9600_rf_noise(2400, 2400, 1600) == 64 && md9600_rf_noise(1600, 2400, 1600) == 40);
	CHECK(md9600_rf_noise(1600, 1600, 2400) == 64 && md9600_rf_noise(2400, 1600, 2400) == 40);
	CHECK(md9600_rf_noise(0, 2400, 1600) == 0 && md9600_rf_noise(0, 1600, 2400) == 112);
	CHECK(md9600_rf_noise(4095, 2400, 2390) == 255);
	CHECK(strcmp(md9600_rf_err_name(MD9600_RF_E_TX_REV), "rev not set") == 0);
	CHECK(strcmp(md9600_rf_err_name(200), "?") == 0);
}

// --- The RF code's calibration rows (rfcal_md9600.c over cal_md9600.c) on a synthetic table ---

static uint8_t sec[3][256];
static bool sec_ok = true;

bool md9600_flash_read_security(uint8_t reg, uint32_t offset, void *buf, uint32_t len)
{
	if (!sec_ok || reg < 1 || reg > 3 || offset + len > 256) {
		return false;
	}
	memcpy(buf, sec[reg - 1] + offset, len);
	return true;
}

static void cal_put(uint32_t off, uint8_t v, uint32_t n)
{
	for (uint32_t i = 0; i < n; i++) {
		sec[(off + i) / 256][(off + i) % 256] = (uint8_t)(v + i);
	}
}

static void test_cal(void)
{
	memset(sec, 0xFF, sizeof(sec));
	md9600_cal_load();
	CHECK(md9600_cal_rf_rows(MD9600_UHF) == 0 && md9600_cal_rf_rows(MD9600_VHF) == 0);
	CHECK(strcmp(md9600_cal_source(), "blank") == 0);
	CHECK(md9600_cal_rx_tune(446000000u) == 2048);
	uint16_t dac, l1, l9;
	CHECK(!md9600_cal_apc(446000000u, 0, &dac) && !md9600_cal_squelch(446000000u, &l1, &l9));

	// Front end, PA rising with the level, squelch rows
	cal_put(0x30, 100, 9);
	cal_put(0x39, 50, 5);
	// The factory PA rows as one radio has them (hardware-md9600.md 5.6): about 10, 14, 25 and 40 W on UHF
	const uint16_t pa_u[4] = { 0x20, 0x1A0, 0x190, 0x10 }, pa_v[4] = { 0x29, 0x1A9, 0x199, 0x19 };
	const uint8_t row_u[4] = { 51, 58, 77, 110 }, row_v[4] = { 62, 67, 71, 110 };
	for (int l = 0; l < 4; l++) {
		cal_put(pa_u[l], row_u[l], 9);
		cal_put(pa_v[l], row_v[l], 5);
	}
	cal_put(0x40, 60, 9);
	cal_put(0x60, 140, 9);
	cal_put(0xE0, 70, 5);
	cal_put(0xEA, 150, 5);
	md9600_cal_load();
	CHECK(md9600_cal_rf_rows(MD9600_UHF) == (MD9600_CALOK_RX | MD9600_CALOK_PA | MD9600_CALOK_SQL));
	CHECK(md9600_cal_rf_rows(MD9600_VHF) == (MD9600_CALOK_RX | MD9600_CALOK_PA | MD9600_CALOK_SQL));
	CHECK(strcmp(md9600_cal_source(), "factory") == 0);
	CHECK(md9600_cal_rx_tune(400000000u) == 1600 && md9600_cal_rx_tune(405000000u) == 1616);
	CHECK(md9600_cal_rx_tune(136000000u) == 800);
	CHECK(md9600_cal_pa_row(400000000u, 0, &dac) && dac == 51 * 16);
	CHECK(md9600_cal_pa_row(410000000u, 3, &dac) && dac == (110 + 1) * 16);
	CHECK(md9600_cal_pa_row(136000000u, 1, &dac) && dac == 67 * 16 && !md9600_cal_pa_row(136000000u, 4, &dac));
	// The power levels: the low three fixed drives, 25 W between the factory rows around it, the top past the top row
	const uint16_t lv_u[5] = { 456, 509, 680, 1232 + (1760 - 1232) * 8 / 152, 1760 + 337 };
	const uint16_t lv_v[5] = { 880, 892, 947, 1072 + (1136 - 1072) * 67 / 83, 1760 + 45 };
	for (uint8_t l = 0; l < 5; l++) {
		CHECK(md9600_cal_apc(400000000u, l, &dac) && dac == lv_u[l]);
		CHECK(md9600_cal_apc(136000000u, l, &dac) && dac == lv_v[l]);
	}
	CHECK(md9600_cal_apc(410000000u, 4, &dac) && dac == (110 + 1) * 16 + 337);	// the top follows the rows
	CHECK(md9600_cal_apc(410000000u, 0, &dac) && dac == 456);			// the low levels don't
	CHECK(!md9600_cal_apc(446000000u, 5, &dac));
	CHECK(md9600_cal_apc_floor(MD9600_UHF) == 440 && md9600_cal_apc_floor(MD9600_VHF) == 870);
	CHECK(md9600_cal_apc_floor(2) == 0);
	CHECK(md9600_cal_squelch(400000000u, &l1, &l9) && l1 == 140 * 16 && l9 == 60 * 16);

	// A PA row that doesn't rise with the level: transmit has no calibration
	// A top row that puts the top level past the drive limit, or rows so low that 25 W falls under 5 W's fixed drive:
	// no level transmits
	cal_put(0x10, 125, 9);
	md9600_cal_load();
	CHECK(md9600_cal_pa_row(400000000u, 3, &dac) && !md9600_cal_apc(400000000u, 0, &dac));
	cal_put(0x10, 110, 9);
	cal_put(0x1A0, 30, 9);
	cal_put(0x190, 35, 9);
	cal_put(0x10, 40, 9);
	cal_put(0x20, 25, 9);
	md9600_cal_load();
	CHECK((md9600_cal_rf_rows(MD9600_UHF) & MD9600_CALOK_PA) && !md9600_cal_apc(400000000u, 2, &dac));
	for (int l = 0; l < 4; l++) {
		cal_put(pa_u[l], row_u[l], 9);
	}
	md9600_cal_load();
	CHECK(md9600_cal_apc(400000000u, 4, &dac));
	sec[1][0xA0 + 4] = (uint8_t)(51 + 4);	// the second row at 440 MHz down to the first row's value
	md9600_cal_load();
	CHECK(!(md9600_cal_rf_rows(MD9600_UHF) & MD9600_CALOK_PA) && !md9600_cal_apc(446000000u, 0, &dac));
	CHECK((md9600_cal_rf_rows(MD9600_UHF) & MD9600_CALOK_RX) && (md9600_cal_rf_rows(MD9600_VHF) & MD9600_CALOK_PA));
	CHECK(md9600_cal_apc(136000000u, 0, &dac));	// the other band's rows still count
	// The flash unreadable
	sec_ok = false;
	md9600_cal_load();
	CHECK(md9600_cal_rf_rows(MD9600_UHF) == 0 && strcmp(md9600_cal_source(), "unreadable") == 0);
	CHECK(!md9600_cal_squelch(446000000u, &l1, &l9));
	sec_ok = true;
}

// --- The diagnostics page's revision lines (rev_md9600.c): every state fits the 128x64 panel's 25 characters ---

static void test_rev_text(void)
{
	char buf[64];
	size_t longest = 0;
	for (int r = MD9600_REV_UNKNOWN; r <= MD9600_REV_COUNT; r++) {
		for (uint8_t src = 0; src <= 5; src++) {
			for (int f = 0; f < 16; f++) {
				for (int16_t probe = -1; probe <= MD9600_REV_COUNT; probe++) {
					md9600_rev_state_t st = { (md9600_rev_t)r, src, (f & 1) != 0, (f & 2) != 0,
								  (uint8_t)(f >> 2) };
					for (uint8_t line = 0; line < MD9600_REV_TEXT_LINES; line++) {
						CHECK(md9600_rev_text(line, st, probe, buf, sizeof buf));
						size_t n = strlen(buf);
						CHECK(n > 0 && n <= MD9600_REV_TEXT_MAX);
						longest = n > longest ? n : longest;
					}
				}
			}
		}
	}
	CHECK(longest == 21);	// the longest of all: "Set rev: Adv>Hardware", "rev V4A/V5 detected"
	md9600_rev_state_t st = { MD9600_REV_V5, MD9600_REV_SRC_STORED, false, true, MD9600_IF_UNKNOWN };
	CHECK(md9600_rev_text(0, st, -1, buf, sizeof buf) && strcmp(buf, "rev V4A/V5 unbuilt") == 0);
	st = (md9600_rev_state_t){ MD9600_REV_V5, MD9600_REV_SRC_DEFAULT, true, false, MD9600_IF_UNKNOWN };
	CHECK(md9600_rev_text(0, st, -1, buf, sizeof buf) && strcmp(buf, "rev V4A/V5 default") == 0);
	CHECK(md9600_rev_text(1, st, -1, buf, sizeof buf) && strcmp(buf, "Set rev: Adv>Hardware") == 0);
	CHECK(md9600_rev_text(2, st, -1, buf, sizeof buf) && strcmp(buf, "ak ? probe off") == 0);
	CHECK(md9600_rev_text(2, st, 0, buf, sizeof buf) && strcmp(buf, "ak ? probe none") == 0);
	st = (md9600_rev_state_t){ MD9600_REV_V5, MD9600_REV_SRC_DETECTED, true, true, MD9600_IF_ABSENT };
	CHECK(md9600_rev_text(0, st, -1, buf, sizeof buf) && strcmp(buf, "rev V4A/V5 detected") == 0);
	CHECK(md9600_rev_text(2, st, -1, buf, sizeof buf) && strcmp(buf, "ak no probe off") == 0);
	st.if_chip = MD9600_IF_PRESENT;
	CHECK(md9600_rev_text(2, st, -1, buf, sizeof buf) && strcmp(buf, "ak yes probe off") == 0);
	st.confirmed = false;
	st.confirmed = true;
	CHECK(md9600_rev_text(1, st, -1, buf, sizeof buf) && strcmp(buf, "rev confirmed") == 0);
	// Past the last line; a short buffer is cut, not overrun
	CHECK(!md9600_rev_text(MD9600_REV_TEXT_LINES, st, -1, buf, sizeof buf));
	CHECK(!md9600_rev_text(0, st, -1, buf, 0));
	CHECK(md9600_rev_text(0, st, -1, buf, 5) && strcmp(buf, "rev ") == 0);
}

// --- The hardware option (hwopt_md9600.c) over a fake record and start-up state ---

static md9600_rev_t stored_rev = MD9600_REV_UNKNOWN;
static bool store_ok = true;
static md9600_rev_state_t rev_now;
static int confirms;
static int unconfirms;

md9600_rev_t md9600_flash_rev_load(void)
{
	return stored_rev;
}

bool md9600_flash_rev_store(md9600_rev_t r)
{
	if (store_ok && md9600_rev_desc(r) != NULL) {
		stored_rev = r;
		return true;
	}
	return false;
}

md9600_rev_state_t md9600_rev_state(void)
{
	return rev_now;
}

void md9600_radio_rev_confirm(bool on)
{
	if (on) {
		confirms++;
	} else {
		unconfirms++;
	}
	rev_now.confirmed = on;
}

static void test_hwopt(void)
{
	const hal_hwopt_t *o = &md9600_hwopts[0];
	CHECK(MD9600_HWOPT_COUNT == 1u);
	CHECK(strcmp(o->name, "Board revision") == 0 && o->count == 3 && o->restart && o->state != NULL);

#if CONFIG_MD9600_V1V3 && CONFIG_MD9600_V4
	// An AK2365A answered, nothing stored: the board runs V1-V3 and asks which it is
	rev_now = md9600_rev_resolve(MD9600_REV_UNKNOWN, MD9600_IF_PRESENT, MD9600_REV_UNKNOWN, MD9600_REV_V5);
	CHECK(rev_now.rev == MD9600_REV_V1V3 && !rev_now.confirmed);
	CHECK(o->get() == HWOPT_NONE && o->state() == HWOPT_ST_ASK);
	// V4A / V5 can't be right with an AK2365A
	CHECK(!o->set(2) && stored_rev == MD9600_REV_UNKNOWN && o->state() == HWOPT_ST_ASK);
	// The revision running: confirmed at once, no restart
	CHECK(o->set(0) && stored_rev == MD9600_REV_V1V3 && o->get() == 0 && confirms == 1);
	CHECK(o->state() == HWOPT_ST_OK);
	// Another one: applies at the next start, and the running one no longer counts as confirmed
	CHECK(o->set(1) && stored_rev == MD9600_REV_V4 && o->get() == 1 && confirms == 1 && unconfirms == 1);
	CHECK(o->state() == HWOPT_ST_RESTART && !rev_now.confirmed);
	// Back to the running one: confirmed again, no restart
	CHECK(o->set(0) && confirms == 2 && o->state() == HWOPT_ST_OK);
	CHECK(o->set(1) && o->state() == HWOPT_ST_RESTART);
	CHECK(!o->set(3) && stored_rev == MD9600_REV_V4);
	store_ok = false;
	CHECK(!o->set(0) && o->get() == 1);
	store_ok = true;
#endif

	// No AK2365A: V4A / V5 detected, the option hidden whatever is stored
	rev_now = md9600_rev_resolve(MD9600_REV_V4, MD9600_IF_ABSENT, MD9600_REV_UNKNOWN, MD9600_REV_V5);
	CHECK(rev_now.rev == MD9600_REV_V5 && rev_now.confirmed && rev_now.source == MD9600_REV_SRC_DETECTED);
	CHECK(o->state() == HWOPT_ST_HIDDEN);

	// No verdict, nothing stored: the default runs and the radio asks; a stored one counts
	stored_rev = MD9600_REV_UNKNOWN;
	CHECK(o->set(2) && stored_rev == MD9600_REV_V5);	// refreshes the cached record
	stored_rev = MD9600_REV_UNKNOWN;
	rev_now = md9600_rev_resolve(MD9600_REV_UNKNOWN, MD9600_IF_UNKNOWN, MD9600_REV_UNKNOWN, MD9600_REV_V5);
	CHECK(!rev_now.confirmed && o->state() == HWOPT_ST_ASK);
	int before = confirms;
	CHECK(o->set(2) && confirms == before + 1 && o->state() == HWOPT_ST_OK);
}

int main(void)
{
	test_init();
	test_power_up();
	test_rx();
	test_lock();
	test_tx_gates();
#if CONFIG_MD9600_TX
	test_tx();
	test_tx_floor();
	for (int r = MD9600_REV_V1V3; r < MD9600_REV_COUNT; r++) {
		if (md9600_rev_built((md9600_rev_t)r)) {
			check_dmr_tx((md9600_rev_t)r, 446075000u, 0);
			check_dmr_tx((md9600_rev_t)r, 146520000u, 1);
			check_dmr_rx_back((md9600_rev_t)r, 461462500u, 451875000u);
			check_dmr_rx_back((md9600_rev_t)r, 146520000u, 147120000u);
			check_dmr_rx_back((md9600_rev_t)r, 461462500u, 461462500u);	// simplex
			check_dmr_rx_back((md9600_rev_t)r, 146520000u, 146520000u);
		}
	}
#endif
	test_probe();
	test_if_detect();
	test_if_verdict();
	test_readings();
	test_noise_window();
	test_ref_trim();
	test_cal();
	test_hwopt();
	test_rev_text();
	printf("md9600RfSeqTest (TX %s): %s (%d failures)\n", CONFIG_MD9600_TX ? "built" : "not built",
	       failures ? "FAILED" : "passed", failures);
	return failures ? 1 : 0;
}
