# SPDX-License-Identifier: MIT
# Copyright (c) 2026 The RadioFoundry Authors
"""DMR voice call features: private calls, emergency, talker alias, late entry, privacy marking (opt-in RF:
--allow-rf --allow-service-stop; the SDR bench's transmitter is the other station), and the talk target / privacy key
requests over the debug link (radio only, nothing transmits).

Each RF test sends one short call from the bench (a bench_tx voice job) on the DMR test channel and checks the call stack's
counters (dmr_stats) and the call it shows (dmr_call). Pass criteria are in README.md."""
import time

import pytest

from rfoundry_hil import counter_deltas, skip
from hil_config import rig

BENCH_SRC = 9990301
STATS = ["call.rx_calls", "call.rx_calls_played", "call.rx_late_entries", "call.rx_voice_bursts",
         "call.rx_enc_dropped", "call.rx_private_calls", "call.rx_emergency_calls", "call.rx_encrypted_calls",
         "call.rx_alias_complete", "call.rx_pi_headers", "call.rx_term_dropped", "call.rx_gps"]


def _on_dmr_channel(radio, pytestconfig):
    if "DMR" not in radio.features():
        skip("not_built", "built without DMR")
    freq = rig(pytestconfig, "dmr-freq")
    radio.go_home()
    radio.find_channel(round(freq * 1e6), "dmr")
    time.sleep(1.0)


def _bench_call(radio, sdr_bench, pytestconfig, **kw):
    """One bench call with the given a bench_tx voice job options; returns (counter deltas, dmr + dmr_call view)."""
    freq, cc, tg = (pytestconfig.getoption(o) for o in ("--dmr-freq", "--dmr-cc", "--dmr-tg"))
    kw.setdefault("dst", tg)
    kw.setdefault("src", BENCH_SRC)
    kw.setdefault("superframes", 4)
    radio.reset_counters()
    _, before = radio.counters()
    with sdr_bench.lease():
        sdr_bench.voice_call(freq, cc, **kw)
    time.sleep(1.0)                      # the call ends (terminator or fade) and the view settles
    _, after = radio.counters()
    d = counter_deltas(before, after, STATS)
    v = radio.view(["dmr", "dmr_call"])
    print("radio deltas:", d)
    print("view:", {k: v[k] for k in v if k.startswith(("call.", "last.", "dmr.target", "dmr.reply"))})
    return d, v


def _print_lc_trace(radio):
    """The HR_C6000 sticky LC trace of the last reception (DM-1701 and the other HR_C6000 radios; nothing elsewhere):
    the dle lines of the debug link log (capture, then every look at the LC page until the call's LC was taken) and
    the lc / lc2 / lt diagnostics lines."""
    _, text = radio.log()
    for line in text.splitlines():
        if " dle " in f" {line}":
            print("  " + line)
    _, lines = radio.link.diag()
    for line in lines:
        if line.split()[:1] in (["lc"], ["lc2"], ["lt"]):
            print("  " + line)


@pytest.mark.feature("dmr_voice")
@pytest.mark.rf
@pytest.mark.bench_service
@pytest.mark.bench_modem
def test_private_call_to_us(radio, sdr_bench, pytestconfig):
    """A private call to our ID: played, shown as to us, and the reply window points back at the caller."""
    _on_dmr_channel(radio, pytestconfig)
    own = int(radio.view(["dmr"])["dmr.own_id"])
    if own == 0:
        skip("state", "no DMR ID in the codeplug")
    d, v = _bench_call(radio, sdr_bench, pytestconfig, dst=own, private=True)
    assert d["call.rx_calls"] == 1 and d["call.rx_private_calls"] == 1 and d["call.rx_calls_played"] == 1, d
    assert v["last.src"] == str(BENCH_SRC) and v["last.to_us"] == "1" and v["last.group"] == "0", v
    # The reply window (codeplug private hang, else 10 s) is likely still open one second later
    if v.get("dmr.reply_active") == "1":
        assert v["dmr.target_id"] == str(BENCH_SRC) and v["dmr.target_private"] == "1", v


@pytest.mark.feature("dmr_voice")
@pytest.mark.rf
@pytest.mark.bench_service
@pytest.mark.bench_modem
def test_private_call_to_other(radio, sdr_bench, pytestconfig):
    """A private call between two other radios: counted (and shown while it lasts) but never played."""
    _on_dmr_channel(radio, pytestconfig)
    d, _ = _bench_call(radio, sdr_bench, pytestconfig, dst=9991234, private=True)
    assert d["call.rx_calls"] == 1 and d["call.rx_private_calls"] == 1 and d["call.rx_calls_played"] == 0, d
    assert d["call.rx_voice_bursts"] == 0, d


@pytest.mark.feature("dmr_emergency")
@pytest.mark.rf
@pytest.mark.bench_service
@pytest.mark.bench_modem
def test_emergency_call(radio, sdr_bench, pytestconfig):
    """The emergency service option is flagged on the call and counted."""
    _on_dmr_channel(radio, pytestconfig)
    try:
        d, v = _bench_call(radio, sdr_bench, pytestconfig, emergency=True)
    finally:
        radio.go_home()  # the heard call raises the emergency screen; go_home acknowledges it
    assert d["call.rx_calls"] == 1 and d["call.rx_emergency_calls"] == 1, d
    assert v["last.emergency"] == "1", v


@pytest.mark.feature("dmr_talker_alias")
@pytest.mark.rf
@pytest.mark.bench_service
@pytest.mark.bench_modem
def test_talker_alias(radio, sdr_bench, pytestconfig):
    """A talker alias in the odd superframes (ISO 8-bit) is assembled and shown."""
    _on_dmr_channel(radio, pytestconfig)
    if "DMR_TALKER_ALIAS" not in radio.features():
        skip("not_built", "built without CONFIG_DMR_TALKER_ALIAS")
    alias = f"RadioFoundry HIL {rig(pytestconfig, 'callsign')}"[:31]
    d, v = _bench_call(radio, sdr_bench, pytestconfig, talker_alias=alias, superframes=10)
    assert d["call.rx_calls"] == 1 and d["call.rx_alias_complete"] == 1, d
    assert v["call.alias"] == alias and v["call.alias_complete"] == "1", v


@pytest.mark.feature("dmr_gps")
@pytest.mark.rf
@pytest.mark.bench_service
@pytest.mark.bench_modem
def test_gps_info(radio, sdr_bench, pytestconfig):
    """An ETSI GPS Info LC (FLCO 8) after a talker alias in the odd superframes: the caller's position on the call
    (call.gps_*), kept with the last heard; one step of the fields is 1.1e-5 degree."""
    _on_dmr_channel(radio, pytestconfig)
    if "DMR_GPS" not in radio.features():
        skip("not_built", "built without CONFIG_DMR_GPS")
    lat, lon = 33.7490, -84.3880
    d, v = _bench_call(radio, sdr_bench, pytestconfig, talker_alias="RadioFoundry GPS", gps=(lat, lon, 1), superframes=10)
    assert d["call.rx_calls"] == 1 and d["call.rx_gps"] >= 1, d
    assert v["last.gps_valid"] == "1" and v["last.gps_err"] == "1", v
    assert abs(float(v["last.gps_lat"]) - lat) < 2e-5 and abs(float(v["last.gps_lon"]) - lon) < 2e-5, v


@pytest.mark.feature("dmr_voice")
@pytest.mark.rf
@pytest.mark.bench_service
@pytest.mark.bench_modem
def test_late_entry(radio, sdr_bench, pytestconfig):
    """No header and the first 8 of 36 bursts left out: the call is taken from the embedded LC (one call, marked late).
    The radio hears from burst C of the second superframe, but takes voice only from a burst A on, so the first
    embedded LC it can assemble is the third superframe's (bursts 14-17): played from its F (burst 18, 19 bursts) if
    the modem has it in its LC page by F's report, else from the next A (burst 19, 18 bursts). A call with the same LC
    as the one before (the same talker again) can't be told from the modem's sticky LC buffer at first: taken at the
    burst A after the reception's first whole superframe, 12 or 13 bursts (HIL 2026-11-14: 8 on the HR_C5000 while
    the driver waited for the second F). HIL 2026-10-10: 7 on aa79493 (the stack waited a superframe more on top of
    the driver's rule), 13 for the new LC on c8c9b23 (the page still held the old LC at F's report).
    The modem's LC trace (dle log lines, lc / lc2 / lt diagnostics) is printed for each late call."""
    _on_dmr_channel(radio, pytestconfig)
    _bench_call(radio, sdr_bench, pytestconfig, src=BENCH_SRC + 1)    # another LC first: the next one is new
    radio.log()                                                        # empty the log ring
    d, v = _bench_call(radio, sdr_bench, pytestconfig, late=8, superframes=6)
    _print_lc_trace(radio)
    assert d["call.rx_calls"] == 1 and d["call.rx_late_entries"] == 1 and d["call.rx_calls_played"] == 1, d
    assert 18 <= d["call.rx_voice_bursts"] <= 20, d
    assert v["call.late_entry"] == "1" and v["last.src"] == str(BENCH_SRC), v
    radio.log()
    d, v = _bench_call(radio, sdr_bench, pytestconfig, late=8, superframes=6)    # the same LC again
    _print_lc_trace(radio)
    assert d["call.rx_calls"] == 1 and d["call.rx_late_entries"] == 1 and d["call.rx_calls_played"] == 1, d
    # 12-13 with a sticky LC buffer (HR_C6000, HR_C5000); a modem that hands over only LCs it assembled has no stale
    # LC to wait out
    assert 12 <= d["call.rx_voice_bursts"] <= 14 or 18 <= d["call.rx_voice_bursts"] <= 20, d
    assert v["last.src"] == str(BENCH_SRC), v


@pytest.mark.feature("dmr_privacy")
@pytest.mark.rf
@pytest.mark.bench_service
@pytest.mark.bench_modem
def test_privacy_service_option(radio, sdr_bench, pytestconfig):
    """A call with the privacy service option: without a key every burst is dropped (never played); with a basic
    privacy key loaded the bursts go through the privacy hook to the vocoder. The bench doesn't scramble, so the
    audio itself is noise either way: this checks the path, not the cipher (dmrCallTest does that)."""
    _on_dmr_channel(radio, pytestconfig)
    if "DMR_PRIVACY" not in radio.features():
        skip("not_built", "built without CONFIG_DMR_PRIVACY")
    radio.link.dmr_privacy("off")
    d, v = _bench_call(radio, sdr_bench, pytestconfig, service_options=0x40)
    assert d["call.rx_calls"] == 1 and d["call.rx_encrypted_calls"] == 1, d
    assert d["call.rx_voice_bursts"] == 0 and d["call.rx_enc_dropped"] >= 20, d
    assert v["last.encrypted"] == "1", v
    with radio.debuglink_privacy():
        radio.link.dmr_privacy("moto", 1)
        radio.wait_for(lambda x: x.get("dmr.privacy") == "1", sections=("dmr",), what="privacy key loaded")
        d, v = _bench_call(radio, sdr_bench, pytestconfig, service_options=0x40)
        assert d["call.rx_calls"] == 1 and d["call.rx_enc_dropped"] == 0 and d["call.rx_voice_bursts"] >= 22, d


@pytest.mark.feature("dmr_voice")
@pytest.mark.rf
@pytest.mark.bench_service
@pytest.mark.bench_modem
def test_pi_bit(radio, sdr_bench, pytestconfig):
    """The EMB PI bit on B-F. The HR_C6000 reports PI unreliably for voice, so its driver clears it (gotcha 6.4):
    on the DM-1701 the call plays as clear. Recorded, not asserted beyond one call heard."""
    _on_dmr_channel(radio, pytestconfig)
    d, _ = _bench_call(radio, sdr_bench, pytestconfig, pi=True)
    assert d["call.rx_calls"] == 1, d


@pytest.mark.feature("dmr_voice")
def test_talk_target_requests(radio, pytestconfig):
    """Radio only (nothing transmits): a typed private ID, a contact and back to the channel's talk target; the
    privacy key request. Every change shows in the dmr view."""
    _on_dmr_channel(radio, pytestconfig)
    L = radio.link
    base = radio.view(["dmr"])
    try:
        L.dmr_target(9990555, private=True)
        v = radio.wait_for(lambda x: x.get("dmr.target_manual") == "1", sections=("dmr",), what="manual target")
        assert v["dmr.target_id"] == "9990555" and v["dmr.target_private"] == "1", v
        L.dmr_target(91, private=False)
        v = radio.wait_for(lambda x: x.get("dmr.target_id") == "91", sections=("dmr",), what="TG 91")
        assert v["dmr.target_private"] == "0" and v["dmr.target_manual"] == "1", v
        L.dmr_target_clear()
        v = radio.wait_for(lambda x: x.get("dmr.target_manual") == "0", sections=("dmr",), what="target cleared")
        assert v["dmr.target_id"] == base["dmr.target_id"], v
        if "DMR_PRIVACY" in radio.features():
            with radio.debuglink_privacy():
                L.dmr_privacy("anytone", 0x1234)
                radio.wait_for(lambda x: x.get("dmr.privacy") == "1", sections=("dmr",), what="privacy on")
            radio.wait_for(lambda x: x.get("dmr.privacy") == "0", sections=("dmr",), what="privacy off")
    finally:
        L.dmr_target_clear()
        if "DMR_PRIVACY" in radio.features():
            L.dmr_privacy("off")


def _features(radio):
    return radio.view(["features"])


@pytest.mark.feature("beep")
@pytest.mark.rf
@pytest.mark.bench_service
@pytest.mark.bench_modem
def test_call_end_tone_setting(radio, sdr_bench, pytestconfig):
    """Settings > Sound > Call end tone: a call heard ends with the call end tone when it is on, and with no tone when
    it is off (the setting's bit in beep.tones_off, set with the SETTING op; the tone counted by beep.played). The
    setting and the tone volume are put back afterwards."""
    _on_dmr_channel(radio, pytestconfig)
    f = _features(radio)
    if f.get("beep.built") != "1":
        skip("not_built", "built without the beeps")
    tones = radio.view(["audio"]).get("beep.tones_off")
    if tones is None:
        skip("not_built", "firmware without the Settings > Sound tone settings (beep.tones_off)")
    was_off, was_level = int(tones), int(f["set.beep_level"])
    L = radio.link
    played = {}
    try:
        if was_level == 0:              # tone volume 0 mutes every tone: the setting couldn't show
            L.setting("beep_level", 50)
        for on in (False, True):
            want = was_off & ~1 if on else was_off | 1      # bit 0: the call end tone
            L.setting("tones_off", want)
            radio.wait_for(lambda x: x.get("beep.tones_off") == str(want), timeout=5, sections=("audio",),
                           what="the call end tone setting")
            # _bench_call resets the counters before the call, beep.played with them: count from there (HIL
            # 2026-11-14: read before it, a tone from earlier showed as -1)
            d, _ = _bench_call(radio, sdr_bench, pytestconfig, superframes=3)
            assert d["call.rx_calls"] == 1, d
            deadline = time.monotonic() + 4.0           # the tone follows the call's end
            while True:
                n = int(_features(radio)["beep.played"])
                if n or time.monotonic() > deadline:
                    break
                time.sleep(0.2)
            played[on] = n
        print("beeps after the call, tone off / on:", played[False], played[True])
        assert played[False] == 0, f"{played[False]} tone(s) after a call with the call end tone off"
        assert played[True] >= 1, "no call end tone after a call with the tone on"
    finally:
        L.setting("tones_off", was_off)
        if was_level == 0:
            L.setting("beep_level", 0)
