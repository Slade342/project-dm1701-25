// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The RadioFoundry Authors
// The reference trim setting (core/radio/ref_trim.c, docs/spec/radio-features.md 6.1): ppb clamped to +-10000 and
// rounded to 100 ppb (0.1 ppm) steps, then handed to the board's hal_radio_t.ref_trim; without the hook only stored
#include <stdio.h>
#include "radio/ref_trim.h"

static int failures;

#define CHECK(cond) do { if (!(cond)) { printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); failures++; } } while (0)

static hal_radio_t radio;
const board_t board = { .radio = &radio };

static int hook_calls;
static int16_t hook_ppb;
static bool hook_retune;	// what the hook answers: the board takes it at the next tune

static bool hook(int16_t ppb)
{
	hook_calls++;
	hook_ppb = ppb;
	return hook_retune;
}

int main(void)
{
	CHECK(radio_ref_trim() == 0);
	CHECK(ref_trim_clamp(0) == 0 && ref_trim_clamp(-2100) == -2100 && ref_trim_clamp(10000) == 10000);
	CHECK(ref_trim_clamp(149) == 100 && ref_trim_clamp(150) == 200 && ref_trim_clamp(-149) == -100);
	CHECK(ref_trim_clamp(-150) == -200 && ref_trim_clamp(49) == 0 && ref_trim_clamp(-49) == 0);
	CHECK(ref_trim_clamp(10001) == 10000 && ref_trim_clamp(-9950) == -10000 && ref_trim_clamp(-40000) == -10000);
	CHECK(ref_trim_clamp(32767) == 10000);

	// What the page shows: -4.5 ppm is -1980 Hz at 440 MHz and -648 Hz at 144 MHz; 0.1 ppm is 14.4 Hz at 144 MHz
	CHECK(ref_trim_hz_at(-4500, 440) == -1980 && ref_trim_hz_at(-4500, 144) == -648);
	CHECK(ref_trim_hz_at(100, 144) == 14 && ref_trim_hz_at(-100, 145) == -15 && ref_trim_hz_at(0, 440) == 0);
	CHECK(ref_trim_hz_at(10000, 480) == 4800 && ref_trim_hz_at(-10000, 480) == -4800);

	// A board that trims by retuning: the synthesizer frequency, within about 1 Hz of f x (1 + trim)
	CHECK(ref_trim_tune_hz(439125000u, 0) == 439125000u);
	CHECK(ref_trim_tune_hz(439125000u, -4500) == 439125000u - 1976u);	// 1976.1 Hz
	CHECK(ref_trim_tune_hz(439125000u, 10000) == 439125000u + 4391u);	// 4391.3 Hz
	CHECK(ref_trim_tune_hz(145525000u, 100) == 145525000u + 15u);		// 14.55 Hz
	CHECK(ref_trim_tune_hz(520000000u, -10000) == 520000000u - 5200u);	// the top of the bands, no overflow

	// No board hook: no setting, the value is only kept
	CHECK(!ref_trim_available());
	CHECK(!radio_set_ref_trim(-2000));
	CHECK(radio_ref_trim() == -2000 && hook_calls == 0);

	// The board's trim gets the clamped, rounded value; the answer is the board's (a retune wanted or not)
	radio.ref_trim = hook;
	CHECK(ref_trim_available());
	hook_retune = true;
	CHECK(radio_set_ref_trim(-2140));
	CHECK(hook_calls == 1 && hook_ppb == -2100 && radio_ref_trim() == -2100);
	// The same trim again (every start applies the settings, often 0): not handed on, no retune
	CHECK(!radio_set_ref_trim(-2100) && !radio_set_ref_trim(-2080) && hook_calls == 1);
	hook_retune = false;
	CHECK(!radio_set_ref_trim(30000));
	CHECK(hook_calls == 2 && hook_ppb == 10000 && radio_ref_trim() == 10000);
	hook_retune = true;
	CHECK(radio_set_ref_trim(0));
	CHECK(hook_calls == 3 && hook_ppb == 0 && radio_ref_trim() == 0);

	if (failures) {
		printf("refTrimTest: %d failures\n", failures);
		return 1;
	}
	printf("refTrimTest: all passed\n");
	return 0;
}
