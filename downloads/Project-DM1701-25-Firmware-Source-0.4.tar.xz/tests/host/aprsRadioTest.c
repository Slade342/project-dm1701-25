// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The RadioFoundry Authors
// APRS through the radio core (docs/spec/aprs.md 6, 7, 9): the engine (core/aprs/aprs.c) and radio_sm.c's APRS block
// in an FM-only build, against a fake board with an AFSK transmitter whose tones are decoded back to AX.25 frames.
// Defaults (nothing sent), the amateur and callsign rules, beacon triggers and the hard minimum, CSMA on a busy
// channel, PTT cutting a transmission short, return to the channel, KISS frames from the host, NMEA from the host,
// messages with retries and acks, the station list, the digipeater and the iGate rules.
#include <stdio.h>
#include <string.h>
#include "board.h"
#include "radio/radio_sm.h"
#include "settings/settings.h"
#include "aprs/aprs.h"
#include "aprs/aprs_host.h"
#include "aprs/aprs_beacon.h"
#include "aprs/aprs_fmt.h"
#include "aprs/ax25.h"
#include "aprs/hdlc.h"
#include "aprs/kiss.h"
#include "aprs/afsk.h"
#include "radio/tx_limit.h"
#include "codeplug/codeplug_kv.h"	// the settings area fakes
#include "fuzz.h"
#include "ui/ui_svc_aprs.h"

static int failures;
static int checks;
#define CHECK(c) do { checks++; if (!(c)) { failures++; printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #c); } } while (0)

#define CH_HZ		146520000u
#define CH2_HZ		146050000u
#define APRS_HZ		144390000u

// ---- fake board ----
static struct {
	uint32_t rx_hz;
	int tx_calls;
	uint32_t tx_hz;
	uint8_t tx_power;
	int tx_off_calls;
	bool keyed;
	uint16_t tone_hz;	// the TX tone in force (0 = the microphone)
	uint8_t noise_on_aprs;	// noise reading on 144.390 (low = a carrier)
	// AFSK
	uint8_t tones[600];
	uint16_t nbits;
	int starts, stops;
	uint32_t afsk_end_ms;
	bool afsk_busy;
	uint8_t level;
	// Faults
	bool tx_fail;		// the transmitter won't key
	bool afsk_fail;		// the AFSK transmitter won't start
	bool afsk_stuck;	// ... or never finishes
} hw;

static uint32_t now;
uint32_t hal_millis(void) { return now; }	// ui_svc_aprs.c
static char frames[8][AX25_TNC2_MAX];	// what went out, decoded from the tones
static int nframes;

static void r_init(void) {}
static void r_set_mode(radio_mode_t m) { (void)m; }
static bool r_rx(uint32_t hz, radio_bw_t bw, const subtone_t *t)
{
	(void)bw;
	(void)t;
	hw.rx_hz = hz;
	return true;
}
static bool r_tx(uint32_t hz, radio_bw_t bw, uint8_t p, const subtone_t *t)
{
	(void)bw;
	(void)t;
	if (hw.tx_fail) {
		return false;
	}
	hw.tx_calls++;
	hw.tx_hz = hz;
	hw.tx_power = p;
	hw.keyed = true;
	return true;
}
static void r_tx_off(void)
{
	hw.tx_off_calls++;
	hw.keyed = false;
}
static void r_status(radio_status_t *st)
{
	st->noise = hw.rx_hz == APRS_HZ ? hw.noise_on_aprs : 120;
	st->rssi_dbm = -120;
	st->carrier = false;
	st->tone_ok = true;
}
static void r_audio(bool on) { (void)on; }
static bool r_tone(uint16_t hz)
{
	hw.tone_hz = hz;
	return true;
}
static const hal_radio_t fake_radio = {
	.init = r_init, .set_mode = r_set_mode, .rx = r_rx, .tx = r_tx, .tx_off = r_tx_off, .status = r_status,
	.audio = r_audio, .tx_tone = r_tone,
};

static void p_led(uint8_t which, bool on) { (void)which; (void)on; }
static uint16_t p_battery_mv(void) { return 7600; }
static uint8_t p_battery_pct(void) { return 80; }
static uint8_t p_mic(void) { return 0; }
static const hal_power_t fake_power = {
	.led = p_led, .battery_mv = p_battery_mv, .battery_pct = p_battery_pct, .mic_level = p_mic,
};

// The tones back to frames, as a receiver would
static void decode_tones(void)
{
	hdlc_dec_t d;
	hdlc_dec_init(&d);
	for (uint32_t i = 0; i < hw.nbits; i++) {
		size_t n = hdlc_dec_bit(&d, hdlc_tone_bit(hw.tones, i));
		ax25_frame_t f;
		if (n != 0 && nframes < 8 && ax25_decode(d.buf, n, &f)) {
			ax25_to_tnc2(&f, frames[nframes++], AX25_TNC2_MAX);
		}
	}
}

static bool a_tx_start(const uint8_t *t, uint16_t n, uint16_t baud, uint16_t mark, uint16_t space, uint8_t level)
{
	if (hw.afsk_fail || !hw.keyed || baud != 1200 || mark != 1200 || space != 2200 || (n + 7u) / 8u > sizeof(hw.tones)) {
		return false;
	}
	memcpy(hw.tones, t, (n + 7u) / 8u);
	hw.nbits = n;
	hw.level = level;
	hw.starts++;
	hw.afsk_busy = true;
	hw.afsk_end_ms = now + (uint32_t)n * 1000u / 1200u;
	decode_tones();
	return true;
}
static bool a_tx_busy(void)
{
	if (hw.afsk_busy && !hw.afsk_stuck && (int32_t)(now - hw.afsk_end_ms) >= 0) {
		hw.afsk_busy = false;
	}
	return hw.afsk_busy;
}
static void a_tx_stop(void)
{
	hw.stops++;
	hw.afsk_busy = false;
}
static hal_afsk_t fake_afsk = { .tx_start = a_tx_start, .tx_busy = a_tx_busy, .tx_stop = a_tx_stop };	// a test swaps it

// The PCM stream (no receive path of the AFSK's own): FM receive audio on its input when the tap says so
static struct {
	audio_block_cb_t cb;
	void *ctx;
	int starts, stops;
} pcm;
static bool s_start(audio_block_cb_t cb, void *ctx)
{
	pcm.cb = cb;
	pcm.ctx = ctx;
	pcm.starts++;
	return true;
}
static void s_stop(void)
{
	pcm.cb = NULL;
	pcm.stops++;
}
static void s_speaker(bool on) { (void)on; }
static const hal_audio_t fake_audio = { .start = s_start, .stop = s_stop, .speaker_pcm = s_speaker };
static hal_audio_tap_t fake_tap;	// caps 0: the stream's input is the microphone

// A broadcast receiver on an empty frequency: an APRS job's carrier sense must read the channel receiver on 144.390
static bool bc_on;
static bool b_power(bool on) { bc_on = on; return true; }
static bool b_tune(uint32_t khz) { (void)khz; return bc_on; }
static bool b_seek(bool up) { (void)up; return false; }
static void b_volume(uint8_t level) { (void)level; }
static bool b_status(bcast_status_t *st)
{
	memset(st, 0, sizeof(*st));
	st->rssi = 5;
	return bc_on;
}
static void b_audio(bool on) { (void)on; }
static const hal_bcast_t fake_bcast = {
	.lo_khz = 65000, .hi_khz = 108000, .grid_khz = 50, .power = b_power, .tune = b_tune, .seek = b_seek,
	.volume = b_volume, .status = b_status, .audio = b_audio,
};

#if CONFIG_DUAL_WATCH
static struct {
	bool up, active;
	uint32_t hz;
	int tunes, stops;
} other_rx;

static bool x_tune(const rx2_tune_t *t)
{
	if (!other_rx.up) {
		return false;
	}
	other_rx.hz = t->rx_hz;
	other_rx.tunes++;
	return true;
}
static void x_stop(void) { other_rx.stops++; }
static void x_status(rx2_status_t *st)
{
	memset(st, 0, sizeof(*st));
	st->up = st->tuned = other_rx.up;
	st->active = other_rx.active;
}
static void x_audio(bool on) { (void)on; }
static const hal_rx2_t fake_rx2 = { .tune = x_tune, .stop = x_stop, .status = x_status, .audio = x_audio };
#endif

static const band_t bands[] = {
	{ 136000000, 174000000, true }, { 400000000, 480000000, true }, { 65000000, 108000000, false },
};
static const char *const power_names[] = { "L", "H" };

const board_t board = {
	.name = "fake",
	.caps = CAP_GPS | CAP_BCAST_FM,
	.bands = bands,
	.band_count = 3,
	.power_count = 2,
	.power_names = power_names,
	.power_default = 0,
	.radio = &fake_radio,
	.power = &fake_power,
	.battery_low_mv = 6400,
	.battery_critical_mv = 6000,
	.afsk = &fake_afsk,
	.audio = &fake_audio,
	.audio_tap = &fake_tap,
	.bcast = &fake_bcast,
#if CONFIG_DUAL_WATCH
	.rx2 = &fake_rx2,
#endif
};

// ---- fake codeplug ----
static channel_t chan, chan2;
static zone_t zone;
static char cp_name[CODEPLUG_NAME_LEN + 1];
codeplug_source_t codeplug_source(void) { return CODEPLUG_OPENFW; }
static uint32_t cp_serial = 1;
static char cp_path[2][10];		// the APRS record's path entries
uint32_t codeplug_serial(void) { return cp_serial; }
void codeplug_kv_begin(codeplug_kv_cursor_t *c, uint16_t lo, uint16_t hi) { (void)c; (void)lo; (void)hi; }	// no settings area
int codeplug_kv_next(codeplug_kv_cursor_t *c, uint16_t *key, void *buf, uint16_t max)
	{ (void)c; (void)key; (void)buf; (void)max; return -1; }
uint8_t codeplug_kv_serial(void) { return 0; }
int codeplug_kv_get(uint16_t key, void *buf, uint16_t max) { (void)key; (void)buf; (void)max; return -1; }
bool codeplug_kv_write(const codeplug_kv_op_t *ops, uint8_t n) { (void)ops; (void)n; return false; }
void storage_lock(void) {}
void storage_unlock(void) {}
void storage_quick_lock(void) {}
void storage_quick_unlock(void) {}
uint16_t codeplug_channel_count(void) { return 2; }
bool codeplug_channel(uint16_t n, channel_t *out)
{
	if (n == 1) {
		*out = chan;
		return true;
	}
	if (n == 2) {
		*out = chan2;
		return true;
	}
	return false;
}
uint16_t codeplug_zone_count(void) { return 1; }
bool codeplug_zones_stored(void) { return true; }
bool codeplug_zone(uint16_t i, zone_t *out)
{
	if (i != 0) {
		return false;
	}
	*out = zone;
	return true;
}
void codeplug_radio_name(char out[CODEPLUG_NAME_LEN + 1]) { memcpy(out, cp_name, sizeof(cp_name)); }
bool codeplug_aprs(uint8_t n, codeplug_aprs_t *out)
{
	memset(out, 0, sizeof(*out));
	if (n != 1) {
		return false;
	}
	strcpy(out->comment, "RadioFoundry test");
	strcpy(out->path[0], cp_path[0]);
	strcpy(out->path[1], cp_path[1]);
	return true;
}
bool codeplug_set_aprs_path(uint8_t n, const char *path1, const char *path2)
{
	if (n != 1) {
		return false;
	}
	strcpy(cp_path[0], path1);
	strcpy(cp_path[1], path2);
	cp_serial++;
	return true;
}
void codeplug_boot_text(char line1[CODEPLUG_NAME_LEN + 1], char line2[CODEPLUG_NAME_LEN + 1])
{
	line1[0] = line2[0] = '\0';
}

// The host link isn't here: aprs_host.c registers with it
#include "hostlink/hostlink.h"
void hostlink_set_tnc(const hostlink_tnc_t *tnc) { (void)tnc; }

// ---- helpers ----
static radio_sm_t sm;

static void run(uint32_t ms)
{
	for (uint32_t t = 0; t < ms; t += RADIO_POLL_MS) {
		now += RADIO_POLL_MS;
		radio_sm_poll(&sm, now);
	}
}

// Run until the AFSK transmitter has started n times in all (CSMA waits a random number of slots)
static bool wait_start(int n, uint32_t max_ms)
{
	for (uint32_t t = 0; t < max_ms && hw.starts < n; t += RADIO_POLL_MS) {
		run(RADIO_POLL_MS);
	}
	return hw.starts >= n;
}

// ... and until it is back on the channel
static void wait_idle(void)
{
	for (int i = 0; i < 400 && (sm.aprs_phase != 0 || hw.keyed); i++) {
		run(RADIO_POLL_MS);
	}
}

static void req(uint8_t type, int32_t arg)
{
	radio_req_t r = { type, arg, 0 };
	radio_sm_request(&sm, &r, now);
}

static void reset(void)
{
	memset(&hw, 0, sizeof(hw));
#if CONFIG_DUAL_WATCH
	memset(&other_rx, 0, sizeof(other_rx));
#endif
	hw.noise_on_aprs = 120;
	nframes = 0;
	memset(frames, 0, sizeof(frames));
	now = 1000;
	memset(&chan, 0, sizeof(chan));
	strcpy(chan.name, "Home");
	chan.rx_hz = chan.tx_hz = CH_HZ;
	chan.mode = RADIO_MODE_FM;
	chan.bw = RADIO_BW_25K;
	chan.power = CODEPLUG_POWER_DEFAULT;
	chan2 = chan;
	strcpy(chan2.name, "Other");
	chan2.rx_hz = chan2.tx_hz = CH2_HZ;
	memset(&zone, 0, sizeof(zone));
	strcpy(zone.name, "Z");
	zone.count = 1;
	zone.channels[0] = 1;
	strcpy(cp_name, "");
	strcpy(cp_path[0], "WIDE1-1");
	strcpy(cp_path[1], "WIDE2-1");
	settings_init();
	radio_sm_init(&sm, now);
	aprs_set_test_call("");
}

// The fixed position (the position service's setting)
static void fixed_position(int32_t lat, int32_t lon)
{
	position_cfg_t pc;
	position_get_cfg(&pc);
	pc.fix_lat = lat;
	pc.fix_lon = lon;
	position_set_cfg(&pc, now);
}

// The settings read again, as the radio core does when they were replaced (RREQ_RELOAD)
static void reload_settings(void)
{
	settings_t st;
	settings_read(&st);
	position_load(&st);
	aprs_reload();
}

// Callsign, a fixed position, automatic beacons every interval_s
static void configure(uint16_t interval_s, bool smart)
{
	aprs_cfg_t c;
	fixed_position(490583333, -720291667);	// 49 03.50 N, 072 01.75 W
	aprs_get_cfg(&c);
	c.tx_on = true;
	c.interval_s = interval_s;
	c.smart = smart;
	c.compressed = false;
	aprs_set_cfg(&c, now);
}

static bool host_out_has(const char *needle)
{
	static uint8_t buf[2048];
	size_t n = aprs_host_output(buf, sizeof(buf) - 1);
	buf[n] = 0;
	for (size_t i = 0; i + strlen(needle) <= n; i++) {
		if (memcmp(buf + i, needle, strlen(needle)) == 0) {
			return true;
		}
	}
	return false;
}

static void rx_line(const char *tnc2)
{
	ax25_frame_t f;
	uint8_t buf[AX25_FRAME_MAX];
	CHECK(ax25_from_tnc2(tnc2, strlen(tnc2), &f));
	f.dst.h = true;
	size_t n = ax25_encode(&f, buf, sizeof(buf));
	aprs_rx_frame(buf, n, now);
}

// ---- tests ----

static void test_defaults(void)
{
	reset();
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(v.block == APRS_NO_CALL);		// no callsign in the settings or the codeplug
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	CHECK(!c.tx_on && c.region == APRS_REGION_NA && aprs_cfg_freq(&c) == APRS_HZ && c.ssid == 7);
	// Callsign and a position, but transmit off: nothing in an hour
	strcpy(cp_name, "Q1TST");
	fixed_position(490583333, -720291667);
	aprs_set_cfg(&c, now);
	run(3600u * 1000u);
	CHECK(hw.tx_calls == 0 && hw.starts == 0);
	aprs_get_view(&v);
	CHECK(v.block == APRS_OK && strcmp(v.call, "Q1TST-7") == 0 && v.pos_valid && v.pos_src == POSITION_SRC_FIXED);
	CHECK(hw.rx_hz == CH_HZ);
	// N0CALL (refused by name) and a name without a digit are no callsign
	CHECK(!aprs_callsign_ok("N0CALL") && !aprs_callsign_ok("QTEST") && !aprs_callsign_ok("1ABC") &&
	      aprs_callsign_ok("Q1ABC") && aprs_callsign_ok("Q2Q0AB") && aprs_callsign_ok("QK2ABC"));
}

static void test_beacon_on_air(void)
{
	reset();
	aprs_set_test_call("q1tst");
	configure(60, false);
	run(59u * 1000u);
	CHECK(hw.starts == 0 && hw.rx_hz == CH_HZ);
	CHECK(wait_start(1, 5000));
	CHECK(hw.tx_calls == 1 && hw.tx_hz == APRS_HZ && hw.starts == 1);
	CHECK(sm.view.state == RS_TX);
	CHECK(sm.view.tx_auto && !radio_view_wakes(&sm.view));	// a timed beacon leaves the screen as it is
	CHECK(nframes == 1);
	CHECK(strcmp(frames[0], "Q1TST-7>APZRDF,WIDE1-1,WIDE2-1:!4903.50N/07201.75W[RadioFoundry test") == 0);
	if (nframes > 0) {
		printf("# on air: %s\n", frames[0]);
	}
	// preamble 300 ms = 45 flags: the first frame bit starts after 360 symbols
	CHECK(hw.nbits > 45u * 8u && hw.level == APRS_LEVEL_DEFAULT);
	wait_idle();
	CHECK(hw.stops == 1 && hw.tx_off_calls == 1 && !hw.keyed && hw.rx_hz == CH_HZ && sm.view.state == RS_IDLE);
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(v.rf_sent == 1 && v.last_why == APRS_WHY_INTERVAL);
	// the next one a minute after that one
	run(55u * 1000u);
	CHECK(hw.starts == 1);
	CHECK(wait_start(2, 8000));
}

// The test TX limit refuses a beacon whose frequency isn't on its list at key-up (APRS_RF_NO_KEY): nothing keyed, the
// radio back on the channel. With the APRS frequency on it, the beacon goes
static void test_tx_limit(void)
{
#if CONFIG_DEBUGLINK
	static const uint32_t ch[] = { CH_HZ }, both[] = { CH_HZ, APRS_HZ };
	tx_limit_info_t l0, l;
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);
	tx_limit_get(&l0, NULL, 0);
	CHECK(tx_limit_set(false, ch, 1));
	CHECK(aprs_send_now());
	run(8000);
	tx_limit_get(&l, NULL, 0);
	CHECK(hw.tx_calls == 0 && !hw.keyed && hw.starts == 0 && hw.rx_hz == CH_HZ);
	CHECK(l.refused == l0.refused + 1 && l.last_hz == APRS_HZ);
	CHECK(tx_limit_set(false, both, 2));
	CHECK(aprs_send_now());
	CHECK(wait_start(1, 8000) && hw.tx_hz == APRS_HZ);
	wait_idle();
	CHECK(tx_limit_set(false, NULL, 0));
#endif
}

static void test_min_interval(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(1, false);	// asks for every second: the hard minimum is 30 s
	run(10u * 60u * 1000u);
	CHECK(hw.starts >= 18 && hw.starts <= 21);
}

static void test_busy_channel(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(60, false);
	hw.noise_on_aprs = 30;	// a carrier on 144.390
	run(61u * 1000u);
	CHECK(hw.rx_hz == APRS_HZ && hw.tx_calls == 0);	// listening
	run(10u * 1000u);
	CHECK(hw.tx_calls == 0 && hw.rx_hz == CH_HZ);	// gave up, back on the channel
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(v.rf_busy == 1);
	hw.noise_on_aprs = 120;
	run(20u * 1000u);	// tried again after the retry wait
	CHECK(hw.starts == 1);
}

// On a broadcast channel the beacon's carrier sense reads the channel receiver on 144.390, not the broadcast one
static void test_bcast_channel(void)
{
	reset();
	chan.rx_hz = chan.tx_hz = 100100000u;
	radio_sm_init(&sm, now);
	aprs_set_test_call("Q1TST");
	configure(60, false);
	hw.noise_on_aprs = 30;	// a carrier on 144.390; the broadcast frequency is empty
	aprs_view_t v;
	aprs_get_view(&v);
	uint32_t busy = v.rf_busy;
	run(61u * 1000u);
	CHECK(sm.view.bcast && hw.rx_hz == APRS_HZ && hw.tx_calls == 0);	// listening, and holding off
	run(10u * 1000u);
	aprs_get_view(&v);
	CHECK(hw.tx_calls == 0 && v.rf_busy == busy + 1);
	CHECK(sm.view.bcast && sm.view.state == RS_RX);	// back on the broadcast channel, listening again
}

static void test_ptt_cuts(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(60, false);
	run(60u * 1000u + 100u);	// on the APRS frequency, listening or keyed
	CHECK(hw.rx_hz == APRS_HZ || hw.keyed);
	req(RREQ_PTT, 1);
	CHECK(sm.view.state == RS_TX && hw.tx_hz == CH_HZ);	// talking on the channel
	run(3000);
	CHECK(hw.starts == 0 || hw.stops >= 1);
	req(RREQ_PTT, 0);
	run(100);
	CHECK(sm.view.state == RS_IDLE && hw.rx_hz == CH_HZ);
	run(20u * 1000u);	// the beacon goes again later
	CHECK(hw.starts >= 1);
}

#if CONFIG_DUAL_WATCH
static void test_dual_watch_beacon(void)
{
	reset();
	zone.count = 2;
	zone.channels[1] = 2;
	radio_sm_init(&sm, now);
	aprs_set_test_call("N0TST");
	configure(0, false);
	radio_req_t watch = { RREQ_SCAN, RSCAN_DUAL, 1 };
	radio_sm_request(&sm, &watch, now);
	CHECK(sm.scan.kind == SCAN_DUAL);
	for (int i = 0; i < 100 && sm.dual_at != 1; i++) {
		run(RADIO_POLL_MS);
	}
	CHECK(sm.dual_at == 1 && hw.rx_hz == CH2_HZ);
	uint32_t steps = sm.scan.steps;
	CHECK(aprs_send_now());
	CHECK(wait_start(1, 5000));
	CHECK(sm.scan.kind == SCAN_DUAL && hw.tx_hz == APRS_HZ && hw.starts == 1);
	wait_idle();
	CHECK(sm.scan.kind == SCAN_DUAL && sm.scan.phase == SCAN_PH_LISTEN &&
	      sm.dual_at == 1 && hw.rx_hz == CH2_HZ && !hw.keyed);
	run(RADIO_SCAN_DWELL_MS + RADIO_POLL_MS);
	CHECK(sm.dual_at == 0 && hw.rx_hz == CH_HZ);
	run(5000);
	CHECK(sm.scan.kind == SCAN_DUAL && sm.scan.steps > steps);
	// PTT still uses the selected channel after a beacon interrupted the watch.
	req(RREQ_PTT, 1);
	CHECK(sm.scan.kind == SCAN_DUAL && hw.tx_hz == CH_HZ);
	req(RREQ_PTT, 0);
	// A regular zone scan still holds a queued packet until the scan stops.
	req(RREQ_SCAN, RSCAN_STOP);
	req(RREQ_SCAN, RSCAN_ZONE);
	CHECK(sm.scan.kind == SCAN_ZONE && aprs_send_now());
	run(5000);
	CHECK(sm.scan.kind == SCAN_ZONE && hw.starts == 1);
	req(RREQ_SCAN, RSCAN_STOP);
	CHECK(wait_start(2, 5000) && hw.tx_hz == APRS_HZ);
	wait_idle();
}

static void test_dual_receiver_beacon(void)
{
	reset();
	zone.count = 2;
	zone.channels[1] = 2;
	radio_sm_init(&sm, now);
	aprs_set_test_call("N0TST");
	configure(0, false);
	other_rx.up = true;
	radio_req_t watch = { RREQ_SCAN, RSCAN_DUAL, 1 };
	radio_sm_request(&sm, &watch, now);
	CHECK(sm.rx2_on && other_rx.hz == CH2_HZ && hw.rx_hz == CH_HZ);
	other_rx.active = true;
	CHECK(aprs_send_now());
	run(5000);
	CHECK(hw.starts == 0 && sm.rx2_on && other_rx.stops == 0);
	int tunes = other_rx.tunes;
	other_rx.active = false;
	CHECK(wait_start(1, 5000));
	CHECK(!sm.rx2_on && other_rx.stops == 1 && hw.tx_hz == APRS_HZ);
	wait_idle();
	CHECK(sm.scan.kind == SCAN_DUAL && sm.scan.phase == SCAN_PH_LISTEN && sm.rx2_on && other_rx.tunes == tunes + 1 &&
	      other_rx.hz == CH2_HZ && hw.rx_hz == CH_HZ);
}

static void test_dual_watch_beacon_abort(void)
{
	reset();
	zone.count = 2;
	zone.channels[1] = 2;
	radio_sm_init(&sm, now);
	aprs_set_test_call("N0TST");
	configure(0, false);
	radio_req_t watch = { RREQ_SCAN, RSCAN_DUAL, 1 };
	radio_sm_request(&sm, &watch, now);
	CHECK(aprs_send_now());
	CHECK(wait_start(1, 5000));
	uint8_t at = sm.dual_at;
	req(RREQ_POWER, 1);	// abort without ending the watch or keying PTT
	CHECK(sm.aprs_phase == 0 && sm.scan.kind == SCAN_DUAL && sm.scan.phase == SCAN_PH_LISTEN && !hw.keyed);
	CHECK(hw.rx_hz == (at == 0 ? CH_HZ : CH2_HZ));
	run(RADIO_SCAN_DWELL_MS + RADIO_POLL_MS);
	CHECK(sm.dual_at != at);
}
#endif
// PTT over a beacon on a channel with its tone burst on: the beacon gives way and the fresh key-up opens with the burst
// (the beacon's RS_TX is the radio's own transmission, not the user's)
static void test_ptt_cuts_burst(void)
{
#if CONFIG_FM_TX_TONES
	reset();
	aprs_set_test_call("Q1TST");
	configure(60, false);
	chan.tone_burst = true;
	req(RREQ_ZONE_POS, 0);
	run(50);
	CHECK(sm.view.ch.tone_burst);
	run(59u * 1000u);
	CHECK(wait_start(1, 5000));
	CHECK(sm.view.state == RS_TX && sm.view.tx_auto && hw.tx_hz == APRS_HZ && hw.tone_hz == 0);
	req(RREQ_PTT, 1);
	CHECK(sm.view.state == RS_TX && !sm.view.tx_auto && hw.tx_hz == CH_HZ);
	CHECK(sm.view.tone_burst && hw.tone_hz == RADIO_BURST_HZ);
	run(RADIO_BURST_MIN_MS + 20);
	radio_sm_tick(&sm, now);	// the burst's timer runs on the tick, which run() doesn't drive
	CHECK(sm.view.state == RS_TX && !sm.view.tone_burst && hw.tone_hz == 0);	// the microphone follows
	req(RREQ_PTT, 0);
	run(300);
	CHECK(sm.view.state == RS_IDLE && hw.rx_hz == CH_HZ);
#endif
}

static void test_not_amateur(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(60, false);
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	c.region = APRS_REGION_CUSTOM;
	c.freq_hz = 150000000u;		// in the radio's band, not amateur
	aprs_set_cfg(&c, now);
	run(10u * 60u * 1000u);
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(v.block == APRS_NOT_AMATEUR && hw.tx_calls == 0);
	// The band edges, 33 cm included
	CHECK(aprs_amateur_hz(144000000u) && aprs_amateur_hz(450000000u) && !aprs_amateur_hz(450000001u));
	CHECK(aprs_amateur_hz(902000000u) && aprs_amateur_hz(927500000u) && aprs_amateur_hz(928000000u));
	CHECK(!aprs_amateur_hz(901999999u) && !aprs_amateur_hz(928000001u));
	c.freq_hz = 144800000u;
	aprs_set_cfg(&c, now);
	run(30u * 1000u);
	CHECK(wait_start(1, 40000) && hw.tx_calls == 1 && hw.tx_hz == 144800000u);
}

static void test_manual_and_ptt_trigger(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);	// no interval
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	c.tx_on = false;
	aprs_set_cfg(&c, now);
	CHECK(aprs_send_now());
	CHECK(wait_start(1, 5000));
	wait_idle();
	// after PTT, with automatic beacons on
	c.tx_on = true;
	c.after_ptt = true;
	aprs_set_cfg(&c, now);
	run(200u * 1000u);
	CHECK(hw.starts == 1);
	req(RREQ_PTT, 1);
	run(2000);
	req(RREQ_PTT, 0);
	CHECK(wait_start(2, 6000));
	wait_idle();
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(v.last_why == APRS_WHY_PTT);
	// again right away: the gap isn't reached
	req(RREQ_PTT, 1);
	run(2000);
	req(RREQ_PTT, 0);
	run(5000);
	CHECK(hw.starts == 2);
#if !CONFIG_APRS_DMR
	// A build without the DMR backend (this one) has one way out: "Send via: DMR" left in the settings by another
	// build is not asked, and the beacon goes out on RF
	c.tx_on = false;
	c.via = APRS_VIA_DMR;
	aprs_set_cfg(&c, now);
	run(200u * 1000u);
	CHECK(aprs_send_now());
	CHECK(wait_start(3, 5000));
	wait_idle();
	aprs_get_view(&v);
	CHECK(v.dmr_sent == 0 && v.dmr_failed == 0);
	c.via = APRS_VIA_RF;
	aprs_set_cfg(&c, now);
#endif
}

// APRS keys at the radio's current power level, a temporary change included (it used the settings' default, so a
// radio stepped down to its lowest level still sent APRS at the default power)
static void test_tx_power(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);
	CHECK(sm.view.power == 0);
	CHECK(aprs_send_now());
	CHECK(wait_start(1, 5000));
	CHECK(hw.tx_power == 0);
	CHECK(sm.view.aprs_tx && sm.view.state == RS_TX);
	wait_idle();
	CHECK(!sm.view.aprs_tx);
	req(RREQ_POWER, 1);		// temporary: H
	CHECK(sm.view.power == 1 && sm.view.temporary);
	run(6000);			// past the 5 s "send now" repeat guard
	CHECK(aprs_send_now());
	CHECK(wait_start(2, 5000));
	CHECK(hw.tx_power == 1);
	CHECK(sm.view.aprs_tx);
	wait_idle();
	CHECK(!sm.view.aprs_tx && sm.view.power == 1 && hw.rx_hz == CH_HZ);
}

// APRS's own power setting (aprs_power, 0 = the radio's level) overrides the radio's current level
static void test_tx_power_own(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	c.power = 2;			// level 2 of 2: H
	aprs_set_cfg(&c, now);
	CHECK(sm.view.power == 0);
	CHECK(aprs_send_now());
	CHECK(wait_start(1, 5000));
	CHECK(hw.tx_power == 1);
	CHECK(sm.view.aprs_tx);
	wait_idle();
	CHECK(!sm.view.aprs_tx && sm.view.power == 0);	// the radio's own level is untouched
	CHECK(aprs_tx_power(0) == 1);
	c.power = 1;
	aprs_set_cfg(&c, now);
	CHECK(aprs_tx_power(1) == 0);
	c.power = 0;
	aprs_set_cfg(&c, now);
	CHECK(aprs_tx_power(1) == 1);
}

static void test_host_kiss_nmea(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	c.kiss = true;
	c.to_is = true;
	c.tx_on = true;
	c.interval_s = 600;
	c.smart = true;
	c.compressed = true;
	aprs_set_cfg(&c, now);
	CHECK(aprs_host_claims(0xC0) && aprs_host_claims('$') && !aprs_host_claims('R'));
	// NMEA from the host: the position, moving at 22.4 kn
	const char *rmc = "$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A\r\n";
	aprs_host_feed((const uint8_t *)rmc, strlen(rmc), now);
	run(100);
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(v.pos_valid && v.pos_src == POSITION_SRC_HOST && v.lat == 481173000 && v.speed_kmh == 41 && v.course == 84);
	// a KISS data frame from the host, from our call (another SSID)
	ax25_frame_t f;
	uint8_t frame[AX25_FRAME_MAX], kiss[2 * AX25_FRAME_MAX];
	const char *line = "Q1TST-9>APRS,WIDE2-1:>from the host";
	CHECK(ax25_from_tnc2(line, strlen(line), &f));
	f.dst.h = true;
	size_t n = ax25_encode(&f, frame, sizeof(frame));
	size_t k = kiss_encode(KISS_CMD_DATA, frame, n, kiss, sizeof(kiss));
	nframes = 0;
	aprs_host_feed(kiss, k, now);
	CHECK(wait_start(hw.starts + 1, 5000));
	wait_idle();
	bool seen = false;
	for (int i = 0; i < nframes; i++) {
		seen = seen || strcmp(frames[i], line) == 0;
	}
	CHECK(seen);
	run(3000);
	// someone else's call: refused
	line = "Q1ABC>APRS:>not ours";
	CHECK(ax25_from_tnc2(line, strlen(line), &f));
	n = ax25_encode(&f, frame, sizeof(frame));
	CHECK(!aprs_host_frame(frame, n, now));
	// the rate limit: a burst of 3, then one per 10 s
	line = "Q1TST>APRS:>burst";
	CHECK(ax25_from_tnc2(line, strlen(line), &f));
	n = ax25_encode(&f, frame, sizeof(frame));
	int ok = 0;
	for (int i = 0; i < 6; i++) {
		ok += aprs_host_frame(frame, n, now) ? 1 : 0;
		run(2000);
	}
	CHECK(ok >= 2 && ok <= 4);
	// our beacon also went to APRS-IS as a 'G' line
	host_out_has("");
	CHECK(aprs_send_now());
	run(1000);
	CHECK(host_out_has("GQ1TST-7>APZRDF,TCPIP*:!/"));	// compressed, no messaging (no receive path)
}

static void test_messages(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);
	CHECK(!aprs_send_message("Q1ABC-9", ""));
	CHECK(!aprs_send_message("not a call", "Hello"));
	CHECK(!aprs_send_message("Q1ABC-9", "Line\nTwo"));
	CHECK(!aprs_send_message(NULL, "Hello"));
	aprs_cfg_t cfg;
	aprs_get_cfg(&cfg);
	aprs_cfg_t bad = cfg;
	bad.region = APRS_REGION_CUSTOM;
	bad.freq_hz = 150000000u;
	aprs_set_cfg(&bad, now);
	CHECK(!aprs_send_message("Q1ABC-9", "Hello"));
	aprs_set_cfg(&cfg, now);
	CHECK(aprs_send_message("Q1ABC-9", "Hello"));
	CHECK(aprs_send_message("Q1ABC-9", "Again"));	// newest message replaces the pending retry
	CHECK(wait_start(1, 5000));
	CHECK(nframes == 1);
	char msgno[8] = "";
	const char *brace = nframes > 0 ? strchr(frames[0], '{') : NULL;
	CHECK(brace != NULL && strstr(frames[0], "::Q1ABC-9  :Again{") != NULL);
	if (brace != NULL) {
		strncpy(msgno, brace + 1, sizeof(msgno) - 1);
	}
	wait_idle();
	run(28u * 1000u);
	CHECK(wait_start(2, 6000));	// no ack: tried again at 30 s
	wait_idle();
#if CONFIG_APRS_RX
	// the ack comes: no third try
	char ack[64];
	snprintf(ack, sizeof(ack), "Q1ABC-9>APRS::Q1TST-7  :ack%s", msgno);
	rx_line(ack);
	run(200u * 1000u);
	CHECK(hw.starts == 2);
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(v.msg_acked || !v.msg_pending);
	// a message to us: kept and acked
	nframes = 0;
	rx_line("Q1ABC-9>APRS,WIDE1-1::Q1TST-7  :Hi there{42");
	CHECK(wait_start(3, 5000));
	wait_idle();
	CHECK(aprs_msg_count() == 1);
	aprs_msg_t m;
	CHECK(aprs_msg(0, &m) && strcmp(m.from, "Q1ABC-9") == 0 && strcmp(m.text, "Hi there") == 0);
	CHECK(nframes == 1 && strstr(frames[0], "::Q1ABC-9  :ack42") != NULL);
	// its retry: acked again, not kept twice
	rx_line("Q1ABC-9>APRS,WIDE1-1::Q1TST-7  :Hi there{42");
	CHECK(wait_start(4, 5000));
	wait_idle();
	CHECK(aprs_msg_count() == 1 && nframes == 2);
#else
	(void)rx_line;
#endif
}

// Messages from APRS-IS reach RF through an iGate as third-party packets ("}SRC>DST,TCPIP,IGATE*:info"): the message
// inside is from SRC, kept and acked to SRC; the station list holds the iGate, the station actually heard
static void test_third_party_messages(void)
{
#if CONFIG_APRS_RX
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);
	nframes = 0;
	rx_line("Q1GTE>APDW17,WIDE2*:}Q1ABC-9>APQRX,TCPIP,Q1GTE*::Q1TST-7  :From the net{77");
	CHECK(wait_start(1, 5000));
	wait_idle();
	CHECK(aprs_msg_count() == 1);
	aprs_msg_t m;
	CHECK(aprs_msg(0, &m) && strcmp(m.from, "Q1ABC-9") == 0 && strcmp(m.text, "From the net") == 0 &&
	      strcmp(m.msgno, "77") == 0);
	CHECK(nframes == 1 && strstr(frames[0], "::Q1ABC-9  :ack77") != NULL);
	// its retry: acked again, not kept twice
	rx_line("Q1GTE>APDW17,WIDE2*:}Q1ABC-9>APQRX,TCPIP,Q1GTE*::Q1TST-7  :From the net{77");
	CHECK(wait_start(2, 5000));
	wait_idle();
	CHECK(aprs_msg_count() == 1 && nframes == 2);
	// the station list: the iGate, not the Internet station (which must not count as heard on RF)
	aprs_station_t s;
	bool gate = false, inner = false;
	for (uint8_t i = 0; aprs_station(i, &s); i++) {
		gate |= strcmp(s.call, "Q1GTE") == 0;
		inner |= strcmp(s.call, "Q1ABC-9") == 0;
	}
	CHECK(gate && !inner);
	// to another station, malformed, our own message gated back, nested: ignored, nothing sent
	rx_line("Q1GTE>APDW17,WIDE2*:}Q1ABC-9>APQRX,TCPIP,Q1GTE*::Q1XYZ    :Not ours{78");
	rx_line("Q1GTE>APDW17,WIDE2*:}garbage");
	rx_line("Q1GTE>APDW17,WIDE2*:}Q1ABC>:");
	rx_line("Q1GTE>APDW17,WIDE2*:}Q1TST-7>APZRDF,TCPIP,Q1GTE*::Q1TST-7  :Echo{79");
	rx_line("Q1GTE>APDW17,WIDE2*:}Q1GTF>APDW17,TCPIP,Q1GTE*:}Q1ABC-9>APQRX,TCPIP,Q1GTF*::Q1TST-7  :Nested{80");
	run(10u * 1000u);
	CHECK(aprs_msg_count() == 1 && nframes == 2 && hw.starts == 2);
	// the ack of our message to an Internet station comes back wrapped too: no more retries
	CHECK(aprs_send_message("Q1ABC-9", "To the net"));
	CHECK(wait_start(3, 5000));
	char msgno[8] = "";
	const char *brace = strchr(frames[nframes - 1], '{');
	CHECK(brace != NULL);
	if (brace != NULL) {
		strncpy(msgno, brace + 1, sizeof(msgno) - 1);
	}
	wait_idle();
	char ack[96];
	snprintf(ack, sizeof(ack), "Q1GTE>APDW17,WIDE2*:}Q1ABC-9>APRS,TCPIP,Q1GTE*::Q1TST-7  :ack%s", msgno);
	rx_line(ack);
	run(200u * 1000u);
	CHECK(hw.starts == 3);
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(v.msg_acked);
#endif
}

static void test_message_options(void)
{
	reset();
	aprs_set_test_call("N0TST");
	configure(0, false);
	fixed_position(0, 0);
	CHECK(!aprs_send_message_opts("K1ABC-9", "Here", APRS_MSG_POSITION));
	fixed_position(490583333, -720291667);
	char long_text[APRS_MSG_TEXT_MAX + 1];
	memset(long_text, 'x', sizeof(long_text) - 1u);
	long_text[sizeof(long_text) - 1u] = '\0';
	CHECK(!aprs_send_message_opts("K1ABC-9", long_text, APRS_MSG_POSITION));
	CHECK(aprs_send_message_opts("K1ABC-9", "Here", APRS_MSG_POSITION));
	CHECK(wait_start(1, 5000));
	CHECK(strstr(frames[0], "::K1ABC-9  :Here @49.0583N 072.0292W") != NULL);
	CHECK(strchr(frames[0], '{') == NULL);
	wait_idle();
	run(200u * 1000u);
	CHECK(hw.starts == 1);
	CHECK(aprs_send_message_opts("K1ABC-9", "Ack me", APRS_MSG_ACK));
	CHECK(wait_start(2, 5000));
	CHECK(strstr(frames[1], "::K1ABC-9  :Ack me{") != NULL);
}

static void test_message_replaces_pending(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);
	CHECK(aprs_send_message("Q1ABC-9", "First"));
	CHECK(wait_start(1, 5000));
	wait_idle();
	CHECK(aprs_send_message("K1ABC-9", "Second"));
	CHECK(wait_start(2, 5000));
	CHECK(strstr(frames[1], "::K1ABC-9  :Second{") != NULL);
	wait_idle();
	run(28u * 1000u);
	CHECK(wait_start(3, 6000));
	CHECK(strstr(frames[2], "::K1ABC-9  :Second{") != NULL);
}

#if CONFIG_APRS_RX
static void test_message_rejection(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);
	CHECK(aprs_send_message("Q1ABC-9", "Hello"));
	CHECK(wait_start(1, 5000));
	const char *brace = strchr(frames[0], '{');
	CHECK(brace != NULL);
	char rej[64];
	snprintf(rej, sizeof(rej), "Q1ABC-9>APRS::Q1TST-7  :rej%s", brace != NULL ? brace + 1 : "");
	wait_idle();
	rx_line(rej);
	run(200u * 1000u);
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(!v.msg_pending && !v.msg_acked);
	CHECK(hw.starts == 1);
	CHECK(aprs_send_message("Q1ABC-9", "Another"));
}
#endif

#if CONFIG_APRS_RX
static void test_stations_digi_igate(void)
{
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	c.digi = 1;		// fill-in
	c.kiss = true;
	c.igate = true;
	c.igate_tx = true;
	aprs_set_cfg(&c, now);
	host_out_has("");
	rx_line("Q1ABC-9>APZRDF,WIDE1-1,WIDE2-1:=4903.50N/07201.75W>Mobile");
	CHECK(aprs_station_count() == 1);
	aprs_station_t s;
	CHECK(aprs_station(0, &s) && strcmp(s.call, "Q1ABC-9") == 0 && s.has_pos && s.direct && s.sym_code == '>');
	// gated to APRS-IS with our q construct; the raw frame to the KISS host too
	CHECK(host_out_has("GQ1ABC-9>APZRDF,WIDE1-1,WIDE2-1,qAR,Q1TST-7:=4903.50N/07201.75W>Mobile"));
	// digipeated (fill-in): our call in the path, used (TNC2 stars the last used entry)
	CHECK(wait_start(1, 5000));
	wait_idle();
	CHECK(nframes == 1 && strcmp(frames[0], "Q1ABC-9>APZRDF,Q1TST-7,WIDE1*,WIDE2-1:=4903.50N/07201.75W>Mobile") == 0);
	// a message from APRS-IS for the station we just heard: to RF as a third-party packet
	nframes = 0;
	const char *is = "Q9WXY>APRS,TCPIP*,qAC,TIER2::Q1ABC-9  :From the net{7";
	aprs_host_is_line(is, strlen(is), now);
	CHECK(wait_start(2, 5000));
	wait_idle();
	CHECK(nframes == 1 && strcmp(frames[0], "Q1TST-7>APZRDF:}Q9WXY>APRS,TCPIP,Q1TST-7*::Q1ABC-9  :From the net{7") == 0);
	// RFONLY stays local
	rx_line("Q2DEF>APRS,RFONLY:>local only");
	CHECK(!host_out_has("Q2DEF"));
}
#endif

#if CONFIG_APRS_RX
static unsigned station_locks, station_unlocks;
static bool station_locked;

static void station_lock(void)
{
	CHECK(!station_locked);
	station_locked = true;
	station_locks++;
}

static void station_unlock(void)
{
	CHECK(station_locked);
	station_locked = false;
	if (++station_unlocks == 2) {
		// Trap for a lookup that locks more than once (the old count-then-rows scan): a packet moves A to the
		// front between reads, so that scan misses A and the find CHECK below fails. One locked copy never gets here.
		aprs_set_lock(NULL, NULL);
		rx_line("Q1ABC-9>APRS:>Moved");
	}
}

static void test_station_lookup(void)
{
	reset();
	rx_line("Q1ABC-9>APRS:>First");
	rx_line("Q1ABC-8>APRS:>Second");
	station_locks = station_unlocks = 0;
	station_locked = false;
	aprs_set_lock(station_lock, station_unlock);
	aprs_station_t s;
	CHECK(ui_svc_aprs_station_find("Q1ABC-9", &s) && strcmp(s.call, "Q1ABC-9") == 0);
	CHECK(station_locks == 1 && station_unlocks == 1 && !station_locked);
	aprs_set_lock(NULL, NULL);
	CHECK(aprs_station_count() == 2);
	CHECK(!ui_svc_aprs_station_find("Q1ABC", &s));
	CHECK(!ui_svc_aprs_station_find("Q1ABC-7", &s));
	CHECK(!ui_svc_aprs_station_find("q1abc-9", &s));
	// The 24-byte retained field holds 23 comment bytes and the terminator.
	rx_line("Q1ABC-9>APRS:=4903.50N/07201.75W>12345678901234567890123EXCESS");
	CHECK(ui_svc_aprs_station_find("Q1ABC-9", &s));
	CHECK(sizeof s.text == 24 && strlen(s.text) == 23);
	CHECK(strcmp(s.text, "12345678901234567890123") == 0);
}

// The range Stations heard shows (ui_svc_aprs_range): from our position as position_now gives it, to the
// station's. EP: our position none / fixed / GPS (GPS wins in Auto) x the station's none / valid. BVA: the same
// spot is 0 m; 10 minutes of latitude due north is 18.5 km at bearing 0
static void test_station_range(void)
{
	aprs_station_t far, here, nopos;
	uint32_t m = 1;
	uint16_t deg = 1;

	reset();
	aprs_set_test_call("Q1TST");
	rx_line("Q1ABC-9>APZRDF:=4913.50N/07201.75W>North");	// 10' north of the fixed position
	rx_line("Q1ABC-8>APZRDF:=4903.50N/07201.75W>Here");	// on it
	rx_line("Q1ABC-7>APZRDF:>Status only");
	CHECK(aprs_station_count() == 3);
	CHECK(ui_svc_aprs_station_find("Q1ABC-9", &far) && far.has_pos);
	rx_line("Q1ABC-8>APZRDF:>New packet");
	CHECK(aprs_station(0, &here) && strcmp(here.call, "Q1ABC-8") == 0);
	CHECK(ui_svc_aprs_station_find("Q1ABC-9", &far) && strcmp(far.call, "Q1ABC-9") == 0);
	CHECK(!ui_svc_aprs_station_find("Q1NONE", &nopos));
	rx_line("Q1ABC-7>APZRDF:>Status only");
	CHECK(aprs_station(2, &far) && far.has_pos && aprs_station(1, &here) && here.has_pos);
	CHECK(aprs_station(0, &nopos) && !nopos.has_pos);
	// our position: none
	CHECK(!ui_svc_aprs_range(&far, &m, &deg) && !ui_svc_aprs_range(&nopos, &m, &deg));
	// fixed
	configure(0, false);
	CHECK(ui_svc_aprs_range(&far, &m, &deg) && m > 18450 && m < 18600 && deg == 0);
	CHECK(ui_svc_aprs_range(&here, &m, &deg) && m < 5);	// the APRS position's 0.01' rounding, about 1 m
	CHECK(!ui_svc_aprs_range(&nopos, &m, &deg));
	// GPS (48 07.038 N 011 31.000 E) wins over the fixed position: the station is across the Atlantic, to the west
	const char *rmc = "$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A";
	position_nmea(rmc, strlen(rmc), true, now);
	run(100);
	CHECK(ui_svc_aprs_range(&here, &m, &deg) && m > 5814000 && m < 5816000 && deg == 305);	// haversine: 5815.2 km, 304.6
	CHECK(!ui_svc_aprs_range(&nopos, &m, &deg));
	// EP on the packet that carries a position: an object or an item is somewhere else than its sender. A station
	// with a position keeps it (and its range); one heard sending only objects and items has none
	reset();
	aprs_set_test_call("Q1TST");
	configure(0, false);
	rx_line("Q1ABC-9>APZRDF:=4913.50N/07201.75W>North");
	rx_line("Q1ABC-9>APZRDF:;LEADER   *092345z4803.50N/07001.75W>Object far away");
	rx_line("Q1ABC-9>APZRDF:)AID#2!4703.50N/07101.75W>Item far away");
	rx_line("Q1ABC-9>APZRDF:;LEADER   _092345z4803.50N/07001.75W>Object deleted");
	rx_line("Q1OBJ>APZRDF:;MARKER   *092345z4803.50N/07001.75W>Object only");
	rx_line("Q1OBJ>APZRDF:)AID#3!4703.50N/07101.75W>Item only");
	CHECK(aprs_station_count() == 2 && aprs_station(1, &far) && strcmp(far.call, "Q1ABC-9") == 0);
	CHECK(far.count == 4 && far.has_pos && far.lat == 492250000);
	CHECK(ui_svc_aprs_range(&far, &m, &deg) && m > 18450 && m < 18600 && deg == 0);
	CHECK(aprs_station(0, &nopos) && strcmp(nopos.call, "Q1OBJ") == 0 && nopos.count == 2 && !nopos.has_pos);
	CHECK(!ui_svc_aprs_range(&nopos, &m, &deg));
	// The position's time: packets without one later move heard_ms on, not pos_ms (the row shows pos_ms's age)
	uint32_t t0 = now;
	now += 600000;
	rx_line("Q1ABC-9>APZRDF:>Status, no position");
	CHECK(aprs_station(0, &far) && strcmp(far.call, "Q1ABC-9") == 0 && far.heard_ms == now && far.pos_ms == t0);
	CHECK(far.has_pos && ui_svc_aprs_range(&far, &m, &deg) && m > 18450 && m < 18600);
	rx_line("Q1ABC-9>APZRDF:=4923.50N/07201.75W>Further north");
	CHECK(aprs_station(0, &far) && far.pos_ms == now && ui_svc_aprs_range(&far, &m, &deg) && m > 37000 && m < 37200);

	// BVA on the position's age (STATION_POS_MS, 24 h): packets without a position keep the entry fresh, the
	// position goes at 24 h (so its age never wraps at 2^32 ms), across the clock's own wrap too
	static const uint32_t starts[] = { 1000, 0xFFFFFFFFu - 3600000u };	// the 2nd wraps 1 h into the day
	for (size_t k = 0; k < sizeof starts / sizeof starts[0]; k++) {
		reset();
		aprs_set_test_call("Q1TST");
		configure(0, false);
		now = starts[k];
		rx_line("Q1ABC-9>APZRDF:=4913.50N/07201.75W>North");
		t0 = now;
		for (int h = 1; h < 24; h++) {	// a status every hour
			now = t0 + (uint32_t)h * 3600000u;
			rx_line("Q1ABC-9>APZRDF:>Status");
			run(RADIO_POLL_MS);
		}
		now = t0 + 24u * 3600000u - RADIO_POLL_MS - 1u;	// 1 ms inside the day after this poll
		run(RADIO_POLL_MS);
		CHECK(aprs_station(0, &far) && far.has_pos && ui_svc_aprs_range(&far, &m, &deg) && m > 18450 && m < 18600);
		run(RADIO_POLL_MS);				// a day old: gone
		CHECK(aprs_station(0, &far) && !far.has_pos && !ui_svc_aprs_range(&far, &m, &deg));
		now = t0 + 0x80000000u;				// still sending, the old position doesn't come back
		rx_line("Q1ABC-9>APZRDF:>Status");
		run(RADIO_POLL_MS);
		CHECK(aprs_station_count() == 1 && aprs_station(0, &far) && !far.has_pos && far.heard_ms == now - RADIO_POLL_MS);
		rx_line("Q1ABC-9>APZRDF:=4913.50N/07201.75W>North");	// a new one counts again
		CHECK(aprs_station(0, &far) && far.has_pos && far.pos_ms == now);
	}
}
#endif

// The position DMR GPS Info takes (position_now): the fixed position, the setting, ambiguity; and DMR callers'
// positions in the station list
static void test_dmr_position(void)
{
	aprs_cfg_t c;
	int32_t lat, lon;
	uint32_t err;
	bool send = true;

	reset();
	CHECK(!position_now(&lat, &lon, &err, &send, now) && !send);	// no position, setting off by default
	configure(0, false);
	CHECK(position_now(&lat, &lon, &err, &send, now) && lat == 490583333 && lon == -720291667 && err == 200 &&
	      !send);
	position_cfg_t pc;
	position_get_cfg(&pc);
	pc.dmr_gps = true;
	pc.ambiguity = 2;	// whole minutes: the middle of the minute, about 1.9 km
	position_set_cfg(&pc, now);
	CHECK(position_now(&lat, &lon, &err, &send, now) && send && err == 1852);
	CHECK(lat == 490583334 && lon == -720250000);	// 49 03.5 N (already mid-minute), 072 01.5 W
	// APRS over DMR blurs the exact position the same way (position_blur)
	int32_t blat = 490583333, blon = -720291667;
	uint32_t berr = 0;
	position_blur(&blat, &blon, POSITION_SRC_FIXED, &berr);
	CHECK(blat == lat && blon == lon && berr == 1852);
	// An APRS save leaves the position settings as they are, and both come back from the store
	aprs_get_cfg(&c);
	c.via = APRS_VIA_BOTH;
	aprs_set_cfg(&c, now);
	reload_settings();
	run(200);
	position_get_cfg(&pc);
	aprs_get_cfg(&c);
	CHECK(pc.dmr_gps && pc.ambiguity == 2 && pc.fix_lat == 490583333 && c.via == APRS_VIA_BOTH);
#if CONFIG_APRS_RX
	uint8_t n0 = aprs_station_count();
	aprs_dmr_heard(9997040, "qd9xyz Bob", 337490000, -843880000, now);
	aprs_dmr_heard(9997040, "qd9xyz Bob", 337490000, -843880000, now + 1000);	// the same: not counted again
	aprs_dmr_heard(9990001, "", 337000000, -843000000, now);
	aprs_dmr_heard(9990002, "Not a call", 337000000, -843000000, now);
	aprs_station_t st;
	CHECK(aprs_station_count() == n0 + 3);
	CHECK(aprs_station(0, &st) && strcmp(st.call, "9990002") == 0 && st.has_pos);
	CHECK(aprs_station(1, &st) && strcmp(st.call, "9990001") == 0);
	CHECK(aprs_station(2, &st) && strcmp(st.call, "QD9XYZ") == 0 && st.count == 1 && st.lat == 337490000 &&
	      st.pos_ms == now);	// the position's time, as for RF stations
#endif
}

// Settings > Location > GPS (position_gps_enable): a board fix is the position while the setting is on, and with it off
// the fix is gone at once (not 60 s later) and new sentences from the driver are ignored
static void test_gps_setting(void)
{
	const char *rmc = "$GPRMC,123519,A,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A";
	aprs_view_t v;

	reset();
	configure(0, false);
	position_nmea(rmc, strlen(rmc), true, now);
	run(100);
	aprs_get_view(&v);
	CHECK(v.pos_valid && v.pos_src == POSITION_SRC_GPS && v.lat == 481173000);
	position_gps_enable(false);
	run(100);
	aprs_get_view(&v);
	CHECK(v.pos_src == POSITION_SRC_FIXED);		// the fixed position, not the GPS fix
	position_nmea(rmc, strlen(rmc), true, now);	// a sentence that was already in the driver's queue
	run(100);
	aprs_get_view(&v);
	CHECK(v.pos_src == POSITION_SRC_FIXED);
	position_gps_enable(true);
	position_nmea(rmc, strlen(rmc), true, now);
	run(100);
	aprs_get_view(&v);
	CHECK(v.pos_src == POSITION_SRC_GPS);
}

// The Position screen's view of the board GPS (position_gps): nothing before a sentence, then satellites without a fix,
// then the fix; gone with the setting off and after a minute of silence
static void test_gps_status(void)
{
	const char *nofix = "$GPGGA,123519,,,,,0,05,,,M,,M,,*6E";
	const char *fix = "$GPGGA,123519,4807.038,N,01131.000,E,1,08,0.9,545.4,M,46.9,M,,*47";
	position_gps_t g;

	reset();
	configure(0, false);
	CHECK(!position_gps(&g, now));			// never heard
	position_nmea(nofix, strlen(nofix), true, now);
	CHECK(position_gps(&g, now) && !g.fix && g.sats == 5);
	position_nmea(fix, strlen(fix), false, now);	// the host's GPS isn't the board's
	CHECK(position_gps(&g, now) && !g.fix);
	position_nmea(fix, strlen(fix), true, now);
	CHECK(position_gps(&g, now) && g.fix && g.sats == 8 && g.lat == 481173000 && g.lon == 115166666 && g.alt_m == 545);
	CHECK(!position_gps(&g, now + 61000));		// silent for a minute
	position_gps_enable(false);
	CHECK(!position_gps(&g, now));
	position_gps_enable(true);
	CHECK(!position_gps(&g, now));			// until the module speaks again
	position_nmea(nofix, strlen(nofix), true, now);
	CHECK(position_gps(&g, now) && !g.fix);		// the old fix was dropped with the setting
}

// DMR destination: EP the default and stored values (a stored 5057 is kept as stored), BVA at the ends of the
// 24-bit range (0 and above 16777215 load as the default), PBT random IDs survive store and reload
static uint32_t dst_after_reload(uint32_t id)
{
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	c.dmr_dst = id;
	aprs_set_cfg(&c, now);
	aprs_reload();
	run(200);
	aprs_get_cfg(&c);
	return c.dmr_dst;
}

static void test_dmr_dst(void)
{
	reset();
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	CHECK(c.dmr_dst == 310999u && APRS_DMR_DST_DEFAULT == 310999u);	// EP: never saved
	CHECK(dst_after_reload(5057) == 5057 && dst_after_reload(204999) == 204999);	// EP: stored values are kept
	CHECK(dst_after_reload(0) == APRS_DMR_DST_DEFAULT);			// BVA
	CHECK(dst_after_reload(1) == 1 && dst_after_reload(16777215u) == 16777215u);
	CHECK(dst_after_reload(16777216u) == APRS_DMR_DST_DEFAULT);
	fuzz_t f;
	fuzz_init(&f, 0xD57);			// PBT
	for (long i = 0; i < fuzz_iters(200); i++) {
		uint32_t id = 1u + fuzz_below(&f, 16777215u);
		CHECK(dst_after_reload(id) == id);
	}
}

// The configuration kept in the settings (settings_t aprs_*): back exactly after a reload, and a stored record with
// values out of range (another firmware's, a damaged one) loads field by field with the defaults for the bad ones
static void test_cfg_store(void)
{
	reset();
	aprs_cfg_t c, b;
	aprs_get_cfg(&c);
	c.tx_on = c.smart = c.compressed = c.after_ptt = c.boot = c.kiss = c.narrow = c.rx_on = true;
	c.igate = c.igate_tx = c.messaging = c.dmr_udt = c.to_is = true;
	c.region = APRS_REGION_CUSTOM;
	c.freq_hz = 145825000;
	c.ssid = 9;
	c.sym_table = '\\';
	c.sym_code = 'k';
	c.path = APRS_PATH_WIDE2_2;
	position_cfg_t pc = { .pref = POSITION_FIXED, .fix_lat = -337000000, .fix_lon = 1512000000, .fix_alt_m = -12,
			      .ambiguity = 3, .dmr_gps = true }, pb;
	position_set_cfg(&pc, now);
	c.interval_s = 900;
	c.distance_m = 2500;
	c.level = 63;
	c.txdelay = 45;
	c.via = APRS_VIA_BOTH;
	c.dmr_dst = 5057;
	c.digi = 2;
	aprs_set_cfg(&c, now);
	reload_settings();
	run(200);			// (taken on the radio task's next tick)
	aprs_get_cfg(&b);
	position_get_cfg(&pb);
	CHECK(b.tx_on && b.smart && b.compressed && b.after_ptt && b.boot && b.kiss && b.narrow && b.rx_on);
	CHECK(b.igate && b.igate_tx && b.messaging && b.dmr_udt && b.to_is && pb.dmr_gps);
	CHECK(b.region == APRS_REGION_CUSTOM && b.freq_hz == 145825000 && b.ssid == 9 && b.sym_table == '\\' &&
	      b.sym_code == 'k' && b.path == APRS_PATH_WIDE2_2 && pb.ambiguity == 3 && pb.pref == POSITION_FIXED);
	CHECK(pb.fix_lat == -337000000 && pb.fix_lon == 1512000000 && pb.fix_alt_m == -12 && b.interval_s == 900 &&
	      b.distance_m == 2500 && b.level == 63 && b.txdelay == 45 && b.via == APRS_VIA_BOTH && b.dmr_dst == 5057 &&
	      b.digi == 2);
	// Out of range on the way in: kept in range
	c.ssid = 40;
	c.level = 200;
	pc.ambiguity = 9;
	aprs_set_cfg(&c, now);
	position_set_cfg(&pc, now);
	aprs_get_cfg(&b);
	position_get_cfg(&pb);
	CHECK(b.ssid == 7 && b.level <= 100 && pb.ambiguity == 4);
	// A damaged record
	settings_t *st = settings_begin();
	st->aprs_region = 99;
	st->aprs_ssid = 77;
	st->aprs_dmr_dst = 0x1000000u;
	st->aprs_symbol[0] = '/';
	st->aprs_symbol[1] = 0x7F;
	st->aprs_path = 50;
	st->aprs_pos_src = 50;
	st->aprs_level = 101;
	st->aprs_txdelay = 0;
	st->aprs_misc = 3u | (3u << 2) | (7u << 4);	// via, digipeater mode and ambiguity all out of range
	settings_end(now);
	reload_settings();
	run(200);			// (taken on the radio task's next tick)
	aprs_get_cfg(&b);
	position_get_cfg(&pb);
	aprs_cfg_t d;
	aprs_cfg_default(&d);
	CHECK(b.region == APRS_REGION_NA && b.ssid == d.ssid && b.dmr_dst == d.dmr_dst && b.sym_code == d.sym_code &&
	      b.sym_table == d.sym_table);
	CHECK(b.path == APRS_PATH_WIDE1_WIDE2 && pb.pref == POSITION_AUTO && b.level == d.level &&
	      b.txdelay == d.txdelay && b.via == APRS_VIA_RF && b.digi == 0 && pb.ambiguity == 0);
	CHECK(b.tx_on && b.freq_hz == 145825000);	// the good fields stay
	// Not stored at all: the defaults
	st = settings_begin();
	st->aprs_stored = 0;
	settings_end(now);
	aprs_reload();
	run(200);			// (taken on the radio task's next tick)
	aprs_get_cfg(&b);
	CHECK(!b.tx_on && b.region == d.region && b.interval_s == d.interval_s);
}

// The path lives in the settings and in the codeplug's APRS record; the one changed last wins (aprs.md 11)
static void test_codeplug_path(void)
{
	aprs_cfg_t c;
	reset();
	strcpy(cp_path[0], "WIDE2-1");		// a CPS wrote WIDE2-1
	cp_path[1][0] = '\0';
	cp_serial++;
	run(200);
	aprs_get_cfg(&c);
	CHECK(c.path == APRS_PATH_WIDE2);
	settings_t st;
	settings_read(&st);
	CHECK(st.aprs_stored == 1 && st.aprs_path == APRS_PATH_WIDE2 && st.aprs_cp_path == APRS_PATH_WIDE2 + 1u);
	// The menu changes it: the codeplug's unchanged path doesn't take it back
	c.path = APRS_PATH_WIDE2_2;
	aprs_set_cfg(&c, now);
	aprs_reload();
	run(200);
	aprs_get_cfg(&c);
	CHECK(c.path == APRS_PATH_WIDE2_2);
	// ... and the storage job writes it into the codeplug
	CHECK(aprs_path_to_codeplug());
	CHECK(strcmp(cp_path[0], "WIDE2-2") == 0 && cp_path[1][0] == '\0');
	run(200);
	aprs_get_cfg(&c);
	settings_read(&st);
	CHECK(c.path == APRS_PATH_WIDE2_2 && st.aprs_cp_path == APRS_PATH_WIDE2_2 + 1u);
	// Two entries go into both slots
	c.path = APRS_PATH_WIDE1_WIDE2;
	aprs_set_cfg(&c, now);
	CHECK(aprs_path_to_codeplug() && strcmp(cp_path[0], "WIDE1-1") == 0 && strcmp(cp_path[1], "WIDE2-1") == 0);
	// None: both empty
	c.path = APRS_PATH_NONE;
	aprs_set_cfg(&c, now);
	CHECK(aprs_path_to_codeplug() && cp_path[0][0] == '\0' && cp_path[1][0] == '\0');
	// The CPS writes a new path: taken
	strcpy(cp_path[0], "WIDE1-1");
	cp_serial++;
	run(200);
	aprs_get_cfg(&c);
	CHECK(c.path == APRS_PATH_WIDE1);
	// A path we don't offer is left alone
	strcpy(cp_path[0], "RELAY");
	strcpy(cp_path[1], "WIDE2-1");
	cp_serial++;
	run(200);
	aprs_get_cfg(&c);
	CHECK(c.path == APRS_PATH_WIDE1);
	strcpy(cp_path[0], "");			// a second entry without a first
	cp_serial++;
	run(200);
	aprs_get_cfg(&c);
	CHECK(c.path == APRS_PATH_WIDE1);
}

// The transmission's failures: the transmitter won't key, the AFSK won't start, the AFSK never finishes. Each time
// the radio goes back to its channel unkeyed, and the frame is tried again later, then given up
static void test_rf_failures(void)
{
	aprs_view_t v;
	reset();
	strcpy(cp_name, "Q1TST");
	configure(0, false);
	for (int fault = 0; fault < 3; fault++) {
		hw.tx_fail = fault == 0;
		hw.afsk_fail = fault == 1;
		hw.afsk_stuck = fault == 2;
		aprs_get_view(&v);
		uint32_t failed = v.rf_failed;
		CHECK(aprs_send_now());
		run(30000);
		aprs_get_view(&v);
		CHECK(v.rf_failed > failed && v.rf_sent == 0);
		static const uint8_t why[3] = { APRS_RF_NO_KEY, APRS_RF_NO_AFSK, APRS_RF_TIMEOUT };
		CHECK(v.rf_fail == why[fault]);
		CHECK(!hw.keyed && hw.rx_hz == CH_HZ && sm.view.state == RS_IDLE && sm.aprs_phase == 0 &&
		      !sm.view.aprs_tx);
		run(60000);		// the retries, then given up
		aprs_get_view(&v);
		CHECK(!aprs_rf_pending() && !v.rf_active && !hw.keyed && hw.rx_hz == CH_HZ);
	}
	hw.tx_fail = hw.afsk_fail = hw.afsk_stuck = false;
	// Working again: a status goes out; with the longest preamble a long one still fits (the preamble shortened)
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	c.txdelay = 255;
	aprs_set_cfg(&c, now);
	int starts = hw.starts;
	nframes = 0;
	CHECK(aprs_send_status("A status text long enough to make the frame and a 2.5 s preamble overflow the tones"));
	CHECK(wait_start(starts + 1, 20000));
	wait_idle();
	aprs_get_view(&v);
	CHECK(v.rf_sent >= 1 && nframes >= 1 && strstr(frames[0], ">A status text") != NULL);
	// No callsign: a status isn't sent
	strcpy(cp_name, "");
	aprs_set_cfg(&c, now);
	CHECK(!aprs_send_status("x"));
}

#if CONFIG_APRS_RX
// One 20 ms block of receive audio through the stream, then a radio poll
static void feed(const int16_t *s)
{
	int16_t spk[AUDIO_BLOCK_SAMPLES];
	if (pcm.cb != NULL) {
		pcm.cb(s, spk, pcm.ctx);
	}
	run(RADIO_POLL_MS);
}

// FM receive audio on the PCM stream (AUDIO_TAP_FM_RX) into the demodulator: only on the APRS frequency, battery saving
// held off while it listens (docs/spec/aprs.md 5.3)
static void test_rx_stream(void)
{
	fake_tap.caps = AUDIO_TAP_FM_RX;
	memset(&pcm, 0, sizeof(pcm));
	reset();
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	CHECK(aprs_can_receive() && c.rx_on && c.messaging);	// a receive path: on by default
	// Not on the APRS frequency: the stream stays off
	run(500);
	CHECK(!aprs_rx_listening() && pcm.starts == 0);
	// A channel on 144.390
	chan.rx_hz = chan.tx_hz = APRS_HZ;
	settings_init();
	radio_sm_init(&sm, now);
	run(200);
	CHECK(aprs_rx_listening() && pcm.starts == 1 && pcm.cb != NULL);
	// A packet: silence, the tones (flags first, as a transmitter's TX delay), silence
	static uint8_t tones[256];
	static int16_t audio[24000];
	const char *line = "Q1ABC-9>APRS,WIDE2-1:!4903.50N/07201.75W-Heard on air";
	ax25_frame_t f;
	uint8_t frame[AX25_FRAME_MAX];
	CHECK(ax25_from_tnc2(line, strlen(line), &f));
	f.dst.h = true;
	size_t n = ax25_encode(&f, frame, sizeof(frame));
	hdlc_enc_t e;
	hdlc_enc_init(&e, tones, sizeof(tones));
	CHECK(hdlc_enc_flags(&e, 30) && hdlc_enc_frame(&e, frame, n) && hdlc_enc_flags(&e, 3));
	afsk_mod_t m;
	afsk_mod_init(&m, 8000);
	memset(audio, 0, sizeof(audio));
	size_t k = afsk_mod(&m, tones, e.nbits, 8000, audio + 800, sizeof(audio) / sizeof(audio[0]) - 1600);
	CHECK(k > 0);
	CHECK(aprs_station_count() == 0);
	aprs_rx_stats_t r0;
	aprs_rx_stats(&r0);
	CHECK(r0.peak == 0 && r0.frames == 0);	// silence so far
	for (size_t i = 0; i + AUDIO_BLOCK_SAMPLES <= k + 1600; i += AUDIO_BLOCK_SAMPLES) {
		feed(audio + i);
	}
	run(100);
	aprs_station_t st;
	CHECK(aprs_station_count() == 1 && aprs_station(0, &st) && strcmp(st.call, "Q1ABC-9") == 0);
	aprs_rx_stats_t rs;
	aprs_rx_stats(&rs);
	CHECK(rs.peak > 7000 && rs.peak <= 8000 && rs.frames == 1 && rs.bits > 900);
	// A signal: the squelch holds through 100 ms of noise readings over the line (a packet's tones do that), closes
	// after 300 ms of them
	hw.noise_on_aprs = 30;
	run(100);
	CHECK(sm.view.state == RS_RX);
	hw.noise_on_aprs = 120;
	run(100);
	hw.noise_on_aprs = 30;
	run(50);
	CHECK(sm.view.state == RS_RX);
	hw.noise_on_aprs = 120;
	run(325);
	CHECK(sm.view.state == RS_IDLE);
	// Receive off: the stream stops
	aprs_get_cfg(&c);
	c.rx_on = false;
	aprs_set_cfg(&c, now);
	run(200);
	CHECK(!aprs_rx_listening() && pcm.stops == 1 && pcm.cb == NULL);
	// ... and the squelch closes after 50 ms again
	hw.noise_on_aprs = 30;
	run(100);
	CHECK(sm.view.state == RS_RX);
	hw.noise_on_aprs = 120;
	run(75);
	CHECK(sm.view.state == RS_IDLE);
	fake_tap.caps = 0;
}
// A board with its own receive path and no transmit one (tx_start NULL): its audio reaches the
// demodulator at its own rate, nothing is sent on RF and the transmitter is never keyed for APRS
static struct {
	const int16_t *s;
	size_t n, pos;
	int starts, stops, refuse;
} brx;
static bool b_rx_start(void)
{
	brx.starts++;
	if (brx.refuse > 0) {
		brx.refuse--;
		return false;
	}
	return true;
}
static void b_rx_stop(void) { brx.stops++; }
static uint16_t b_rx_read(int16_t *buf, uint16_t max)
{
	uint16_t k = 0;
	while (k < max && k < 200u && brx.pos < brx.n) {	// 25 ms at 8 kHz per poll
		buf[k++] = brx.s[brx.pos++];
	}
	return k;
}

static void test_rx_board_only(void)
{
	hal_afsk_t saved = fake_afsk;
	fake_afsk = (hal_afsk_t){ .rx_rate_hz = 8000, .rx_start = b_rx_start, .rx_read = b_rx_read, .rx_stop = b_rx_stop };
	memset(&brx, 0, sizeof(brx));
	reset();
	CHECK(aprs_can_receive());
	chan.rx_hz = chan.tx_hz = APRS_HZ;
	settings_init();
	radio_sm_init(&sm, now);
	strcpy(cp_name, "Q1TST");
	configure(60, false);
	run(200);
	CHECK(aprs_rx_listening() && brx.starts == 1);
	aprs_rx_stats_t rs;
	aprs_rx_stats(&rs);
	CHECK(rs.start_fails == 0);
	static uint8_t tones[256];
	static int16_t audio[24000];
	const char *line = "Q1ABC-9>APRS,WIDE2-1:!4903.50N/07201.75W-Own path";
	ax25_frame_t f;
	uint8_t frame[AX25_FRAME_MAX];
	CHECK(ax25_from_tnc2(line, strlen(line), &f));
	f.dst.h = true;
	size_t n = ax25_encode(&f, frame, sizeof(frame));
	hdlc_enc_t e;
	hdlc_enc_init(&e, tones, sizeof(tones));
	CHECK(hdlc_enc_flags(&e, 30) && hdlc_enc_frame(&e, frame, n) && hdlc_enc_flags(&e, 3));
	afsk_mod_t m;
	afsk_mod_init(&m, 8000);
	memset(audio, 0, sizeof(audio));
	size_t k = afsk_mod(&m, tones, e.nbits, 8000, audio + 800, sizeof(audio) / sizeof(audio[0]) - 1600);
	CHECK(k > 0);
	brx.s = audio;
	brx.n = k + 1600;
	run(3000);
	aprs_station_t st;
	CHECK(aprs_station_count() == 1 && aprs_station(0, &st) && strcmp(st.call, "Q1ABC-9") == 0);
	// A beacon can't go out on RF: blocked, never keyed
	aprs_view_t v;
	aprs_get_view(&v);
	CHECK(v.block == APRS_NO_AFSK);
	aprs_send_now();
	run(60000);
	CHECK(hw.tx_calls == 0 && !hw.keyed && hw.starts == 0);
	// Receive off: the path stops
	aprs_cfg_t c;
	aprs_get_cfg(&c);
	c.rx_on = false;
	aprs_set_cfg(&c, now);
	run(200);
	CHECK(!aprs_rx_listening() && brx.stops == 1);
	// A start the board refuses is tried again a second later, not on every tick
	brx.starts = 0;
	brx.refuse = 2;
	c.rx_on = true;
	aprs_set_cfg(&c, now);
	run(500);
	aprs_rx_stats(&rs);
	CHECK(!aprs_rx_listening() && brx.starts == 1 && rs.start_fails == 1);
	run(1000);
	aprs_rx_stats(&rs);
	CHECK(!aprs_rx_listening() && brx.starts == 2 && rs.start_fails == 2);
	run(1100);
	CHECK(aprs_rx_listening() && brx.starts == 3);
	// Receive off and on again after a refusal: the new start is at once, not after the refused one's wait
	c.rx_on = false;
	aprs_set_cfg(&c, now);
	run(200);
	brx.refuse = 1;
	c.rx_on = true;
	aprs_set_cfg(&c, now);
	run(200);
	CHECK(!aprs_rx_listening() && brx.starts == 4);
	c.rx_on = false;
	aprs_set_cfg(&c, now);
	run(200);
	c.rx_on = true;
	aprs_set_cfg(&c, now);
	run(200);
	CHECK(aprs_rx_listening() && brx.starts == 5);
	fake_afsk = saved;
}
#endif

int main(void)
{
	test_defaults();
	test_beacon_on_air();
	test_tx_limit();
	test_min_interval();
	test_busy_channel();
	test_bcast_channel();
	test_ptt_cuts();
#if CONFIG_DUAL_WATCH
	test_dual_watch_beacon();
	test_dual_receiver_beacon();
	test_dual_watch_beacon_abort();
#endif
	test_ptt_cuts_burst();
	test_not_amateur();
	test_manual_and_ptt_trigger();
	test_tx_power();
	test_tx_power_own();
	test_host_kiss_nmea();
	test_messages();
	test_third_party_messages();
	test_message_options();
	test_message_replaces_pending();
#if CONFIG_APRS_RX
	test_message_rejection();
#endif
	test_dmr_position();
	test_gps_setting();
	test_gps_status();
	test_cfg_store();
	test_dmr_dst();
	test_codeplug_path();
	test_rf_failures();
#if CONFIG_APRS_RX
	test_stations_digi_igate();
	test_rx_stream();
	test_rx_board_only();
	test_station_lookup();
	test_station_range();
#endif
	printf("# aprsRadioTest: %d checks, %s\n", checks, failures ? "FAILED" : "PASSED");
	return failures ? 1 : 0;
}
