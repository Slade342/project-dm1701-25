// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The RadioFoundry Authors
// FD6818 driver: band words, CTCSS word, and the bit-banged frames against a fake chip that samples the data line on
// rising clock edges while CS is low (docs/spec/hardware-dm32.md 8.1-8.4)
#include <stdio.h>
#include <string.h>
#include "rf/fd6818/fd6818.h"
#include "rf/subaudio/subaudio.h"


static int failures;

#define CHECK(cond) do { if (!(cond)) { printf("FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); failures++; } } while (0)

// --- Fake chip on the three wires ---

typedef struct {
	uint8_t reg;
	uint16_t val;
} frame_t;

static struct {
	bool cs, clk, data, driving;
	uint32_t shift;
	int bits;
	bool reading;
	uint16_t out;		// value the chip shifts out in a read
	int out_bits;
	frame_t log[256];
	int n;
	int crit_depth, crit_max;
	int protocol_errors;
	uint16_t regs[256];
	uint16_t (*css)(void);	// set: what 0x0C reads (the lock bit by set-up and time)
} chip;

static void fake_cs(bool level)
{
	if (!chip.cs && level) {	// end of a frame
		if (!chip.reading) {
			if (chip.bits != 24) {
				chip.protocol_errors++;
			} else if (chip.n < 256) {
				chip.log[chip.n].reg = (uint8_t)(chip.shift >> 16);
				chip.log[chip.n].val = (uint16_t)chip.shift;
				chip.regs[(chip.shift >> 16) & 0xFF] = (uint16_t)chip.shift;
				chip.n++;
			}
		}
		chip.reading = false;
	}
	if (chip.cs && !level) {
		chip.driving = true;
		chip.shift = 0;
		chip.bits = 0;
		chip.reading = false;
	}
	chip.cs = level;
}

static void fake_clk(bool level)
{
	bool rising = !chip.clk && level;
	chip.clk = level;
	if (!rising || chip.cs) {
		return;
	}
	// A read is an address with bit 7 set followed by the MCU letting go of the data line; an address with bit 7
	// set that the MCU keeps driving is a write (the init table's 0xB3 / 0xB4 / 0xC7 entries)
	if (!chip.driving) {
		if (!chip.reading) {
			if (chip.bits != 8 || (chip.shift & 0x80u) == 0) {
				chip.protocol_errors++;
			}
			chip.reading = true;
			chip.out = chip.regs[chip.shift & 0x7Fu];
			if ((chip.shift & 0x7Fu) == FD6818_REG_CSS_STATUS && chip.css) {
				chip.out = chip.css();
			}
			chip.out_bits = 0;
		}
		chip.out_bits++;
		return;
	}
	chip.shift = (chip.shift << 1) | (chip.data ? 1u : 0u);
	chip.bits++;
}

static void fake_data_out(bool level)
{
	chip.data = level;
	chip.driving = true;
}

static void fake_release(void)
{
	chip.driving = false;
}

static bool fake_data_in(void)
{
	// Bit n (from the MSB) is on the line while the clock is high after the n-th rising edge of the read
	int n = chip.out_bits - 1;
	if (n < 0 || n > 15) {
		return false;
	}
	return (chip.out >> (15 - n)) & 1u;
}

static void fake_delay(uint32_t us)
{
	(void)us;
}

static uint32_t fake_enter(void)
{
	if (++chip.crit_depth > chip.crit_max) {
		chip.crit_max = chip.crit_depth;
	}
	return 0;
}

static void fake_exit(uint32_t s)
{
	(void)s;
	chip.crit_depth--;
}

static const rfbus_3w_pins_t pins = {
	.cs = fake_cs, .clk = fake_clk, .data_out = fake_data_out, .data_release = fake_release,
	.data_in = fake_data_in, .delay_us = fake_delay, .crit_enter = fake_enter, .crit_exit = fake_exit,
	.delay_ms = fake_delay,
};

static rfbus_3w_t bus3;

// A fresh bus per attach: its write count starts at 0
static rfbus_t *bus(void)
{
	rfbus_3w_attach(&bus3, &pins);
	return &bus3.bus;
}

static void reset_chip(void)
{
	memset(&chip, 0, sizeof chip);
	chip.cs = true;
}

static int find_last(uint8_t reg)
{
	for (int i = chip.n - 1; i >= 0; i--) {
		if (chip.log[i].reg == reg) {
			return i;
		}
	}
	return -1;
}

static void test_rssi_cal(void)
{
	static const fd6818_rssi_cal_t t[] = { { 136, -26 }, { 140, -36 }, { 174, -40 }, { 400, -25 }, { 446, -25 },
					       { 461, -20 }, { 480, -20 } };
	uint8_t n = sizeof(t) / sizeof(t[0]);
	CHECK(fd6818_rssi_cal_db(NULL, 0, 146000000u) == 0);
	CHECK(fd6818_rssi_cal_db(t, n, 100000000u) == -26);	// below the first point
	CHECK(fd6818_rssi_cal_db(t, n, 136000000u) == -26);
	CHECK(fd6818_rssi_cal_db(t, n, 138000000u) == -31);	// halfway
	CHECK(fd6818_rssi_cal_db(t, n, 157000000u) == -38);
	CHECK(fd6818_rssi_cal_db(t, n, 174000000u) == -40);
	CHECK(fd6818_rssi_cal_db(t, n, 220000000u) == -40);	// between the bands: the nearer end
	CHECK(fd6818_rssi_cal_db(t, n, 350000000u) == -25);
	CHECK(fd6818_rssi_cal_db(t, n, 449000000u) == -24);
	CHECK(fd6818_rssi_cal_db(t, n, 470000000u) == -20);
	CHECK(fd6818_rssi_cal_db(t, n, 520000000u) == -20);	// past the last point
	CHECK(fd6818_rssi_cal_db(t, 1, 446000000u) == -26);
}

static void test_helpers(void)
{
	uint16_t a, b;
	CHECK(fd6818_band_words(14400000u, &a, &b) && a == 0xAF28 && b == 0x375C);	// 144 MHz: >= 124 MHz row
	CHECK(fd6818_band_words(43500000u, &a, &b) && a == 0x2F50 && b == 0x39F0);	// 435 MHz: >= 370 MHz row
	CHECK(fd6818_band_words(18500000u, &a, &b) && a == 0x3F48 && b == 0x38F0);	// 185 MHz
	CHECK(fd6818_band_words(18499999u, &a, &b) && a == 0x3F48);			// the row's own boundary value
	CHECK(fd6818_band_words(18499998u, &a, &b) && a == 0xAF28);
	CHECK(!fd6818_band_words(1500000u, &a, &b));					// below 16 MHz: nothing
	CHECK(subaudio_ctcss_word(885, true) == 1827);	// 88.5 Hz x 20.64888 (the old port's integer division gave 1651)
	CHECK(subaudio_ctcss_word(1000, true) == 2065);
	CHECK(subaudio_ctcss_word(2541, true) == 5247);
	CHECK(fd6818_rssi_raw(0x01FF) == 0xFF && fd6818_rssi_raw(0xFE00) == 0);
	CHECK(fd6818_rssi_dbm(100) == -110 && fd6818_rssi_dbm(0xFE00) == -160);	// guide: reg / 2 - 160
	CHECK(fd6818_noise(0xAB08) == 33 && fd6818_noise(0x00FF) == 255);	// low byte only, capped
	// the measured floor (43) stays shut at the loosest squelch level (opens below 64), a strong carrier (8) opens the
	// tightest (below 40): core/radio/radio_sm.h RADIO_SQL_*
	CHECK(fd6818_noise(43) >= 64 && fd6818_noise(8) < 40);
}

static void test_frames(void)
{
	fd6818_t dev;
	reset_chip();
	fd6818_attach(&dev, bus());
	fd6818_write(&dev, 0x30, 0xBFF1);
	CHECK(chip.n == 1 && chip.log[0].reg == 0x30 && chip.log[0].val == 0xBFF1);
	CHECK(chip.protocol_errors == 0);
	CHECK(dev.state == 0xBFF1 && dev.bus->writes == 1);
	CHECK(chip.crit_depth == 0 && chip.crit_max == 1);
	// Bit 7 of the address is the read flag: the bus never sets it in a write (the sequences never ask it to)
	fd6818_write(&dev, 0xB3, 0xFE00);
	CHECK(chip.n == 2 && chip.log[1].reg == 0x33 && chip.log[1].val == 0xFE00);
	CHECK(chip.protocol_errors == 0);

	chip.regs[0x67] = 0x0123;
	uint16_t v = fd6818_read(&dev, 0x67);
	CHECK(v == 0x0123);
	CHECK(chip.protocol_errors == 0);
	CHECK(chip.n == 2);	// a read logs no write
	chip.regs[0x65] = 0xA55A;
	CHECK(fd6818_read(&dev, 0x65) == 0xA55A);
}

static void test_sequences(void)
{
	fd6818_t dev;
	reset_chip();
	fd6818_attach(&dev, bus());
	fd6818_init(&dev);
	CHECK(chip.n == 53 + 20);
	CHECK(chip.log[0].reg == 0x00 && chip.log[0].val == 0x8000);	// soft reset first
	CHECK(chip.log[52].reg == 0x09 && chip.log[52].val == 0xF09F);	// last init entry
	for (int i = 0; i < chip.n; i++) {
		CHECK(chip.log[i].reg < 0x80);	// no read cycle disguised as a write (the earlier 0xB3 / 0xB4 entries)
	}
	CHECK(chip.log[72].reg == 0x48 && chip.log[72].val == 0xBBBF);	// last post-init entry
	CHECK(chip.protocol_errors == 0);

	chip.n = 0;
	fd6818_set_freq(&dev, 144000000u);
	CHECK(chip.n == 5);
	CHECK(chip.log[0].reg == 0x30 && chip.log[0].val == 0);			// idle first
	CHECK(chip.log[1].reg == 0x1A && chip.log[1].val == 0xAF28);
	CHECK(chip.log[2].reg == 0x40 && chip.log[2].val == 0x375C);
	CHECK(chip.log[3].reg == 0x38 && chip.log[3].val == 0xBA00);
	CHECK(chip.log[4].reg == 0x39 && chip.log[4].val == 0x00DB);		// 144.000 MHz = 0x00DBBA00
	CHECK(dev.freq_10hz == 14400000u);

	// RX -> TX goes through idle; idle -> RX doesn't add an extra write
	chip.n = 0;
	fd6818_set_state(&dev, FD6818_STATE_RX);
	CHECK(chip.n == 1 && chip.log[0].val == FD6818_STATE_RX);
	chip.n = 0;
	fd6818_set_state(&dev, FD6818_STATE_TX);
	CHECK(chip.n == 2 && chip.log[0].val == FD6818_STATE_IDLE && chip.log[1].val == FD6818_STATE_TX);

	chip.n = 0;
	fd6818_dmr_burst(&dev, false, FD6818_BW_DMR);
	CHECK(chip.n == 3 && chip.log[0].reg == 0x43 && chip.log[0].val == 0x4048 && chip.log[2].val == FD6818_STATE_RX);
	chip.n = 0;
	fd6818_dmr_burst(&dev, true, FD6818_BW_DMR);
	CHECK(chip.n == 2 && chip.log[0].val == 0 && chip.log[1].val == FD6818_STATE_TX);

	chip.n = 0;
	fd6818_set_mode(&dev, FD6818_MODE_DMR);
	int i = find_last(0x43);
	CHECK(i >= 0 && chip.log[i].val == 0x4048);
	CHECK(chip.log[chip.n - 1].reg == 0x47 && chip.log[chip.n - 1].val == 0x0140);
	for (int k = 0; k < chip.n; k++) {
		CHECK(chip.log[k].reg < 0x80);	// the earlier 0xC7 entry was a read cycle
	}
	chip.n = 0;
	fd6818_set_mode(&dev, FD6818_MODE_FM);
	i = find_last(0x43);
	CHECK(i >= 0 && chip.log[i].val == 0x3028);

	chip.n = 0;
	fd6818_set_tx_ctcss(&dev, 885);
	CHECK(chip.n == 2 && chip.log[0].reg == 0x07 && chip.log[0].val == 1827 && chip.log[1].val == 0x9045);
}

// Receiver power saving in the radio's own order: idle, then 0x37 low; waking puts 0x37 back and leaves the state idle
static void test_rx_sleep(void)
{
	fd6818_t dev;
	reset_chip();
	fd6818_attach(&dev, bus());
	fd6818_rx_sleep(&dev, true, FD6818_MODE_FM);
	CHECK(chip.n == 2 && chip.log[0].reg == 0x30 && chip.log[0].val == 0 && chip.log[1].reg == 0x37 &&
		chip.log[1].val == 0x1D11);
	CHECK(dev.state == FD6818_STATE_IDLE);
	chip.n = 0;
	fd6818_rx_sleep(&dev, true, FD6818_MODE_DMR);
	CHECK(chip.n == 2 && chip.log[1].val == 0x1D00);
	chip.n = 0;
	fd6818_rx_sleep(&dev, false, FD6818_MODE_FM);
	CHECK(chip.n == 2 && chip.log[0].reg == 0x37 && chip.log[0].val == 0x1F1F && chip.log[1].val == 0x1F0F);

	// set-up B: its own words, one on waking
	fd6818_attach_variant(&dev, bus(), &fd6818_variant_b_dmr6943);
	chip.n = 0;
	fd6818_rx_sleep(&dev, true, FD6818_MODE_FM);
	CHECK(chip.n == 2 && chip.log[0].reg == 0x30 && chip.log[0].val == 0 && chip.log[1].val == 0x9D17);
	chip.n = 0;
	fd6818_rx_sleep(&dev, true, FD6818_MODE_DMR);
	CHECK(chip.n == 2 && chip.log[1].val == 0x9D00);
	chip.n = 0;
	fd6818_rx_sleep(&dev, false, FD6818_MODE_FM);
	CHECK(chip.n == 1 && chip.log[0].reg == 0x37 && chip.log[0].val == 0x9D1F);
}

// AM receive: one AF word, the FM word with the AM demodulator type; FM gives the tables' word back
static void test_am(void)
{
	fd6818_t dev;
	reset_chip();
	fd6818_attach(&dev, bus());
	// Outside AM, "off" writes nothing
	fd6818_set_am(&dev, false);
	CHECK(chip.n == 0);
	// On: the AM output, full gain, 0x4A's AM word (hardware-dm32.md 8.7). 0x4A isn't in the default tables: its value
	// before AM is read from the chip
	chip.regs[FD6818_REG_AM_4A] = 0x1234;
	fd6818_set_am(&dev, true);
	CHECK(chip.n == 3);
	CHECK(chip.log[0].reg == FD6818_REG_AF && chip.log[0].val == 0x6740);
	CHECK(chip.log[1].reg == FD6818_REG_GAIN && chip.log[1].val == 0x03FF);
	CHECK(chip.log[2].reg == FD6818_REG_AM_4A && chip.log[2].val == 0x5450);
	CHECK((FD6818_AF_AM & 0x0F00u) == 0x0700u && (FD6818_AF_FM & 0x0F00u) == 0x0100u);
	CHECK(FD6818_BW_AM == 0x0048u);
	// Again (a new AM channel): the same writes, 0x4A's saved value kept
	fd6818_set_am(&dev, true);
	CHECK(chip.n == 6 && chip.log[5].val == 0x5450);
	// Off: FM's AF word, the FM table's 0x13, 0x4A as it was
	fd6818_set_am(&dev, false);
	int i = find_last(FD6818_REG_GAIN);
	CHECK(i >= 0 && chip.log[i].val == 0x037E);
	i = find_last(FD6818_REG_AF);
	CHECK(i >= 0 && chip.log[i].val == 0x0140);
	i = find_last(FD6818_REG_AM_4A);
	CHECK(i >= 0 && chip.log[i].val == 0x1234);
	// A mode change from AM ends AM first: 0x4A comes back although the mode tables don't write it
	fd6818_set_am(&dev, true);
	chip.n = 0;
	fd6818_set_mode(&dev, FD6818_MODE_FM);
	i = find_last(FD6818_REG_AM_4A);
	CHECK(i >= 0 && chip.log[i].val == 0x1234 && !dev.am);
	i = find_last(FD6818_REG_AF);
	CHECK(i >= 0 && chip.log[i].val == FD6818_AF_FM);
	// Outside AM a status reading changes nothing and the gain loop doesn't run
	chip.n = 0;
	int16_t rssi = -90;
	uint8_t noise = 77;
	CHECK(!fd6818_am_status(&dev, 0x0010, 400, &rssi, &noise));
	CHECK(chip.n == 0 && rssi == -90 && noise == 77);
	CHECK(chip.protocol_errors == 0);

	// In AM: the squelch value is noise_sq plus the offset from the default tables' 0x4F = 0x302F (noise_sq_th_in 47):
	// level 1 (opens below 64) at 47. A strong reading cuts the gain (0x13 written) after the reading is taken
	fd6818_set_am(&dev, true);
	CHECK(dev.am_noise_off == 17);
	chip.n = 0;
	rssi = -60;
	CHECK(fd6818_am_status(&dev, 0x4B00u | 46u, 222, &rssi, &noise));
	CHECK(noise == 63 && rssi == -60);
	CHECK(chip.n == 1 && chip.log[0].reg == FD6818_REG_GAIN && chip.log[0].val == 0x0BF);
	// The next reading's RSSI gets the 32 dB the loop took off added back
	rssi = -92;
	CHECK(fd6818_am_status(&dev, 70, 150, &rssi, &noise));
	CHECK(rssi == -60 && noise == 87);
	fd6818_set_am(&dev, false);

	// A variant whose tables set 0x13 and 0x4A (the DM-1801 Pro's init: 0x03DF, 0x5430) gets those back, no read
	reset_chip();
	fd6818_attach_variant(&dev, bus(), &fd6818_variant_b);
	chip.regs[FD6818_REG_GAIN] = 0x1111;
	chip.regs[FD6818_REG_AM_4A] = 0x2222;
	fd6818_set_am(&dev, true);
	CHECK(dev.am_noise_off == 24);	// its 0x4F = 0x2A28: noise_sq_th_in 40 is its level 1
	fd6818_set_am(&dev, false);
	i = find_last(FD6818_REG_GAIN);
	CHECK(i >= 0 && chip.log[i].val == 0x03DF);
	i = find_last(FD6818_REG_AM_4A);
	CHECK(i >= 0 && chip.log[i].val == 0x5430);
	CHECK(chip.protocol_errors == 0);
}

// The AM gain loop: full gain on noise, down at once on a strong signal, up one step at a time after the hold
static void test_am_agc(void)
{
	fd6818_agc_t a;
	fd6818_agc_reset(&a);
	CHECK(fd6818_agc_word(&a) == 0x03FF && fd6818_agc_atten_db(&a) == 0);
	// Noise and weak signals (under 142 + 20): nothing changes
	for (int k = 0; k < 100; k++) {
		CHECK(!fd6818_agc_step(&a, 60));
		CHECK(!fd6818_agc_step(&a, 160));
	}
	CHECK(fd6818_agc_word(&a) == 0x03FF);
	// 0x67 = 222: 40 dB over the target, the gain goes down by 32 dB: -32 dB is 0x0BF
	fd6818_agc_reset(&a);
	CHECK(fd6818_agc_step(&a, 222));
	CHECK(fd6818_agc_word(&a) == 0x0BF && fd6818_agc_atten_db(&a) == 32);
	// The reading is averaged with the one before: 222 then 142 is 182, 20 dB over, 12 dB down from -32: -45 dB (0x05E)
	CHECK(fd6818_agc_step(&a, 142));
	CHECK(fd6818_agc_word(&a) == 0x05E && fd6818_agc_atten_db(&a) == 45);
	// At the target: holds
	for (int k = 0; k < 50; k++) {
		CHECK(!fd6818_agc_step(&a, 142));
	}
	// The signal goes: 0x67 = 100 is 21 dB under. The gain waits out the hold (30 readings), then rises one step each
	// hold and a reading
	int steps = 0, first = -1;
	for (int k = 0; k < 200; k++) {
		if (fd6818_agc_step(&a, 100)) {
			steps++;
			if (first < 0) {
				first = k;
			}
		}
	}
	CHECK(first == 30);
	CHECK(steps == 6 && fd6818_agc_atten_db(&a) == 30);
	// The top of the table: never above full gain, never below the lowest entry
	fd6818_agc_reset(&a);
	for (int k = 0; k < 5; k++) {
		(void)fd6818_agc_step(&a, 511);
	}
	CHECK(fd6818_agc_atten_db(&a) == 93 && fd6818_agc_word(&a) == 0x000);
	// The bits above 8:0 aren't part of the reading
	fd6818_agc_reset(&a);
	CHECK(!fd6818_agc_step(&a, 0xFE00u | 142u));
}

// The AM squelch scale: noise_sq (0x65 bits 7:0) plus an offset that puts level 1 (opens below 64) at the chip's own
// noise threshold (0x4F bits 6:0). The DM-32's empty-channel floor (59 and up) stays shut at every level; the high
// byte (rssi_rel) is ignored
static void test_am_noise(void)
{
	uint8_t off = fd6818_am_noise_offset(0x302F);
	CHECK(off == 17 && fd6818_am_noise_offset(0x2A28) == 24);
	CHECK(fd6818_am_noise_offset(0x7F7F) == 0 && fd6818_am_noise_offset(0x0000) == 64);
	CHECK(fd6818_am_noise(46, off) < 64 && fd6818_am_noise(47, off) == 64);
	CHECK(fd6818_am_noise(59, off) > 64 + 3);	// above level 1 and its hysteresis
	CHECK(fd6818_am_noise(23, off) == 40);	// level 9 opens below 40: at 22
	CHECK(fd6818_am_noise(0x4B00u | 31u, off) == 48);
	CHECK(fd6818_am_noise(0xFFu, off) == 255 && fd6818_am_noise(240, off) == 255);
}

// RX sub-audio set-up in the radio's own order, and the 0x0C detect bits
static void test_rx_tones(void)
{
	fd6818_t dev;
	reset_chip();
	fd6818_attach(&dev, bus());

	fd6818_set_rx_tone(&dev, FD6818_TONE_CTCSS, 1000);	// 100.0 Hz
	CHECK(chip.n == 4);
	CHECK(chip.log[0].reg == 0x07 && chip.log[0].val == 0x0811);
	CHECK(chip.log[1].reg == 0x07 && chip.log[1].val == 0x21CE);
	CHECK(chip.log[2].reg == 0x52 && chip.log[2].val == 0x028F);
	CHECK(chip.log[3].reg == 0x51 && chip.log[3].val == 0x9045);

	chip.n = 0;
	fd6818_set_rx_tone(&dev, FD6818_TONE_DCS, 023);	// the datasheet's example: word 0x763813
	CHECK(chip.n == 4);
	CHECK(chip.log[0].reg == 0x07 && chip.log[0].val == 0x0AD7);
	CHECK(chip.log[1].reg == 0x08 && chip.log[1].val == 0x0813);
	CHECK(chip.log[2].reg == 0x08 && chip.log[2].val == 0x8763);
	CHECK(chip.log[3].reg == 0x51 && chip.log[3].val == 0x8045);

	chip.n = 0;
	fd6818_set_rx_tone(&dev, FD6818_TONE_DCS_INV, 023);
	CHECK(chip.n == 4 && chip.log[3].reg == 0x51 && chip.log[3].val == 0xA045);

	chip.n = 0;
	fd6818_set_rx_tone(&dev, FD6818_TONE_NONE, 0);
	CHECK(chip.n == 3);
	CHECK(chip.log[0].reg == 0x07 && chip.log[0].val == 0x0470);
	CHECK(chip.log[1].reg == 0x07 && chip.log[1].val == 0x21CE);
	CHECK(chip.log[2].reg == 0x51 && chip.log[2].val == 0);

	CHECK(fd6818_tone_found(0x0000, FD6818_TONE_NONE));
	CHECK(fd6818_tone_found(0x0400, FD6818_TONE_CTCSS) && !fd6818_tone_found(0xC000, FD6818_TONE_CTCSS));
	CHECK(fd6818_tone_found(0x4000, FD6818_TONE_DCS) && !fd6818_tone_found(0x8400, FD6818_TONE_DCS));
	CHECK(fd6818_tone_found(0x8000, FD6818_TONE_DCS_INV) && !fd6818_tone_found(0x4400, FD6818_TONE_DCS_INV));

	chip.regs[0x0C] = 0x4000;
	CHECK(fd6818_rx_tone_ok(&dev, FD6818_TONE_DCS) && !fd6818_rx_tone_ok(&dev, FD6818_TONE_CTCSS));
	CHECK(fd6818_rx_tone_ok(&dev, FD6818_TONE_NONE));
}

// The DM-1801 Pro set (docs/spec/hardware-dm1801pro.md 5): its own tables, the 0x0200 step, no 0x1A word
static void test_dm1801pro(void)
{
	fd6818_t dev;
	reset_chip();
	fd6818_attach_variant(&dev, bus(), &fd6818_variant_b);
	fd6818_init(&dev);
	CHECK(chip.log[0].reg == 0x00 && chip.log[0].val == 0x8000);
	CHECK(chip.log[chip.n - 1].reg == 0x24 && chip.log[chip.n - 1].val == 0x8C7E);
	CHECK(dev.freq_10hz == 0);
	CHECK(chip.protocol_errors == 0);

	chip.n = 0;
	fd6818_set_freq(&dev, 446000000u);
	CHECK(chip.n == 4);
	CHECK(chip.log[0].reg == 0x30 && chip.log[0].val == 0);
	CHECK(chip.log[1].reg == 0x40 && chip.log[1].val == 0x34F0);	// no 0x1A write
	CHECK(chip.log[2].reg == 0x38 && chip.log[2].val == 0x8AC0);
	CHECK(chip.log[3].reg == 0x39 && chip.log[3].val == 0x02A8);	// 446.000 MHz = 0x02A88AC0

	chip.n = 0;
	fd6818_set_state(&dev, FD6818_STATE_RX);
	CHECK(chip.n == 3 && chip.log[0].reg == 0x37 && chip.log[1].val == 0x0200 && chip.log[2].val == 0xBFF1);
	chip.n = 0;
	fd6818_set_state(&dev, FD6818_STATE_TX);
	CHECK(chip.n == 5 && chip.log[0].val == FD6818_STATE_IDLE && chip.log[1].reg == 0x37 && chip.log[2].reg == 0x52 &&
		chip.log[3].val == 0x0200 && chip.log[4].val == 0xC1FE);
	CHECK(dev.state == 0xC1FE);
	chip.n = 0;
	fd6818_set_state(&dev, FD6818_STATE_IDLE);
	CHECK(chip.n == 1 && dev.state == 0);

	// DMR is the five mode registers and 0x3F = 0 (the radio's DMR receive value, 5.4); going back to FM restores 0x48
	// and ends on the 0x2B mode word
	chip.n = 0;
	fd6818_set_mode(&dev, FD6818_MODE_DMR);
	CHECK(chip.n == 6 && chip.log[0].reg == 0x47 && chip.log[0].val == 0x0140 && chip.log[1].reg == 0x48 &&
		chip.log[1].val == 0xB2F5 && chip.log[2].reg == 0x7E && chip.log[2].val == 0xB03F &&
		chip.log[3].reg == 0x2B && chip.log[3].val == 0x0700);
	CHECK(chip.log[5].reg == 0x3F && chip.log[5].val == 0x0000);
	chip.n = 0;
	fd6818_set_mode(&dev, FD6818_MODE_FM);
	CHECK(chip.n == 6 && chip.log[3].reg == 0x48 && chip.log[3].val == 0xB386 && chip.log[5].reg == 0x2B &&
		chip.log[5].val == 0xC000);

	// A DMR burst switches straight between the final words: no idle, no bandwidth
	chip.n = 0;
	fd6818_dmr_burst(&dev, true, dev.variant->bw_dmr);
	CHECK(chip.n == 2 && chip.log[0].reg == 0x52 && chip.log[1].reg == 0x30 && chip.log[1].val == 0xC1FE);
	chip.n = 0;
	fd6818_dmr_burst(&dev, false, dev.variant->bw_dmr);
	CHECK(chip.n == 1 && chip.log[0].reg == 0x30 && chip.log[0].val == 0xBFF1);
	CHECK(chip.protocol_errors == 0);
}

// A variant with burst tables switches straight between the two states: only the table, no idle, no bandwidth
static void test_burst_tables(void)
{
	static const fd6818_regval_t brx[] = { { 0x30, 0xBFF1 } };
	static const fd6818_regval_t btx[] = { { 0x52, 0x028F }, { 0x30, 0xC1FE } };
	fd6818_variant_t v = fd6818_variant_b;
	v.burst_rx = brx;
	v.burst_rx_n = 1;
	v.burst_tx = btx;
	v.burst_tx_n = 2;
	fd6818_t dev;
	reset_chip();
	fd6818_attach_variant(&dev, bus(), &v);
	chip.n = 0;
	fd6818_dmr_burst(&dev, true, v.bw_dmr);
	CHECK(chip.n == 2 && chip.log[0].reg == 0x52 && chip.log[0].val == 0x028F && chip.log[1].reg == 0x30 &&
		chip.log[1].val == 0xC1FE);
	chip.n = 0;
	fd6818_dmr_burst(&dev, false, v.bw_dmr);
	CHECK(chip.n == 1 && chip.log[0].reg == 0x30 && chip.log[0].val == 0xBFF1);
	CHECK(chip.protocol_errors == 0);
	// The DM-32UV's set has none: idle first
	fd6818_attach_variant(&dev, bus(), &fd6818_variant_default);
	chip.n = 0;
	fd6818_dmr_burst(&dev, true, FD6818_BW_DMR);
	CHECK(chip.n >= 2 && chip.log[0].reg == 0x30 && chip.log[0].val == 0);
}

// A split DMR channel (RX 443.700 / TX 448.700): the burst switch moves the synthesizer to the TX frequency for a
// burst and back to the RX frequency after it. Simplex: no frequency frames (issue 72: the radio stayed on the TX
// frequency between bursts and never heard the hotspot's downlink)
static void test_burst_split(void)
{
	const fd6818_variant_t *vars[] = { &fd6818_variant_default, &fd6818_variant_b };
	for (unsigned i = 0; i < 2; i++) {
		fd6818_t dev;
		reset_chip();
		fd6818_attach_variant(&dev, bus(), vars[i]);
		fd6818_set_freq(&dev, 443700000u);
		chip.n = 0;
		fd6818_dmr_burst_at(&dev, true, FD6818_BW_DMR, 448700000u);
		CHECK(chip.regs[0x38] == (uint16_t)(44870000u & 0xFFFFu) && chip.regs[0x39] == (44870000u >> 16));
		CHECK(chip.log[0].reg == 0x30 && chip.log[0].val == 0);	// idle first, then the frequency
		CHECK(chip.log[chip.n - 1].reg == 0x30 || chip.log[chip.n - 1].reg == 0x52);
		chip.n = 0;
		fd6818_dmr_burst_at(&dev, false, FD6818_BW_DMR, 443700000u);
		CHECK(chip.regs[0x38] == (uint16_t)(44370000u & 0xFFFFu) && chip.regs[0x39] == (44370000u >> 16));
		// Already on that frequency (simplex, or the second burst of a pair on one frequency): only the switch
		int n_switch = chip.n;
		chip.n = 0;
		fd6818_dmr_burst_at(&dev, false, FD6818_BW_DMR, 443700000u);
		CHECK(chip.n > 0 && chip.n < n_switch);
		for (int k = 0; k < chip.n; k++) {
			CHECK(chip.log[k].reg != 0x38 && chip.log[k].reg != 0x39);
		}
		// hz 0: never retunes
		chip.n = 0;
		fd6818_dmr_burst_at(&dev, true, FD6818_BW_DMR, 0);
		for (int k = 0; k < chip.n; k++) {
			CHECK(chip.log[k].reg != 0x38 && chip.log[k].reg != 0x39);
		}
		CHECK(chip.protocol_errors == 0);
	}
}

// The lock poll (0x0C bit 9) and set-up B's two DMR word sets: the newer DM-32UV RF section's differs from the DM-1801
// Pro's only in 0x47 / 0x48 (hardware-dm32.md 8.10)
static void test_setup_b(void)
{
	fd6818_t dev;
	reset_chip();
	fd6818_attach_variant(&dev, bus(), &fd6818_variant_b_dmr6943);
	chip.regs[0x0C] = 0x0280;
	CHECK(fd6818_pll_locked(&dev, 0));
	chip.regs[0x0C] = 0x0080;
	CHECK(!fd6818_pll_locked(&dev, 3));
	chip.regs[0x0C] = 0x0200;
	CHECK(fd6818_pll_locked(&dev, 3));

	fd6818_set_mode(&dev, FD6818_MODE_DMR);
	CHECK(chip.regs[0x47] == 0x6943 && chip.regs[0x48] == 0xB2FD);
	fd6818_attach_variant(&dev, bus(), &fd6818_variant_b);
	fd6818_set_mode(&dev, FD6818_MODE_DMR);
	CHECK(chip.regs[0x47] == 0x0140 && chip.regs[0x48] == 0xB2F5);
	const fd6818_variant_t *a = &fd6818_variant_b, *b = &fd6818_variant_b_dmr6943;
	CHECK(a->init == b->init && a->fm == b->fm && a->rx == b->rx && a->tx == b->tx && a->burst_rx == b->burst_rx &&
		a->burst_tx == b->burst_tx && a->bw_dmr == b->bw_dmr && a->dmr_n == b->dmr_n && a->dmr != b->dmr);
	CHECK(chip.protocol_errors == 0);
}

// fd6818_detect against a section that locks on some set-ups only, after some reads of 0x0C
static fd6818_t det_dev;
static const fd6818_variant_t *det_locks[2];	// the set-ups that lock this section
static const fd6818_variant_t *det_last;
static unsigned det_reads, det_slow;		// reads since the set-up changed; reads before det_locks[0] locks
static const uint16_t *det_seq;			// set: 0x0C reads in turn (a bit that flickers)

static uint16_t det_css(void)
{
	if (det_seq) {
		return *det_seq++;
	}
	if (det_dev.variant != det_last) {
		det_last = det_dev.variant;
		det_reads = 0;
	}
	det_reads++;
	bool ok = (det_dev.variant == det_locks[0] && det_reads > det_slow) || det_dev.variant == det_locks[1];
	return ok ? FD6818_CSS_PLL_LOCK : 0;
}

static uint8_t detect(const fd6818_variant_t *l0, const fd6818_variant_t *l1, unsigned slow)
{
	static const fd6818_variant_t *const v[] = { &fd6818_variant_default, &fd6818_variant_b_dmr6943 };
	reset_chip();
	chip.css = det_css;
	det_locks[0] = l0;
	det_locks[1] = l1;
	det_last = NULL;
	det_slow = slow;
	uint8_t i = fd6818_detect(&det_dev, bus(), v, 2, 145000000u, 20);
	CHECK(chip.protocol_errors == 0);
	return i;
}

static void test_detect(void)
{
	const fd6818_variant_t *a = &fd6818_variant_default, *b = &fd6818_variant_b_dmr6943;
	// Both lock the classic section, so the default is taken; only B locks the newer one; neither: none, left on A
	CHECK(detect(a, b, 0) == 0 && det_dev.variant == a);
	CHECK(detect(b, NULL, 0) == 1 && det_dev.variant == b);
	CHECK(detect(NULL, NULL, 0) == 2 && det_dev.variant == a && chip.regs[FD6818_REG_STATE] != FD6818_STATE_TX);
	// The default locks only after the first wait: B locks too, so A gets a longer try and is taken
	CHECK(detect(a, b, 25) == 0 && det_dev.variant == a);
	// Slower than the longer try as well: taken as B
	CHECK(detect(a, b, 70) == 1 && det_dev.variant == b);
	// A lock bit set once while settling is no lock
	static const uint16_t flicker[] = { FD6818_CSS_PLL_LOCK, 0, 0, 0, 0 };
	reset_chip();
	chip.css = det_css;
	det_seq = flicker;
	fd6818_attach_variant(&det_dev, bus(), &fd6818_variant_default);
	CHECK(!fd6818_pll_locked(&det_dev, 2));
	static const uint16_t settle[] = { FD6818_CSS_PLL_LOCK, 0, FD6818_CSS_PLL_LOCK, FD6818_CSS_PLL_LOCK,
					   FD6818_CSS_PLL_LOCK };
	det_seq = settle;
	CHECK(fd6818_pll_locked(&det_dev, 2));
	det_seq = NULL;
	chip.css = NULL;
}

int main(void)
{
	test_setup_b();
	test_detect();
	test_burst_split();
	test_dm1801pro();
	test_burst_tables();
	test_helpers();
	test_rssi_cal();
	test_frames();
	test_sequences();
	test_rx_tones();
	test_rx_sleep();
	test_am();
	test_am_agc();
	test_am_noise();
	if (failures) {
		printf("fd6818Test: %d failures\n", failures);
		return 1;
	}
	printf("fd6818Test: all passed\n");
	return 0;
}
