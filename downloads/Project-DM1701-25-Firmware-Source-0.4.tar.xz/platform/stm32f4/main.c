// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The RadioFoundry Authors
// STM32F4 entry: platform set-up, the board's early init, then the core application under FreeRTOS
#include "config.h"
#include "platform.h"
#include "board.h"
#include "hal_watchdog.h"
#include "FreeRTOS.h"
#include "task.h"

// gotchas.md 13.11: the syscall level must fit the 3 priority bits of the APM32F4 clones
_Static_assert((configMAX_SYSCALL_INTERRUPT_PRIORITY & 0x1Fu) == 0u,
	"configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY must be even (3 priority bits)");

void stm32_time_init(void);
void app_start(void);	// core/app: creates the tasks

int main(void)
{
	board_rf_safe();	// transmitter off before anything that could hang (docs/spec/crash-log.md 8)
	stm32_sysboot_check();	// REBOOT ROM-DFU: into the ROM bootloader before anything is set up
	stm32_irq_stack_fill();	// before the first interrupt: the main stack's high water mark and canary (irq_stack.c)
#if CONFIG_WATCHDOG
	hal_watchdog_start();	// after the ROM entry check: the IWDG can't be stopped and the ROM never feeds it
#endif
	HAL_Init();
	HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);	// all 4 bits preemption (FreeRTOS needs this)
	stm32_time_init();
	board_early_init();	// its busy waits feed (hal_delay_ms before the scheduler)
	stm32_time_init();		// the clock changed; restart the count from the new rate
#if CONFIG_WATCHDOG
	hal_watchdog_feed();
#endif
	app_start();
#if CONFIG_WATCHDOG
	hal_watchdog_feed();	// the start-up task's first work runs before the idle task does
#endif
	vTaskStartScheduler();
	for (;;) {
	}
}

// Without the crash log a crash stops the radio here (core/crash and crash_stm32.c otherwise: kept and restarted)
#if !CONFIG_CRASH_LOG
void vApplicationStackOverflowHook(TaskHandle_t task, char *name)
{
	(void)task;
	(void)name;
	__disable_irq();
	board_rf_safe();
	for (;;) {
	}
}

void vApplicationMallocFailedHook(void)
{
	__disable_irq();
	board_rf_safe();
	for (;;) {
	}
}

void HardFault_Handler(void)
{
	__disable_irq();
	board_rf_safe();
	for (;;) {
	}
}

void NMI_Handler(void) __attribute__((alias("HardFault_Handler")));
#endif
