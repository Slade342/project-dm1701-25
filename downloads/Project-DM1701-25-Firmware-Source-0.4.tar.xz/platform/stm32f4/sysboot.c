// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The RadioFoundry Authors
// STM32F4 system services (hal_system.h): chip identity and option bytes, memory reads, SoC registers, reboot, and the
// software entry to the MCU's ROM bootloader (docs/spec/hardware-dm1701.md "Software entry to a bootloader").
//
// ROM DFU entry: the request stores a flag in an RTC backup register (kept through a system reset, unlike RAM, which
// the stock bootloader runs in before the application) and resets. The stock bootloader then starts the application
// as usual, and stm32_sysboot_check(), first thing in main(), finds the flag, clears it (so a failed entry boots
// normally next time), puts the board in its reset-time pin state (board_sysboot_prepare: the power latch stays
// high), returns clocks and peripherals to their reset state, maps system memory at 0 and jumps to the ROM's reset
// vector.
#include <string.h>
#include "config.h"
#include "platform.h"
#include "board.h"
#include "hal_system.h"
#include "mem_window.h"
#if CONFIG_CRASH_LOG
#include "hal_crash.h"
#endif

#define SYSBOOT_MAGIC		0xB007DF11u	// in RTC_BKP19R: enter the ROM bootloader on the next start
#define SYSMEM_BASE		0x1FFF0000u
#define SYSMEM_END		0x1FFF7800u
#define UID_BASE_ADDR		0x1FFF7A10u
#define FLASH_SIZE_ADDR		0x1FFF7A22u
#define SPIN_LIMIT		1000000u

__attribute__((weak)) void board_sysboot_prepare(void)
{
}

static bool chip(hal_chip_t *c)
{
	c->idcode = DBGMCU->IDCODE;
	c->flash_kb = *(volatile const uint16_t *)FLASH_SIZE_ADDR;
	c->uid[0] = *(volatile const uint32_t *)(UID_BASE_ADDR + 0u);
	c->uid[1] = *(volatile const uint32_t *)(UID_BASE_ADDR + 4u);
	c->uid[2] = *(volatile const uint32_t *)(UID_BASE_ADDR + 8u);
	c->optcr = FLASH->OPTCR;
	c->family = HAL_CHIP_STM32F4;
	return true;
}

// Whole aligned words are read one 32-bit load at a time: that is what a register block needs (mem_window.h refuses
// anything else there), and memcpy may use byte loads
static void read(uint32_t addr, void *dst, size_t n)
{
	if (((addr | n) & 3u) != 0) {
		memcpy(dst, (const void *)(uintptr_t)addr, n);
		return;
	}
	uint8_t *d = dst;
	for (size_t i = 0; i < n; i += 4u) {
		uint32_t v = *(volatile const uint32_t *)(uintptr_t)(addr + i);
		memcpy(d + i, &v, 4u);
	}
}

static bool mem_window(unsigned i, hal_mem_window_t *w)
{
	return stm32_mem_window_for(i, w, *(volatile const uint16_t *)FLASH_SIZE_ADDR);
}

#if CONFIG_DEBUGLINK
#define BUS_ERRORS	(SCB_CFSR_PRECISERR_Msk | SCB_CFSR_IMPRECISERR_Msk | SCB_CFSR_BFARVALID_Msk)

// CHIP_REG's SoC registers (mem_window.h). The write and its read back run at priority -1 (FAULTMASK), so no handler
// changes the register between them, and with data bus faults ignored there (CCR.BFHFNMIGN): a reserved address inside
// the windows is refused instead of crashing the radio. The write goes around the write buffer (ACTLR.DISDEFWBUF), so
// its fault, if any, is precise and lands here rather than after FAULTMASK is lifted
static bool reg(uint32_t addr, uint32_t *val, bool write)
{
	if (!stm32_reg_allowed(addr)) {
		return false;
	}
	uint32_t fm = __get_FAULTMASK();
	__disable_fault_irq();
	uint32_t before = SCB->CFSR & BUS_ERRORS;
	SCB->CCR |= SCB_CCR_BFHFNMIGN_Msk;
	__DSB();
	__ISB();
	if (write) {
		SCnSCB->ACTLR |= SCnSCB_ACTLR_DISDEFWBUF_Msk;
		__DSB();
		__ISB();
		*(volatile uint32_t *)(uintptr_t)addr = *val;
		__DSB();
		SCnSCB->ACTLR &= ~SCnSCB_ACTLR_DISDEFWBUF_Msk;
	}
	uint32_t v = *(volatile const uint32_t *)(uintptr_t)addr;
	__DSB();
	SCB->CCR &= ~SCB_CCR_BFHFNMIGN_Msk;
	uint32_t err = SCB->CFSR & BUS_ERRORS & ~before;
	if (err != 0) {
		SCB->CFSR = err;	// write 1 to clear: only the flags this access set
	}
	__DSB();
	__ISB();
	__set_FAULTMASK(fm);
	if (err != 0) {
		return false;
	}
	*val = v;
	return true;
}
#endif

static void backup_write(uint32_t v)
{
	RCC->APB1ENR |= RCC_APB1ENR_PWREN;
	(void)RCC->APB1ENR;
	PWR->CR |= PWR_CR_DBP;
	RTC->BKP19R = v;
	(void)RTC->BKP19R;
}

static bool reboot(uint8_t mode)
{
	if (mode == HAL_REBOOT_ROM_DFU) {
		backup_write(SYSBOOT_MAGIC);
		if (RTC->BKP19R != SYSBOOT_MAGIC) {
			return false;
		}
	} else if (mode != HAL_REBOOT_NORMAL) {
		return false;
	}
	__disable_irq();
	board_rf_safe();	// a reset leaves the pins floating until the next start drives them: transmitter off first
#if CONFIG_CRASH_LOG
	hal_crash_soft_mark();	// asked for: not the watchdog (crash-log.md 1.3)
#endif
	NVIC_SystemReset();
	return false;	// not reached
}

const hal_system_t stm32_system = {
	.chip = chip,
	.read = read,
	.mem_window = mem_window,
	.reboot = reboot,
	.irq_stack_free = stm32_irq_stack_free,	// irq_stack.c
#if CONFIG_DEBUGLINK
	.reg = reg,
#endif
#if CONFIG_STUB_ENTRY
	.stub_region = stm32_stub_region,	// stub_entry.c
	.enter_stub = stm32_enter_stub,
	.stub_run_addr = 0x20000000u,		// the staging buffer is copied to the SRAM base at entry
	.stub_image_ok = stm32_stub_image_ok,	// with the IWDG running: only a stub that feeds it
#endif
};

static void spin_until(volatile uint32_t *reg, uint32_t mask, uint32_t want)
{
	for (uint32_t i = 0; i < SPIN_LIMIT && (*reg & mask) != want; i++) {
	}
}

void stm32_sysboot_check(void)
{
	RCC->APB1ENR |= RCC_APB1ENR_PWREN;
	(void)RCC->APB1ENR;
	if (RTC->BKP19R != SYSBOOT_MAGIC) {
		return;
	}
	backup_write(0);
	PWR->CR &= ~PWR_CR_DBP;
	if (RTC->BKP19R != 0) {
		return;	// can't clear it: entering anyway would loop into the ROM on every start
	}

	board_rf_safe();
	board_sysboot_prepare();

	__disable_irq();
	SysTick->CTRL = 0;
	SysTick->LOAD = 0;
	SysTick->VAL = 0;
	for (unsigned i = 0; i < sizeof(NVIC->ICER) / sizeof(NVIC->ICER[0]); i++) {
		NVIC->ICER[i] = 0xFFFFFFFFu;
		NVIC->ICPR[i] = 0xFFFFFFFFu;
	}

	// Clocks back to HSI 16 MHz, HSE and the PLLs off and at their reset values (the stock bootloader leaves
	// HSE/PLL running; the ROM sets its own clocks up)
	RCC->CR |= RCC_CR_HSION;
	spin_until(&RCC->CR, RCC_CR_HSIRDY, RCC_CR_HSIRDY);
	RCC->CFGR = 0;
	spin_until(&RCC->CFGR, RCC_CFGR_SWS, 0);
	RCC->CR &= ~(RCC_CR_PLLON | RCC_CR_PLLI2SON | RCC_CR_CSSON);
	spin_until(&RCC->CR, RCC_CR_PLLRDY | RCC_CR_PLLI2SRDY, 0);
	RCC->CR &= ~RCC_CR_HSEON;
	spin_until(&RCC->CR, RCC_CR_HSERDY, 0);
	RCC->CR &= ~RCC_CR_HSEBYP;
	RCC->PLLCFGR = 0x24003010u;
	RCC->PLLI2SCFGR = 0x20003000u;
	RCC->CIR = 0x00FF0000u;	// clear the ready flags, interrupts off
	RCC->CIR = 0;
	FLASH->ACR = 0;		// 0 wait states is right for 16 MHz; caches off

	// Peripherals to their reset state, except the GPIO ports (the board's pin levels above, the power latch)
	RCC->AHB1RSTR = RCC_AHB1RSTR_DMA1RST | RCC_AHB1RSTR_DMA2RST | RCC_AHB1RSTR_OTGHRST | RCC_AHB1RSTR_CRCRST;
	RCC->AHB2RSTR = 0xFFFFFFFFu;
	RCC->AHB3RSTR = 0xFFFFFFFFu;
	RCC->APB1RSTR = 0xFFFFFFFFu;
	RCC->APB2RSTR = 0xFFFFFFFFu;
	RCC->AHB1RSTR = 0;
	RCC->AHB2RSTR = 0;
	RCC->AHB3RSTR = 0;
	RCC->APB1RSTR = 0;
	RCC->APB2RSTR = 0;
	RCC->AHB1ENR &= 0x000001FFu;	// GPIOA..GPIOI only
	RCC->AHB2ENR = 0;
	RCC->AHB3ENR = 0;
	RCC->APB1ENR = 0;
	RCC->APB2ENR = RCC_APB2ENR_SYSCFGEN;
	(void)RCC->APB2ENR;

	uint32_t sp = *(volatile const uint32_t *)SYSMEM_BASE;
	uint32_t pc = *(volatile const uint32_t *)(SYSMEM_BASE + 4u);
	if (sp < 0x20000000u || sp > 0x20020000u || pc < SYSMEM_BASE || pc >= SYSMEM_END) {
		NVIC_SystemReset();	// not a ROM vector table: boot normally (the flag is gone)
	}
	SYSCFG->MEMRMP = SYSCFG_MEMRMP_MEM_MODE_0;	// system flash at 0
	SCB->VTOR = 0;
	__DSB();
	__ISB();
	__enable_irq();		// the reset state; nothing can interrupt now (NVIC cleared, SysTick off)
	__asm volatile("msr msp, %0\n\tbx %1" : : "r"(sp), "r"(pc) : "memory");
	__builtin_unreachable();
}
