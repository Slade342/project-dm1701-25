// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The RadioFoundry Authors
// HR_C7000 DMR modem glue (dmr_glue.h): the slot engine (drivers/modem/hrc7000/hrc7000_dmr.c) on the SoC's modem
// interrupts, the DMR PA one-shot on Timer 3, and the deferred event task that calls the DMR stack (docs/spec/dmr-modem.md
// 6, modem-hrc7000.md 3, hardware-dm32.md 8.5, 8.6).
//
// What runs where (all interrupts at one level, never nested; this file and the engine run from RAM,
// the board's linker script, but for the task-side code marked HRC_FLASHFUNC):
//   PIC 29 (system)      received bursts, late entry, slot abnormal; clears the chip's flags
//   PIC 30 / 31 (TS)     decide the coming slot (TX burst, receive, nothing), PA off after a burst, slot tick event
//   PIC 32 (RF TX)       FD6818 idle -> TX for our burst
//   Timer 3              PA one-shot, armed with every burst: PA select and drive "DMR PA" ms later
//   "dmr" task           drains the engine's events into the stack's callback; every 10 ms the stall watchdog
// Task-level calls into the engine mask the modem sources at the PIC (hrc_modem_irqs_mask) for their register work.
#include <stddef.h>
#include <string.h>
#include "config.h"
#include "dmr_glue.h"

#if CONFIG_DMR	// the whole file: DMR only
#include "platform.h"
#include "modem/hrc7000/hrc7000_dmr.h"
#if defined(CONFIG_HOTSPOT_SPLIT) && CONFIG_HOTSPOT_SPLIT
#include "modem/hrc7000/hrc7000_bs.h"
#include "dmr/bsOutbound.h"
#endif
#include "audio_pcm.h"
#include "hal_time.h"
#include "FreeRTOS.h"
#include "task.h"

#define DMR_TASK_PRIORITY	(configMAX_PRIORITIES - 2)
#define DMR_TASK_STACK		512	// words: the stack's callback runs on it
#define DMR_POLL_MS		10

static hrc7000_dmr_t eng;
static const hrc_dmr_board_t *brd;
static TaskHandle_t task;
static volatile bool active;
static volatile bool rf_on_rx;	// the last burst switch put the RF back to receive (hrc_dmr_tx_end)
static dmr_event_cb_t volatile stack_cb;
static void *volatile stack_ctx;

// --- Engine ops ---

static uint32_t now_us(void *ctx)
{
	(void)ctx;
	return hrc_micros();
}

static uint32_t lock_saved;
static uint32_t lock_depth;

static void lock(void *ctx)
{
	(void)ctx;
	uint32_t s = hrc_irq_save();
	if (lock_depth++ == 0) {
		lock_saved = hrc_modem_irqs_mask();
	}
	hrc_irq_restore(s);
}

static void unlock(void *ctx)
{
	(void)ctx;
	uint32_t s = hrc_irq_save();
	if (lock_depth > 0 && --lock_depth == 0) {
		hrc_modem_irqs_restore(lock_saved);
	}
	hrc_irq_restore(s);
}

static void notify(void *ctx)
{
	(void)ctx;
	if (task == NULL) {
		return;
	}
	if (hrc_in_isr()) {
		BaseType_t woken = pdFALSE;
		vTaskNotifyGiveFromISR(task, &woken);
		portYIELD_FROM_ISR(woken);
	} else {
		xTaskNotifyGive(task);
	}
}

// A split duplex hotspot's base-station outbound keys once for its whole length (hrc7000_bs.c)
static bool outbound_continuous(void)
{
#if defined(CONFIG_HOTSPOT_SPLIT) && CONFIG_HOTSPOT_SPLIT
	return eng.bs != NULL;
#else
	return false;
#endif
}

static void rf(void *ctx, bool tx)
{
	(void)ctx;
	if (brd->burst != NULL) {
		hrc_rfburst_switch(tx, outbound_continuous(), eng.t_tick);
	} else if (brd->rf_switch != NULL) {
		brd->rf_switch(tx);
	}
	rf_on_rx = !tx;
}

static void pa_arm(void *ctx)
{
	(void)ctx;
	// The burst sequences key the PA themselves; a board with neither has no PA key (and no pa_delay_us)
	if (brd->burst == NULL && brd->pa_on != NULL) {
		hrc_timer_oneshot(TIMER_PA, brd->pa_delay_us);
	}
}

static const hrc7000_dmr_ops_t ops = {
	.rf = rf, .pa_arm = pa_arm, .now_us = now_us, .lock = lock, .unlock = unlock, .notify = notify, .ctx = NULL,
};

// --- Interrupts ---

static void isr_sys(void) { hrc7000_dmr_isr_sys(&eng); }
static void isr_ts_tx(void) { hrc7000_dmr_isr_timeslot(&eng, true); }
static void isr_ts_rx(void) { hrc7000_dmr_isr_timeslot(&eng, false); }
static void isr_rftx(void) { hrc7000_dmr_isr_rftx(&eng); }

static void isr_pa_timer(void)
{
	hrc_timer_ack(TIMER_PA);
	hrc_timer_stop(TIMER_PA);
	if (active && brd->pa_on != NULL) {
		brd->pa_on();
	}
}

static void irqs_enable(bool on)
{
	hrc_irq_enable(IRQ_MODEM_SYS, on || eng.fm_rx != NULL);	// FM receive audio uses it outside DMR too
	hrc_irq_enable(IRQ_MODEM_TS_TX, on);
	hrc_irq_enable(IRQ_MODEM_TS_RX, on);
	hrc_irq_enable(IRQ_MODEM_RF_TX, on);
	if (!on) {
		hrc_timer_stop(TIMER_PA);
	}
}

// --- Lost interrupts (hal_dmr_modem_t.health) ---

static uint32_t lost_seen;	// stalls + stuck requests at the last check
static uint32_t lost_ms;	// the first one's time (never 0 once set) and the PIC's words just before it was handled
static uint32_t lost_regs[4];

// The PIC's mask and request words, read before each poll: after it, the poll's recovery has dropped the requests
HRC_FLASHFUNC static void pic_words(uint32_t w[4])
{
	w[0] = PIC_MASK;
	w[1] = PIC_MASK_1;
	w[2] = PIC_INT_ST;
	w[3] = PIC_INT_ST_1;
}

// The poll found a lost interrupt (a stalled transmission or a request pending with no handler run): keep the first
// one's PIC words, and unmask the modem sources again unless a task is inside the engine
HRC_FLASHFUNC static void lost_check(const uint32_t before[4])
{
	uint32_t n = eng.st.stalls + eng.st.sys_stuck;
	if (n == lost_seen) {
		return;
	}
	lost_seen = n;
	if (lost_ms == 0) {
		memcpy(lost_regs, before, sizeof lost_regs);
		lost_ms = hal_millis() | 1u;
	}
	uint32_t s = hrc_irq_save();
	if (active && lock_depth == 0) {
		irqs_enable(true);
	}
	hrc_irq_restore(s);
}

HRC_FLASHFUNC static void health(dmr_modem_health_t *h)
{
	h->stalls = eng.st.stalls;
	h->stuck = eng.st.sys_stuck;
	h->first_ms = lost_ms;
	memcpy(h->first_regs, lost_regs, sizeof h->first_regs);
}

// --- Deferred event task ---

HRC_FLASHFUNC static void dmr_task(void *arg)
{
	(void)arg;
	dmr_event_t ev;
	dmr_burst_t burst;
	for (;;) {
		ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(DMR_POLL_MS));
		if (active) {
			uint32_t pic[4];
			pic_words(pic);
			hrc7000_dmr_poll(&eng);
			lost_check(pic);
		}
		while (hrc7000_dmr_pop(&eng, &ev, &burst)) {
			dmr_event_cb_t cb = stack_cb;
			if (cb != NULL) {
				cb(&ev, stack_ctx);
			}
		}
	}
}

// --- The radio's interface ---

HRC_FLASHFUNC void hrc_dmr_board_init(hrc7000_t *modem, const hrc_dmr_board_t *hooks)
{
	brd = hooks;
	hrc7000_dmr_init(&eng, modem, &ops);
	hrc_irq_register(IRQ_MODEM_SYS, isr_sys);
	hrc_irq_register(IRQ_MODEM_TS_TX, isr_ts_tx);
	hrc_irq_register(IRQ_MODEM_TS_RX, isr_ts_rx);
	hrc_irq_register(IRQ_MODEM_RF_TX, isr_rftx);
	hrc_irq_register(IRQ_TIMER3, isr_pa_timer);
	hrc_irq_enable(IRQ_TIMER3, true);
	irqs_enable(false);
	if (hooks->burst != NULL) {
		hrc_rfburst_init(modem, hooks->burst);
	}
	if (task == NULL) {
		xTaskCreate(dmr_task, "dmr", DMR_TASK_STACK, NULL, DMR_TASK_PRIORITY, &task);
	}
}

void hrc_dmr_enter(void)
{
	rf_on_rx = false;
	hrc7000_dmr_run(&eng);
	active = true;
	irqs_enable(true);
}

void hrc_dmr_leave(void)
{
	irqs_enable(false);
	active = false;
	hrc7000_dmr_halt(&eng);
	rf_on_rx = false;	// after the halt: its switch back to RX doesn't count outside DMR
}

bool hrc_dmr_fm_rx_hook(void (*fn)(void))
{
	uint32_t s = hrc_irq_save();
	eng.fm_rx = fn;
	hrc_irq_restore(s);
	hrc_irq_enable(IRQ_MODEM_SYS, active || fn != NULL);
	return true;
}

bool hrc_dmr_tx_end(void)
{
	if (!rf_on_rx || brd == NULL || brd->tx_end == NULL) {
		return false;
	}
	rf_on_rx = false;	// once: a later rx() is a full set-up
	brd->tx_end();
	return true;
}

void hrc_dmr_rx_restart(void)
{
	rf_on_rx = false;
	hrc7000_dmr_rx_restart(&eng);
}

bool hrc_dmr_tx_active(void)
{
	return active && hrc7000_dmr_is_transmitting(&eng);
}

void hrc_dmr_tx_drop(void)
{
	if (!active) {
		return;
	}
	hrc7000_dmr_halt(&eng);		// PA off now, TX_DONE to the stack, engine off ...
	hrc7000_dmr_run(&eng);		// ... and on again, receiving
}

// --- hal_dmr_modem_t ---

static bool start(const dmr_config_t *cfg, dmr_event_cb_t cb, void *ctx)
{
	if (!active) {
		return false;	// the radio is not in DMR mode (set_mode(RADIO_MODE_DMR) first)
	}
	hrc7000_dmr_configure(&eng, cfg);
	stack_ctx = ctx;
	hrc_barrier();
	stack_cb = cb;
	return true;
}

static void stop(void)
{
	stack_cb = NULL;
	if (active && hrc7000_dmr_is_transmitting(&eng)) {
		hrc_dmr_tx_drop();
	}
}

static void configure(const dmr_config_t *cfg) { hrc7000_dmr_configure(&eng, cfg); }
static void rx_restart(void) { hrc7000_dmr_rx_restart(&eng); }
static void rx_lock_slot(int8_t ts) { hrc7000_dmr_rx_lock_slot(&eng, ts); }

// The prompt FIFO also feeds the modulator: its gate closes before the first burst can be armed, and audio_pcm.c opens
// it once the engine has stopped transmitting
static bool tx_begin(dmr_timing_t timing, int8_t ts, dmr_access_t access)
{
	hrc_audio_pcm_tx_gate();
	return active && hrc7000_dmr_tx_begin(&eng, timing, ts, access);
}

static bool tx_queue(const dmr_tx_burst_t *b) { return hrc7000_dmr_tx_queue(&eng, b); }
static uint8_t tx_queue_space(void) { return hrc7000_dmr_tx_queue_space(&eng); }
static void tx_listen(void) { hrc7000_dmr_tx_listen(&eng); }
static int8_t tx_fill(const dmr_tx_burst_t *b) { return hrc7000_dmr_tx_fill(&eng, b); }
static void tx_end(void) { hrc7000_dmr_tx_end(&eng); }
static void tx_abort(void) { hrc7000_dmr_tx_abort(&eng); }
static void set_embedded_lc(const uint8_t lc[9]) { hrc7000_dmr_set_embedded_lc(&eng, lc); }
static void set_cc_filter(int8_t cc) { hrc7000_dmr_set_cc_filter(&eng, cc); }
static bool is_transmitting(void) { return hrc7000_dmr_is_transmitting(&eng); }

#if defined(CONFIG_HOTSPOT_SPLIT) && CONFIG_HOTSPOT_SPLIT
// --- Split duplex (docs/spec/split-duplex.md 5): the slot clock and the TX half's BS outbound (hrc7000_bs.c) ---

static hrc7000_bs_t bs;

static uint32_t split_now_us(void)
{
	return hrc_micros();
}

static bool slot_clock(uint32_t *counter, uint32_t *t_us, int8_t *ts)
{
	return active && hrc7000_dmr_slot_clock(&eng, counter, t_us, ts);
}

static bool bs_start(const dmr_bs_config_t *cfg)
{
	return active && hrc7000_bs_start(&bs, &eng, cfg, bsOutboundRawSlot);
}

static void bs_key(bool on)
{
	if (on) {
		hrc_audio_pcm_tx_gate();	// as tx_begin
	}
	hrc7000_bs_key(&eng, on);
}

static bool bs_queue(int8_t ts, const dmr_tx_burst_t *b, const dmr_cach_t *cach, const uint8_t *emb_lc)
{
	return hrc7000_bs_queue(&eng, ts, b, cach, emb_lc);
}

static bool bs_queue_at(uint32_t counter, int8_t ts, const dmr_tx_burst_t *b, const dmr_cach_t *cach,
			const uint8_t *emb_lc)
{
	return hrc7000_bs_queue_at(&eng, counter, ts, b, cach, emb_lc);
}

static bool bs_restart(uint32_t t_us, int8_t ts) { return active && hrc7000_bs_restart(&eng, t_us, ts); }

static uint8_t bs_space(int8_t ts) { return hrc7000_bs_space(&eng, ts); }

static void bs_stop(void)
{
	if (hrc7000_bs_active(&eng)) {
		hrc7000_bs_stop(&eng);
	}
}

static bool bs_keyed(void) { return hrc7000_bs_keyed(&eng); }

#define SPLIT_OPS	.now_us = split_now_us, .slot_clock = slot_clock, .bs_start = bs_start, .bs_key = bs_key, \
			.bs_queue = bs_queue, .bs_space = bs_space, .bs_stop = bs_stop, .bs_keyed = bs_keyed, \
			.bs_cach = HRC7000_BS_CACH_METHOD, .bs_queue_at = bs_queue_at, .bs_restart = bs_restart, \
			.bs_air_delay_us = HRC7000_BS_AIR_DELAY_US,
#else
#define SPLIT_OPS
#endif

const hal_dmr_modem_t hrc_dmr = {
	.start = start, .stop = stop, .configure = configure, .rx_restart = rx_restart, .rx_lock_slot = rx_lock_slot,
	.tx_begin = tx_begin, .tx_queue = tx_queue, .tx_queue_space = tx_queue_space, .tx_listen = tx_listen, .tx_end = tx_end,
	.tx_abort = tx_abort, .set_embedded_lc = set_embedded_lc, .set_cc_filter = set_cc_filter,
	.is_transmitting = is_transmitting, .tx_fill = tx_fill, .health = health,
	SPLIT_OPS
};

// --- Bring-up counters (the board's diagnostics page shows these lines first) ---

HRC_FLASHFUNC void hrc_dmr_stats_reset(void)
{
	// Every field before last_rx_type_info is a uint32_t counter (hrc7000_dmr.h); the ISRs update them
	lock(NULL);
	memset(&eng.st, 0, offsetof(hrc7000_dmr_stats_t, last_rx_type_info));
	lost_seen = 0;	// the loss record goes with its counters: health() would show a first loss from before the reset
	lost_ms = 0;
	memset(lost_regs, 0, sizeof lost_regs);
	unlock(NULL);
	hrc_audio_pcm_gate_reset();	// its line is one of ours
}

typedef struct {
	char *p, *end;
} out_t;

HRC_FLASHFUNC static void put(out_t *o, const char *s)
{
	while (*s && o->p < o->end) {
		*o->p++ = *s++;
	}
}

HRC_FLASHFUNC static void put_u(out_t *o, uint32_t v)
{
	char t[11];
	int n = 0;
	do {
		t[n++] = (char)('0' + v % 10u);
		v /= 10u;
	} while (v && n < 10);
	while (n && o->p < o->end) {
		*o->p++ = t[--n];
	}
}

HRC_FLASHFUNC static void put_x(out_t *o, uint32_t v, int digits)
{
	for (int i = digits - 1; i >= 0 && o->p < o->end; i--) {
		*o->p++ = "0123456789ABCDEF"[(v >> (4 * i)) & 0xFu];
	}
}

HRC_FLASHFUNC static void put_kv(out_t *o, const char *k, uint32_t v)
{
	put(o, k);
	put_u(o, v);
}

// Lines of at most about 20 characters (the 120-pixel-wide diagnostics page)
HRC_FLASHFUNC bool hrc_dmr_stats_line(uint8_t i, char *buf, uint8_t len)
{
	if (len == 0) {
		return false;
	}
	hrc7000_dmr_stats_t m;
	lock(NULL);
	m = eng.st;
	unlock(NULL);
	out_t o = { buf, buf + len - 1 };
	switch (i) {
	case 0:		// alive: ticks climb by 33 per second once a DMR signal gave the chip timing
		put(&o, active ? "DMR on" : "DMR off");
		put(&o, stack_cb != NULL ? "+cb" : "");
		put_kv(&o, " tk", m.ticks);
		break;
	case 1:
		put_kv(&o, "ts ", m.ts_tx_ints);
		put_kv(&o, "/", m.ts_rx_ints);
		put_kv(&o, " si", m.sys_ints);
		break;
	case 2:
		put_kv(&o, "V", m.rx_voice);
		put_kv(&o, " H", m.rx_lc_header);
		put_kv(&o, " T", m.rx_terminator);
		put_kv(&o, " I", m.rx_idle);
		break;
	case 3:
		put_kv(&o, "C", m.rx_csbk);
		put_kv(&o, " D", m.rx_data);
		put_kv(&o, " crc", m.rx_crc_err);
		put_kv(&o, " u", m.rx_unusable);
		break;
	case 4:
		put_kv(&o, "le", m.late_entry);
		put_kv(&o, " ab", m.slot_abnormal);
		put_kv(&o, " rs", m.rx_restarts);
		put_kv(&o, "/", m.rx_lost);
		put_kv(&o, "/", m.rx_stale);
		put_kv(&o, " h", m.rx_holds);
		put_kv(&o, " st", m.stalls);
		break;
	case 5:		// last burst: CC, TS; raw RX_TYPE_INFO
		put_kv(&o, "cc", m.last_cc);
		put_kv(&o, " ts", (uint32_t)(m.last_ts < 0 ? 0 : m.last_ts));
		put(&o, " ");
		put_x(&o, m.last_rx_type_info, 8);
		break;
	case 6:		// raw SYS_INTERP list and LAYER2 status of the last interrupts
		put_x(&o, m.last_sys_list, 5);
		put(&o, " ");
		put_x(&o, m.last_l2_status, 8);
		put_kv(&o, " k", m.sys_stuck);
		break;
	case 7:
		put_kv(&o, "tx", m.tx_bursts);
		put_kv(&o, " rf", m.rftx_ints);
		put_kv(&o, " pa", m.last_pa_ms);
		put_kv(&o, " s", m.tx_state);
		break;
	case 8:
		put_kv(&o, "un", m.tx_underrun);
		put_kv(&o, " rj", m.tx_rejected);
		put_kv(&o, " ok", m.tx_done);
		put_kv(&o, " ov", m.ev_overflow);
		put_kv(&o, " L", m.rx_in_tx[0]);
		put_kv(&o, "/", m.rx_in_tx[1]);
		break;
	case 9:		// the last TX start's slot: timing (0 own, 1 aligned, 2 ASAP), TS asked, our chip slot; the reception
			// it came from: chip slot, TS, slot ticks since (255 none)
		put_kv(&o, "txb m", m.txb_timing);
		put_kv(&o, " ts", (uint32_t)(m.txb_ts < 0 ? 0 : m.txb_ts));
		put_kv(&o, " c", m.txb_chip_slot);
		put_kv(&o, " r", m.txb_rx_chip_slot);
		put_kv(&o, "/", (uint32_t)(m.txb_last_ts < 0 ? 0 : m.txb_last_ts));
		put_kv(&o, " a", m.txb_rx_age);
		break;
	case 10:	// its reception's raw RX_TYPE_INFO (b22 CACH TC, b19 chip slot); deframe ms into the slot at arming
		put(&o, "txb ");
		put_x(&o, m.txb_rx_type_info, 8);
		put_kv(&o, " d", m.txb_deframe_ms);
		break;
	case 11:	// through a repeater: TC lock count, ticks waited for it; an aligned start's first TX tick: the TC
			// estimate (repeater) or LAYER2_STATUS b31 (SFR) in b0, the next slot ours in b1, and its 0.1 ms after
			// the last receive tick (a multiple of 300 is on the received slot grid: 300 through a repeater, 600
			// for an SFR, whose first TX-vector interrupt skips a slot)
		put_kv(&o, "txh k", m.txb_tc_agree);
		put_kv(&o, " w", m.txb_lock_wait);
		put_kv(&o, " e", m.txa_est);
		put_kv(&o, " u", m.txa_rx_us);
		break;
#if defined(CONFIG_HOTSPOT_SPLIT) && CONFIG_HOTSPOT_SPLIT
	case 12:	// the split duplex TX half's BS outbound (split-duplex.md 11.6), as the HR_C6000 radios' "bs" line
		put_kv(&o, "bs sl", bs.st.slots);
		put_kv(&o, " b", bs.st.bursts);
		put_kv(&o, " u", bs.st.underruns);
		put_kv(&o, " k", bs.st.keyups);
		put_kv(&o, " c", bs.st.cach_written);
		put_kv(&o, " st", bs.st.stalls);
		break;
	case 13:	// its slot clock: timeslot interrupts and the boundaries they made, PHY_RDY, RF TX, late slots, the
			// longest gap (us)
		put_kv(&o, "bs ti", bs.st.ts_ints);
		put_kv(&o, " tt", bs.st.ts_ticks);
		put_kv(&o, " ph", bs.st.phy_ints);
		put_kv(&o, " ri", bs.st.rftx_ints);
		put_kv(&o, " lt", bs.st.late);
		put_kv(&o, " mg", bs.st.max_gap_us);
		break;
#endif
	case HRC_DMR_DIAG_LINES - 1: {	// the prompt FIFO's TX gate (audio_pcm.c): closings, late (a beep still
					// sounding, its tail cut), ring play on while closed (never); the speaker queue's underruns (never)
		uint32_t g, l, ra, b, ov, un;
		hrc_audio_pcm_gate_stats(&g, &l, &ra);
		hrc_audio_pcm_stats(&b, &ov, &un);
		put_kv(&o, "pg g", g);
		put_kv(&o, " l", l);
		put_kv(&o, " ra", ra);
		put_kv(&o, " un", un);
		break;
	}
	default:
		return false;
	}
	*o.p = '\0';
	return true;
}

#endif	// CONFIG_DMR
