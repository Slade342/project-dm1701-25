// SPDX-License-Identifier: MIT
// Copyright (c) 2026 The RadioFoundry Authors
// FreeRTOS for the HR_C7000 radios (CK803S; one interrupt level, no priorities: platform/hrc7000/freertos)
#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

// A board changes a setting in boards/<id>/freertos_board.h, read first; every setting below it is a default
#if __has_include("freertos_board.h")
#include "freertos_board.h"
#endif

#include <stdint.h>
#include "clock_hz.h"

#define configUSE_PREEMPTION			1
#define configUSE_PORT_OPTIMISED_TASK_SELECTION	0
#define configCPU_CLOCK_HZ			HRC_CPU_HZ	// 168 MHz unless board.mk sets it (clock_hz.h)
#define configTICK_RATE_HZ			1000
#define configMAX_PRIORITIES			7
#if CONFIG_CRASH_LOG
#define configMINIMAL_STACK_SIZE		144	// the idle task: a configASSERT in the kernel captures on it (make stack-check)
#else
#define configMINIMAL_STACK_SIZE		128
#endif
#ifndef configTOTAL_HEAP_SIZE
#define configTOTAL_HEAP_SIZE			(40 * 1024)	// task stacks and queues (the STM32 radios need 28 KB; more room here)
#endif
#define configMAX_TASK_NAME_LEN			12
#define configUSE_16_BIT_TICKS			0
#define configIDLE_SHOULD_YIELD			1
#define configUSE_MUTEXES			1
#define configUSE_RECURSIVE_MUTEXES		1
#define configUSE_COUNTING_SEMAPHORES		1
#define configQUEUE_REGISTRY_SIZE		0
#define configUSE_TASK_NOTIFICATIONS		1
#define configSUPPORT_STATIC_ALLOCATION		0
#define configSUPPORT_DYNAMIC_ALLOCATION	1
#define configUSE_IDLE_HOOK			CONFIG_WATCHDOG	// the watchdog feed (core/app/watchdog.c)
#define configUSE_TICK_HOOK			1
#define configCHECK_FOR_STACK_OVERFLOW		2
#define configUSE_MALLOC_FAILED_HOOK		1
#define configUSE_TIMERS			1
#define configTIMER_TASK_PRIORITY		(configMAX_PRIORITIES - 1)
#define configTIMER_QUEUE_LENGTH		8
#define configTIMER_TASK_STACK_DEPTH		256
#define configUSE_TRACE_FACILITY		0
#define configUSE_STATS_FORMATTING_FUNCTIONS	0

// Every task's handle for the debug link's tasks view, its least free stack (core/app/task_stack.c)
#if CONFIG_TASK_STACKS && !defined(__ASSEMBLER__)
#include "app/task_stack.h"
#define traceTASK_CREATE(tcb)			task_stack_created(tcb)
#define traceTASK_DELETE(tcb)			task_stack_deleted(tcb)
#endif

#define INCLUDE_vTaskPrioritySet		1
#define INCLUDE_uxTaskPriorityGet		1
#define INCLUDE_vTaskDelete			1
#define INCLUDE_vTaskSuspend			1
#define INCLUDE_vTaskDelayUntil			1
#define INCLUDE_vTaskDelay			1
#define INCLUDE_xTaskGetSchedulerState		1
#define INCLUDE_xTaskGetCurrentTaskHandle	1
#define INCLUDE_uxTaskGetStackHighWaterMark	1

// A failed assertion: with the crash log, kept (the line, the caller) and the radio restarts (core/crash/crash.h)
#if CONFIG_CRASH_LOG && !defined(__ASSEMBLER__)
void crash_assert(unsigned line) __attribute__((noreturn));
#define configASSERT(x)				do { if (!(x)) { crash_assert(__LINE__); } } while (0)
#else
#define configASSERT(x)				do { if (!(x)) { __asm__ volatile ("psrclr ie"); for (;;) {} } } while (0)
#endif

#endif
